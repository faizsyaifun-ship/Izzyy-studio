# Izzy Studio

A React + TypeScript browser-based AI video storyboard and canvas-rendering studio.

## Run locally

1. Install Node.js 20 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env.local` and add your `GEMINI_API_KEY`.
4. Run `npm run dev`.
5. Open the local URL shown in the terminal.

## Build for deployment

- `npm run build` creates the production frontend in `dist/`.
- Deploy the app with its server/API routes to a Node.js host; keep API keys in server-side environment variables.
- Do not place Gemini API keys in client-side code.

## Video styles

The studio includes Editorial Desk, Tech Blueprint, Kinetic Cards, Newsroom Broadcast, Sonic Pulse, and **Creator Portfolio Motion**.

Creator Portfolio Motion is based on the supplied motion reference: alternating dark and pale scenes, social-profile identity, floating browser/search UI, a purple project panel, floating profile card, blue contact CTA, and a logo-style outro. The design is rendered procedurally on the canvas and adapts to vertical, square, and widescreen output.


## Sutradara AI

Panel Sutradara AI berada di bawah preview. Masukkan instruksi revisi dalam bahasa alami, lalu pilih **Revisi dengan AI**. Server mengirim instruksi bersama storyboard aktif ke Gemini, memvalidasi hasil melalui skema storyboard, dan mengembalikan blueprint yang direvisi tanpa mengganti identitas proyek, rasio aspek, gaya, atau sumber audio. API key tetap berada di server.


### Sutradara AI bertahap

Sutradara AI menerima storyboard terkini dan hingga lima instruksi revisi terakhir sebagai konteks. Instruksi terbaru menjadi prioritas, sehingga pengguna dapat menyempurnakan video berulang kali tanpa memulai proyek dari awal. Panel juga menyediakan tombol **Urungkan** untuk membatalkan revisi terakhir (hingga 10 langkah selama proyek aktif). Riwayat revisi berada di memori sesi browser dan akan direset saat proyek video baru dibuat atau halaman dimuat ulang.

## Instalasi seperti aplikasi (PWA)

IZZY STUDIO sudah memiliki manifest, ikon aplikasi, dan service worker. Setelah aplikasi dipasang pada hosting dengan HTTPS:

- **Android / Chrome:** buka URL aplikasi → menu ⋮ → `Install app` atau `Add to Home screen`.
- **iPhone:** buka URL aplikasi di Safari → tombol Share → `Add to Home Screen` → `Add`. (Di iPhone, Safari adalah cara paling konsisten untuk memasang web app.)

PWA tetap membutuhkan koneksi internet untuk fitur AI dan server. Service worker hanya menyimpan shell aplikasi; endpoint `/api/` tidak pernah disimpan ke cache.

## Deployment ke Render

File `render.yaml` disertakan sebagai konfigurasi awal. Unggah repository proyek ke GitHub, lalu di Render pilih **New → Blueprint** dan hubungkan repository tersebut. Setelah layanan dibuat, isi environment variable `GEMINI_API_KEY` pada dashboard Render. Tunggu deployment selesai, lalu buka URL HTTPS yang diberikan Render.
