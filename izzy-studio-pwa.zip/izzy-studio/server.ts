import "dotenv/config";
import { AsyncLocalStorage } from "async_hooks";
import express from "express";
import type { Request, Response } from "express";
import fs from "fs";
import os from "os";
import path from "path";
import { spawn } from "child_process";
import { fileURLToPath } from "url";
import { createPartFromUri, GoogleGenAI, ThinkingLevel, Type } from "@google/genai";
import {
  defaultEnvironmentalEffectForAsset,
  detectSentenceLanguage,
  detectTextLanguage,
  runBlueprintQualityControl,
} from "./src/lib/languageSync.ts";
import type {
  AnimationIntensity,
  AspectRatio,
  EnvironmentalEffectType,
  LanguagePreference,
  MotionTimingCurve,
  SceneTransition,
  SupportedLanguage,
  VideoBlueprint,
  VideoStyleId,
  VoiceName,
} from "./src/types/video.ts";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);

// Capped exponential backoff schedule (max 4 retry attempts, max single wait 15s)
const RETRY_DELAYS_MS = [1500, 3000, 6000, 10000] as const;
const MAX_RETRY_ATTEMPTS = RETRY_DELAYS_MS.length;
const MAX_COOLDOWN_WAIT_MS = 15_000;
const MIN_GENERAL_GAP_MS = 350;
const MIN_TTS_GAP_MS = 1200;

// Supported active Gemini models (never deprecated 1.5/2.0 models)
const MODEL_CONFIG = {
  storyboard: {
    primary: "gemini-4-hydrogen",
    fallback: "gemini-3.1-flash-lite",
  },
  transcription: {
    primary: "gemini-3.5-transcribe",
    fallback: "gemini-4-hydrogen",
  },
  tts: {
    primary: "gemini-3.8-flash-lite-tts",
    fallback: "gemini-3.8-flash-tts",
  },
} as const;

type ModelTask = keyof typeof MODEL_CONFIG;

interface ModelUsageReport {
  task: ModelTask;
  primaryModel: string;
  usedModel: string;
  fallbackUsed: boolean;
  fallbackReason?: string;
}

interface ModelAvailabilityEntry {
  available: boolean;
  checkedAt: number;
  error?: string;
}

const MODEL_CACHE_TTL_MS = 60_000;
const modelAvailabilityCache = new Map<string, ModelAvailabilityEntry>();

interface HttpCaptureRecord {
  status: number;
  urlPath: string;
  retryAfterHeader: string | null;
  rateLimitHeaders: Record<string, string>;
  rawBody: string;
  capturedAt: number;
}

interface HttpCaptureStore {
  lastError: HttpCaptureRecord | null;
}

const geminiHttpCaptureAls = new AsyncLocalStorage<HttpCaptureStore>();
let fetchHookInstalled = false;

function installGeminiFetchDiagnosticHook(): void {
  if (fetchHookInstalled || typeof globalThis.fetch !== "function") return;
  const originalFetch = globalThis.fetch.bind(globalThis);

  globalThis.fetch = async (
    input: Parameters<typeof fetch>[0],
    init?: Parameters<typeof fetch>[1]
  ): Promise<globalThis.Response> => {
    const response = await originalFetch(input, init);
    const store = geminiHttpCaptureAls.getStore();
    if (!store || response.ok) {
      return response;
    }

    try {
      const rawUrl =
        typeof input === "string"
          ? input
          : input instanceof URL
          ? input.toString()
          : input.url;

      if (rawUrl.includes("generativelanguage.googleapis.com")) {
        const parsedUrl = new URL(rawUrl);
        const rateLimitHeaders: Record<string, string> = {};
        response.headers.forEach((value, key) => {
          const lower = key.toLowerCase();
          if (
            lower === "retry-after" ||
            lower.startsWith("x-ratelimit") ||
            lower.startsWith("x-goog-ratelimit")
          ) {
            rateLimitHeaders[lower] = value;
          }
        });

        const cloned = response.clone();
        const rawBody = (await cloned.text().catch(() => "")).slice(0, 2000);
        store.lastError = {
          status: response.status,
          urlPath: parsedUrl.pathname,
          retryAfterHeader: response.headers.get("retry-after"),
          rateLimitHeaders,
          rawBody,
          capturedAt: Date.now(),
        };
      }
    } catch {
      // Never break fetch on diagnostic inspection
    }

    return response;
  };

  fetchHookInstalled = true;
}

installGeminiFetchDiagnosticHook();

function attachHttpCaptureToError(
  err: unknown,
  capture: HttpCaptureRecord | null
): Error {
  const baseErr =
    err instanceof Error ? err : new Error(String(err ?? "Gemini API error"));
  if (capture) {
    (
      baseErr as Error & { _httpCapture?: HttpCaptureRecord }
    )._httpCapture = capture;
  }
  return baseErr;
}

function getAttachedHttpCapture(err: unknown): HttpCaptureRecord | null {
  if (!err || typeof err !== "object") return null;
  return (
    (err as { _httpCapture?: HttpCaptureRecord })._httpCapture ?? null
  );
}

function attachModelToError(err: unknown, modelName: string): Error {
  const baseErr =
    err instanceof Error ? err : new Error(String(err ?? "Gemini API error"));
  if (!(baseErr as Error & { _geminiModel?: string })._geminiModel) {
    (baseErr as Error & { _geminiModel?: string })._geminiModel = modelName;
  }
  return baseErr;
}

function getAttachedModel(err: unknown): string | null {
  if (!err || typeof err !== "object") return null;
  return (err as { _geminiModel?: string })._geminiModel ?? null;
}

interface CooldownEntry {
  until: number;
  causeType: "rate_limit" | "quota_exhausted" | "server_error" | "network" | "validation";
  quotaMetric: string | null;
}

class GeminiRequestQueue {
  private tail: Promise<void> = Promise.resolve();
  private lastCompletedAt = 0;
  private modelCooldowns = new Map<string, CooldownEntry>();

  getActiveCooldown(modelName: string): {
    remainingMs: number;
    entry: CooldownEntry;
  } | null {
    const entry = this.modelCooldowns.get(modelName);
    if (!entry) return null;
    const remainingMs = entry.until - Date.now();
    if (remainingMs <= 0) {
      this.modelCooldowns.delete(modelName);
      return null;
    }
    return { remainingMs, entry };
  }

  getRemainingCooldownMs(modelName: string): number {
    return this.getActiveCooldown(modelName)?.remainingMs ?? 0;
  }

  recordCooldown(
    modelName: string,
    cooldownMs: number,
    causeType: CooldownEntry["causeType"] = "rate_limit",
    quotaMetric: string | null = null
  ): void {
    if (!Number.isFinite(cooldownMs) || cooldownMs <= 0) return;
    const bounded = Math.min(cooldownMs, 300_000);
    const nextUntil = Date.now() + bounded;
    const prev = this.modelCooldowns.get(modelName);
    if (!prev || nextUntil > prev.until) {
      this.modelCooldowns.set(modelName, {
        until: nextUntil,
        causeType,
        quotaMetric,
      });
    }
  }

  async enqueue<T>(
    label: string,
    minGapMs: number,
    signal: AbortSignal | undefined,
    task: () => Promise<T>
  ): Promise<T> {
    if (signal?.aborted) {
      throw new Error("Permintaan dibatalkan oleh pengguna.");
    }

    const run = async (): Promise<T> => {
      if (signal?.aborted) {
        throw new Error("Permintaan dibatalkan oleh pengguna.");
      }
      const elapsed = Date.now() - this.lastCompletedAt;
      if (this.lastCompletedAt > 0 && elapsed < minGapMs) {
        await sleepWithAbort(minGapMs - elapsed, signal);
      }
      try {
        return await task();
      } finally {
        this.lastCompletedAt = Date.now();
      }
    };

    const next = this.tail.then(run, run);
    this.tail = next.then(
      () => undefined,
      () => undefined
    );
    try {
      return await next;
    } catch (err) {
      console.warn(
        `[gemini-queue] Task "${label}" failed: ${
          err instanceof Error ? err.message.slice(0, 180) : String(err)
        }`
      );
      throw err;
    }
  }
}

const geminiQueue = new GeminiRequestQueue();

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      "GEMINI_API_KEY belum tersedia. Periksa konfigurasi Secrets di AI Studio."
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      timeout: 35_000,
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

interface ParsedErrorDetails {
  httpStatus: number | null;
  codeName: string | null;
  message: string;
  retryAfterSeconds: number | null;
  quotaMetric: string | null;
  causeType: "rate_limit" | "quota_exhausted" | "server_error" | "network" | "validation";
  rawDiagnosticSnippet: string;
}

function parseRetryDelayToSeconds(val: unknown): number | null {
  if (typeof val === "number" && Number.isFinite(val) && val > 0) {
    return Math.ceil(val);
  }
  if (typeof val !== "string") return null;
  const trimmed = val.trim();
  if (!trimmed) return null;

  if (/^\d+(\.\d+)?s$/i.test(trimmed)) {
    const secs = Number(trimmed.slice(0, -1));
    return Number.isFinite(secs) && secs > 0 ? Math.ceil(secs) : null;
  }
  if (/^\d+$/.test(trimmed)) {
    const secs = Number(trimmed);
    return Number.isFinite(secs) && secs > 0 ? Math.ceil(secs) : null;
  }
  const dateMs = Date.parse(trimmed);
  if (Number.isFinite(dateMs)) {
    const diffSec = Math.ceil((dateMs - Date.now()) / 1000);
    return diffSec > 0 ? diffSec : null;
  }
  return null;
}

function extractErrorDetails(err: unknown): ParsedErrorDetails {
  const anyErr = err as
    | {
        status?: unknown;
        statusCode?: unknown;
        code?: unknown;
        message?: unknown;
        error?: { code?: unknown; status?: unknown; message?: unknown };
        response?: { status?: unknown };
      }
    | undefined;

  const httpCapture = getAttachedHttpCapture(err);
  const cooldownMeta =
    err && typeof err === "object"
      ? (err as {
          _cooldownMeta?: {
            remainingSeconds?: number;
            causeType?: ParsedErrorDetails["causeType"];
            quotaMetric?: string | null;
          };
        })._cooldownMeta
      : undefined;

  const rawMessage =
    err instanceof Error
      ? err.message
      : typeof anyErr?.error?.message === "string"
      ? anyErr.error.message
      : String(err ?? "Terjadi kesalahan tidak terduga.");

  const candidateStatuses = [
    httpCapture?.status,
    anyErr?.status,
    anyErr?.statusCode,
    anyErr?.code,
    anyErr?.error?.code,
    anyErr?.response?.status,
  ];

  let httpStatus: number | null = null;
  for (const val of candidateStatuses) {
    if (typeof val === "number" && val >= 400 && val < 600) {
      httpStatus = val;
      break;
    }
    if (typeof val === "string" && /^\d{3}$/.test(val)) {
      const n = Number(val);
      if (n >= 400 && n < 600) {
        httpStatus = n;
        break;
      }
    }
  }

  let codeName: string | null = null;
  const rawStatusStr =
    typeof anyErr?.error?.status === "string"
      ? anyErr.error.status
      : typeof anyErr?.status === "string"
      ? anyErr.status
      : null;
  if (rawStatusStr) {
    codeName = rawStatusStr.toUpperCase();
  }

  const combinedInspectionText = `${rawMessage}\n${httpCapture?.rawBody ?? ""}`;
  const upperMsg = combinedInspectionText.toUpperCase();
  const knownCodeNames = [
    "API_KEY_INVALID",
    "PERMISSION_DENIED",
    "NOT_FOUND",
    "RESOURCE_EXHAUSTED",
    "UNAVAILABLE",
    "DEADLINE_EXCEEDED",
    "INTERNAL",
    "BAD_GATEWAY",
    "SERVICE_UNAVAILABLE",
    "GATEWAY_TIMEOUT",
  ];
  if (!codeName) {
    for (const k of knownCodeNames) {
      if (upperMsg.includes(k)) {
        codeName = k;
        break;
      }
    }
  }

  if (!httpStatus) {
    const match = combinedInspectionText.match(
      /\b(400|401|403|404|429|500|502|503|504)\b/
    );
    if (match) {
      httpStatus = Number(match[1]);
    } else if (codeName === "API_KEY_INVALID") {
      httpStatus = 400;
    } else if (codeName === "PERMISSION_DENIED") {
      httpStatus = 403;
    } else if (codeName === "NOT_FOUND") {
      httpStatus = 404;
    } else if (codeName === "RESOURCE_EXHAUSTED") {
      httpStatus = 429;
    } else if (codeName === "INTERNAL") {
      httpStatus = 500;
    } else if (codeName === "BAD_GATEWAY") {
      httpStatus = 502;
    } else if (
      codeName === "UNAVAILABLE" ||
      codeName === "SERVICE_UNAVAILABLE"
    ) {
      httpStatus = 503;
    } else if (
      codeName === "DEADLINE_EXCEEDED" ||
      codeName === "GATEWAY_TIMEOUT"
    ) {
      httpStatus = 504;
    }
  }

  // Parse Retry-After header and Google RPC RetryInfo / QuotaFailure body
  let retryAfterSeconds: number | null = parseRetryDelayToSeconds(
    httpCapture?.retryAfterHeader
  );
  let quotaMetric: string | null = null;
  let parsedErrorSummary = "";

  const jsonBodiesToInspect = [httpCapture?.rawBody, rawMessage].filter(
    (s): s is string => Boolean(s && s.trim().startsWith("{"))
  );

  for (const jsonCandidate of jsonBodiesToInspect) {
    try {
      const parsed = JSON.parse(jsonCandidate) as {
        error?: {
          message?: string;
          status?: string;
          details?: Array<{
            "@type"?: string;
            retryDelay?: string;
            violations?: Array<{
              quotaMetric?: string;
              quotaId?: string;
              quotaValue?: string;
              description?: string;
            }>;
          }>;
        };
      };
      const inner = parsed.error;
      if (inner?.message && !parsedErrorSummary) {
        parsedErrorSummary = inner.message;
      }
      if (inner?.status && !codeName) {
        codeName = inner.status.toUpperCase();
      }
      for (const detail of inner?.details ?? []) {
        const dtype = String(detail?.["@type"] || "");
        if (dtype.includes("RetryInfo") && detail.retryDelay && !retryAfterSeconds) {
          retryAfterSeconds = parseRetryDelayToSeconds(detail.retryDelay);
        }
        if (dtype.includes("QuotaFailure") && Array.isArray(detail.violations)) {
          const metrics = detail.violations
            .map((v) => v.quotaId || v.quotaMetric || v.description || "")
            .filter(Boolean);
          if (metrics.length > 0 && !quotaMetric) {
            quotaMetric = metrics.join(", ");
          }
        }
      }
    } catch {
      // ignore non-JSON text
    }
  }

  if (!retryAfterSeconds) {
    const inlineMatch = combinedInspectionText.match(
      /retry(?:\s+after|\s+in)?\s+(\d+(?:\.\d+)?)\s*s/i
    );
    if (inlineMatch) {
      const secs = Number(inlineMatch[1]);
      if (Number.isFinite(secs) && secs > 0) {
        retryAfterSeconds = Math.ceil(secs);
      }
    }
  }

  const lowerAll = combinedInspectionText.toLowerCase();
  const metricLower = (quotaMetric || "").toLowerCase();
  let causeType: ParsedErrorDetails["causeType"] = "server_error";

  if (httpStatus === 400 || httpStatus === 401 || httpStatus === 403 || httpStatus === 404) {
    causeType = "validation";
  } else if (httpStatus === 429 || codeName === "RESOURCE_EXHAUSTED") {
    const isDailyOrZeroQuota =
      metricLower.includes("perday") ||
      metricLower.includes("daily") ||
      lowerAll.includes("perday") ||
      lowerAll.includes("daily") ||
      lowerAll.includes("limit: 0") ||
      (retryAfterSeconds !== null && retryAfterSeconds > 120);
    causeType = isDailyOrZeroQuota ? "quota_exhausted" : "rate_limit";
  } else if (
    lowerAll.includes("fetch failed") ||
    lowerAll.includes("econnreset") ||
    lowerAll.includes("etimedout") ||
    lowerAll.includes("network") ||
    lowerAll.includes("socket hang up")
  ) {
    causeType = "network";
  }

  if (cooldownMeta) {
    if (cooldownMeta.remainingSeconds && !retryAfterSeconds) {
      retryAfterSeconds = cooldownMeta.remainingSeconds;
    }
    if (cooldownMeta.quotaMetric && !quotaMetric) {
      quotaMetric = cooldownMeta.quotaMetric;
    }
    if (cooldownMeta.causeType) {
      causeType = cooldownMeta.causeType;
    }
  }

  const headerInfo = httpCapture?.retryAfterHeader
    ? `Retry-After=${httpCapture.retryAfterHeader}`
    : "Retry-After=none";
  const bodySnippet = (parsedErrorSummary || rawMessage)
    .replace(/\s+/g, " ")
    .slice(0, 260);
  const rawDiagnosticSnippet = [
    httpStatus ? `HTTP ${httpStatus}` : null,
    codeName,
    headerInfo,
    quotaMetric ? `metric=${quotaMetric}` : null,
    bodySnippet,
  ]
    .filter(Boolean)
    .join(" | ");

  return {
    httpStatus,
    codeName,
    message: rawMessage,
    retryAfterSeconds,
    quotaMetric,
    causeType,
    rawDiagnosticSnippet,
  };
}

function isRetryableError(err: unknown): boolean {
  const details = extractErrorDetails(err);
  const { httpStatus, codeName, message, causeType, retryAfterSeconds } = details;
  if (httpStatus === 400 || httpStatus === 401 || httpStatus === 403 || httpStatus === 404) {
    return false;
  }
  // Do not waste blind retries when daily quota or zero-limit quota is exhausted
  if (causeType === "quota_exhausted") {
    return false;
  }
  // Do not stall a web request if upstream asks to wait longer than our cap
  if (
    retryAfterSeconds !== null &&
    retryAfterSeconds * 1000 > MAX_COOLDOWN_WAIT_MS
  ) {
    return false;
  }
  if (
    httpStatus === 429 ||
    httpStatus === 500 ||
    httpStatus === 502 ||
    httpStatus === 503 ||
    httpStatus === 504
  ) {
    return true;
  }
  if (
    codeName === "RESOURCE_EXHAUSTED" ||
    codeName === "UNAVAILABLE" ||
    codeName === "SERVICE_UNAVAILABLE" ||
    codeName === "INTERNAL" ||
    codeName === "BAD_GATEWAY" ||
    codeName === "DEADLINE_EXCEEDED" ||
    codeName === "GATEWAY_TIMEOUT"
  ) {
    return true;
  }
  const lower = message.toLowerCase();
  return (
    lower.includes("unavailable") ||
    lower.includes("overloaded") ||
    lower.includes("try again") ||
    lower.includes("timeout") ||
    lower.includes("timed out") ||
    lower.includes("econnreset") ||
    lower.includes("etimedout") ||
    lower.includes("enotfound") ||
    lower.includes("eai_again") ||
    lower.includes("fetch failed") ||
    lower.includes("socket hang up") ||
    lower.includes("network")
  );
}

function isModelNotFoundError(err: unknown): boolean {
  const { httpStatus, codeName, message } = extractErrorDetails(err);
  if (httpStatus === 404 || codeName === "NOT_FOUND") return true;
  const lower = message.toLowerCase();
  return (
    lower.includes("model not found") ||
    lower.includes("is not found for api version") ||
    lower.includes("not supported for generatecontent")
  );
}

function isEmptyModelOutputError(err: unknown): boolean {
  return (
    err instanceof Error &&
    (err as Error & { code?: string }).code === "EMPTY_MODEL_OUTPUT"
  );
}

async function sleepWithAbort(ms: number, signal?: AbortSignal): Promise<void> {
  if (signal?.aborted) {
    throw new Error("Permintaan dibatalkan oleh pengguna.");
  }
  await new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => {
      signal?.removeEventListener("abort", onAbort);
      resolve();
    }, ms);
    const onAbort = () => {
      clearTimeout(timer);
      reject(new Error("Permintaan dibatalkan oleh pengguna."));
    };
    signal?.addEventListener("abort", onAbort, { once: true });
  });
}

async function executeWithRetry<T>(
  modelName: string,
  minGapMs: number,
  operation: () => Promise<T>,
  options: {
    signal?: AbortSignal;
    onRetry?: (info: {
      attempt: number;
      maxRetries: number;
      delayMs: number;
      httpStatus: number | null;
      message: string;
    }) => void;
  } = {}
): Promise<T> {
  let lastError: unknown;
  for (let attempt = 0; attempt <= MAX_RETRY_ATTEMPTS; attempt++) {
    if (options.signal?.aborted) {
      throw new Error("Permintaan dibatalkan.");
    }
    try {
      const activeCooldown = geminiQueue.getActiveCooldown(modelName);
      if (activeCooldown && activeCooldown.remainingMs > MAX_COOLDOWN_WAIT_MS) {
        const remainingSeconds = Math.ceil(activeCooldown.remainingMs / 1000);
        const cooldownErr = new Error(
          `Model ${modelName} dalam masa cooldown (${remainingSeconds} detik tersisa).`
        ) as Error & {
          status?: number;
          _cooldownMeta?: {
            remainingSeconds: number;
            causeType: CooldownEntry["causeType"];
            quotaMetric: string | null;
          };
        };
        cooldownErr.status = 429;
        cooldownErr._cooldownMeta = {
          remainingSeconds,
          causeType: activeCooldown.entry.causeType,
          quotaMetric: activeCooldown.entry.quotaMetric,
        };
        throw attachModelToError(cooldownErr, modelName);
      }
      if (activeCooldown && activeCooldown.remainingMs > 0) {
        await sleepWithAbort(activeCooldown.remainingMs, options.signal);
      }

      return await geminiQueue.enqueue(
        modelName,
        minGapMs,
        options.signal,
        async () => {
          const store: HttpCaptureStore = { lastError: null };
          try {
            return await geminiHttpCaptureAls.run(store, operation);
          } catch (innerErr) {
            throw attachModelToError(
              attachHttpCaptureToError(innerErr, store.lastError),
              modelName
            );
          }
        }
      );
    } catch (err) {
      lastError = attachModelToError(err, modelName);
      const details = extractErrorDetails(lastError);

      if (details.httpStatus === 429 || details.codeName === "RESOURCE_EXHAUSTED") {
        const cooldownMs = details.retryAfterSeconds
          ? details.retryAfterSeconds * 1000
          : details.causeType === "quota_exhausted"
          ? 60_000
          : RETRY_DELAYS_MS[Math.min(attempt, RETRY_DELAYS_MS.length - 1)];
        geminiQueue.recordCooldown(
          modelName,
          cooldownMs,
          details.causeType,
          details.quotaMetric
        );
        console.warn(
          `[gemini-429] model=${modelName} cause=${details.causeType} retryAfter=${
            details.retryAfterSeconds ?? "none"
          }s metric=${details.quotaMetric ?? "none"} detail=${details.rawDiagnosticSnippet}`
        );
      }

      if (attempt >= MAX_RETRY_ATTEMPTS || !isRetryableError(lastError)) {
        throw lastError;
      }

      const backoffMs = RETRY_DELAYS_MS[attempt];
      const delayMs = details.retryAfterSeconds
        ? Math.min(
            MAX_COOLDOWN_WAIT_MS,
            Math.max(backoffMs, details.retryAfterSeconds * 1000)
          )
        : backoffMs;

      options.onRetry?.({
        attempt: attempt + 1,
        maxRetries: MAX_RETRY_ATTEMPTS,
        delayMs,
        httpStatus: details.httpStatus,
        message: details.message,
      });
      await sleepWithAbort(delayMs, options.signal);
    }
  }
  throw lastError instanceof Error
    ? attachModelToError(lastError, modelName)
    : attachModelToError(
        new Error("Permintaan Gemini API gagal setelah beberapa kali percobaan."),
        modelName
      );
}

async function checkModelAvailability(
  ai: GoogleGenAI,
  modelName: string
): Promise<ModelAvailabilityEntry> {
  const cached = modelAvailabilityCache.get(modelName);
  if (cached && Date.now() - cached.checkedAt < MODEL_CACHE_TTL_MS) {
    return cached;
  }

  try {
    await ai.models.get({ model: modelName });
    const entry: ModelAvailabilityEntry = {
      available: true,
      checkedAt: Date.now(),
    };
    modelAvailabilityCache.set(modelName, entry);
    return entry;
  } catch (err) {
    const details = extractErrorDetails(err);
    const available = !isModelNotFoundError(err);
    const entry: ModelAvailabilityEntry = {
      available,
      checkedAt: Date.now(),
      error: details.message,
    };
    modelAvailabilityCache.set(modelName, entry);
    return entry;
  }
}

async function runModelWithRetryAndFallback<T>(
  ai: GoogleGenAI,
  task: ModelTask,
  runner: (modelName: string) => Promise<T>,
  options: {
    signal?: AbortSignal;
    onRetry?: (info: {
      modelName: string;
      attempt: number;
      maxRetries: number;
      delayMs: number;
      httpStatus: number | null;
    }) => void;
    onFallback?: (info: {
      primaryModel: string;
      fallbackModel: string;
      reason: string;
    }) => void;
  } = {}
): Promise<{ result: T; report: ModelUsageReport }> {
  const { primary, fallback } = MODEL_CONFIG[task];
  const minGapMs = task === "tts" ? MIN_TTS_GAP_MS : MIN_GENERAL_GAP_MS;

  const primaryCheck = await checkModelAvailability(ai, primary);
  if (!primaryCheck.available && fallback !== primary) {
    const reason = `Model utama "${primary}" tidak tersedia (${primaryCheck.error || "NOT_FOUND"}).`;
    options.onFallback?.({
      primaryModel: primary,
      fallbackModel: fallback,
      reason,
    });

    const fallbackCheck = await checkModelAvailability(ai, fallback);
    if (!fallbackCheck.available) {
      throw attachModelToError(
        new Error(
          `Model utama "${primary}" dan model cadangan "${fallback}" tidak tersedia saat ini.`
        ),
        fallback
      );
    }

    const result = await executeWithRetry(fallback, minGapMs, () => runner(fallback), {
      signal: options.signal,
      onRetry: (info) =>
        options.onRetry?.({
          modelName: fallback,
          attempt: info.attempt,
          maxRetries: info.maxRetries,
          delayMs: info.delayMs,
          httpStatus: info.httpStatus,
        }),
    });

    return {
      result,
      report: {
        task,
        primaryModel: primary,
        usedModel: fallback,
        fallbackUsed: true,
        fallbackReason: reason,
      },
    };
  }

  try {
    const result = await executeWithRetry(primary, minGapMs, () => runner(primary), {
      signal: options.signal,
      onRetry: (info) =>
        options.onRetry?.({
          modelName: primary,
          attempt: info.attempt,
          maxRetries: info.maxRetries,
          delayMs: info.delayMs,
          httpStatus: info.httpStatus,
        }),
    });

    return {
      result,
      report: {
        task,
        primaryModel: primary,
        usedModel: primary,
        fallbackUsed: false,
      },
    };
  } catch (primaryErr) {
    const details = extractErrorDetails(primaryErr);
    const canFallback =
      fallback !== primary &&
      (isModelNotFoundError(primaryErr) ||
        isRetryableError(primaryErr) ||
        isEmptyModelOutputError(primaryErr) ||
        details.httpStatus === 429 ||
        details.codeName === "RESOURCE_EXHAUSTED");

    if (!canFallback) {
      throw attachModelToError(primaryErr, primary);
    }

    const reason = isModelNotFoundError(primaryErr)
      ? `Model utama "${primary}" mengembalikan 404 NOT_FOUND.`
      : isEmptyModelOutputError(primaryErr)
      ? `Model utama "${primary}" mengembalikan output kosong (${details.message}).`
      : `Model utama "${primary}" gagal (${
          details.httpStatus ?? details.codeName ?? "gangguan sementara"
        }).`;

    options.onFallback?.({
      primaryModel: primary,
      fallbackModel: fallback,
      reason,
    });

    const fallbackCheck = await checkModelAvailability(ai, fallback);
    if (!fallbackCheck.available) {
      throw attachModelToError(primaryErr, primary);
    }

    const result = await executeWithRetry(fallback, minGapMs, () => runner(fallback), {
      signal: options.signal,
      onRetry: (info) =>
        options.onRetry?.({
          modelName: fallback,
          attempt: info.attempt,
          maxRetries: info.maxRetries,
          delayMs: info.delayMs,
          httpStatus: info.httpStatus,
        }),
    });

    return {
      result,
      report: {
        task,
        primaryModel: primary,
        usedModel: fallback,
        fallbackUsed: true,
        fallbackReason: reason,
      },
    };
  }
}

function parseJsonSafely<T>(rawText: string, emptyFallbackMessage: string): T {
  const cleaned = rawText
    .trim()
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();

  if (!cleaned) {
    throw new Error(emptyFallbackMessage);
  }
  try {
    return JSON.parse(cleaned) as T;
  } catch {
    throw new Error(
      "Respons AI tidak berbentuk JSON yang valid. Silakan coba lagi."
    );
  }
}

type VisualAssetKey =
  | "projectile_bullet"
  | "human_silhouette"
  | "human_anatomy"
  | "heart_organ"
  | "brain_organ"
  | "vehicle_car"
  | "solar_planet"
  | "earthquake_seismic"
  | "tech_circuit"
  | "ocean_marine"
  | "energy_solar"
  | "money_economy"
  | "server_cyber"
  | "data_network"
  | "law_balance"
  | "news_globe"
  | "editorial_desk"
  | "concept_diagram";

type VisualCameraMovement =
  | "static"
  | "zoom_in"
  | "zoom_out"
  | "dolly_in"
  | "orbit"
  | "tilt_focus"
  | "pan_left"
  | "pan_right"
  | "track_object";

type VisualAnimationType =
  | "trajectory"
  | "pulse"
  | "orbit"
  | "shake_wave"
  | "flow_stream"
  | "scan_highlight"
  | "scale_compare"
  | "float_drift";

interface RawSceneVisualSpec {
  assetKey?: VisualAssetKey | string;
  subject?: string;
  action?: string;
  environment?: string;
  objects?: string[];
  visualDescription?: string;
  cameraMovement?: VisualCameraMovement | string;
  animationType?: VisualAnimationType | string;
  focusRegion?: string;
  objectMovement?: string;
  secondaryAnimation?: string;
  environmentalEffect?: EnvironmentalEffectType | string;
  animationIntensity?: AnimationIntensity | string;
  motionTiming?: MotionTimingCurve | string;
  narrationSyncCue?: string;
}

interface RawSceneSchema {
  archetype:
    | "desk_intro"
    | "metric_counter"
    | "network_graph"
    | "document_audit"
    | "server_radar"
    | "news_map_card"
    | "balance_verdict"
    | "kinetic_statement";
  transition?: SceneTransition | string;
  language?: SupportedLanguage | string;
  topTitle: string;
  topHighlightWord: string;
  topSubLabel: string;
  narration: string;
  estimatedSeconds?: number;
  calloutBadge?: string;
  sceneVisualSpec?: RawSceneVisualSpec;
  visualMetric?: {
    prefix: string;
    targetValue: number;
    decimals: number;
    suffix: string;
    unitLabel: string;
    sourceLabel: string;
  };
  tableRow?: {
    taskLabel: string;
    aiAction: string;
    evidenceText: string;
    status: "pending" | "warning" | "verified";
  };
  newsCard?: {
    tag: string;
    headline: string;
    regionName: string;
    subDetail?: string;
  };
  bullets?: string[];
}

interface RawBlueprintSchema {
  title: string;
  subjectNameplate: string;
  tableColumns: [string, string, string];
  scenes: RawSceneSchema[];
}

const BLUEPRINT_RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    title: {
      type: Type.STRING,
      description: "Judul singkat video explainer (maksimal 6 kata) sesuai bahasa output.",
    },
    subjectNameplate: {
      type: Type.STRING,
      description:
        "Label singkat topik utama dalam huruf kapital sesuai bahasa output (misal: BALISTIK PELURU, ANATOMI TUBUH, CARDIAC SYSTEM).",
    },
    tableColumns: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description:
        "Tepat 3 nama kolom pendek untuk tabel ringkasan progresif sesuai bahasa output (misal: ['Tahap', 'Proses', 'Dampak'] atau ['Stage', 'Process', 'Impact']).",
    },
    scenes: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          archetype: {
            type: Type.STRING,
            description:
              "Pilih satu dari: desk_intro, metric_counter, network_graph, document_audit, server_radar, news_map_card, balance_verdict, kinetic_statement. Gunakan kinetic_statement atau metric_counter jika topik sains/kesehatan/teknologi/umum.",
          },
          transition: {
            type: Type.STRING,
            description:
              "Efek transisi masuk adegan agar halus dan sinematik. Pilih satu dari: morph, depth, whip, zoom, slide, fade.",
          },
          topTitle: {
            type: Type.STRING,
            description: "Headline singkat di bagian atas layar (3-6 kata) sesuai bahasa adegan.",
          },
          topHighlightWord: {
            type: Type.STRING,
            description:
              "Satu atau dua kata persis dari topTitle yang disorot warna aksen.",
          },
          topSubLabel: {
            type: Type.STRING,
            description: "Sub-label pendek 2-4 kata di atas atau bawah headline.",
          },
          narration: {
            type: Type.STRING,
            description:
              "Teks narasi suara yang dibacakan di adegan ini dan tampil sebagai subtitle tersinkronisasi.",
          },
          estimatedSeconds: {
            type: Type.NUMBER,
            description: "Estimasi durasi adegan dalam detik (antara 3.5 hingga 8.0).",
          },
          calloutBadge: {
            type: Type.STRING,
            description: "Label penanda kecil opsional (2-3 kata).",
          },
          sceneVisualSpec: {
            type: Type.OBJECT,
            description:
              "Spesifikasi semantik & gerak multi-lapisan adegan ini. WAJIB cocok dengan makna narasi adegan!",
            properties: {
              assetKey: {
                type: Type.STRING,
                description:
                  "Pilih paling cocok: projectile_bullet (peluru/proyektil), human_silhouette (siluet tubuh manusia), human_anatomy (anatomi tubuh/organ/cedera), heart_organ (jantung/heart), brain_organ (otak/saraf/brain), vehicle_car (mobil/kendaraan), solar_planet (planet/tata surya/antariksa), earthquake_seismic (gempa/bangunan bergetar), tech_circuit (teknologi/chip/robot/AI), ocean_marine (laut/ombak/ikan), energy_solar (energi/listrik), money_economy (ekonomi/uang), server_cyber (server/keamanan siber), data_network (jaringan data), law_balance (hukum/timbangan evaluasi), news_globe (peta wilayah/negara), editorial_desk (HANYA jika topik memang kantor/pemerintahan/birokrasi), concept_diagram (diagram konsep edukatif umum).",
              },
              subject: {
                type: Type.STRING,
                description: "Subjek atau objek utama yang digambar (2-5 kata).",
              },
              action: {
                type: Type.STRING,
                description: "Aktivitas atau proses visual yang terjadi pada adegan ini.",
              },
              environment: {
                type: Type.STRING,
                description: "Lingkungan atau latar konteks adegan.",
              },
              objects: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
                description: "2-3 objek pendukung relevan yang muncul bergerak di layar.",
              },
              visualDescription: {
                type: Type.STRING,
                description: "Deskripsi adegan multi-lapisan sinematik yang menjelaskan narasi.",
              },
              cameraMovement: {
                type: Type.STRING,
                description:
                  "Pilih satu gerakan kamera dinamis: dolly_in, orbit, tilt_focus, zoom_in, zoom_out, pan_left, pan_right, track_object, static",
              },
              animationType: {
                type: Type.STRING,
                description:
                  "Pilih satu: trajectory, pulse, orbit, shake_wave, flow_stream, scan_highlight, scale_compare, float_drift",
              },
              focusRegion: {
                type: Type.STRING,
                description: "Area atau bagian spesifik yang disorot (misal: Rongga Dada, Ujung Proyektil, Orbit Planet).",
              },
              objectMovement: {
                type: Type.STRING,
                description: "Bagaimana objek utama bergerak (misal: accelerating 3D heartbeat contraction).",
              },
              secondaryAnimation: {
                type: Type.STRING,
                description: "Gerakan lapisan sekunder/pendukung (misal: flowing blood particles and ECG pulse).",
              },
              environmentalEffect: {
                type: Type.STRING,
                description:
                  "Efek atmosfer/partikel: blood_flow, starfield_drift, seismic_tremor, data_streams, ocean_bubbles, energy_sparks, shockwave_rings, ambient_dust",
              },
              animationIntensity: {
                type: Type.STRING,
                description: "Intensitas gerak: subtle, balanced, atau cinematic",
              },
              motionTiming: {
                type: Type.STRING,
                description: "Kurva fisika gerak: spring, ease_in_out, dramatic_ramp, atau linear_flow",
              },
              narrationSyncCue: {
                type: Type.STRING,
                description: "Petunjuk sinkronisasi visual terhadap penekanan kalimat narasi.",
              },
            },
            required: [
              "assetKey",
              "subject",
              "action",
              "environment",
              "objects",
              "visualDescription",
              "cameraMovement",
              "animationType",
              "objectMovement",
              "secondaryAnimation",
              "environmentalEffect",
            ],
          },
          visualMetric: {
            type: Type.OBJECT,
            description:
              "Isi jika adegan menampilkan angka, nilai uang, persentase, atau statistik.",
            properties: {
              prefix: { type: Type.STRING },
              targetValue: { type: Type.NUMBER },
              decimals: { type: Type.INTEGER },
              suffix: { type: Type.STRING },
              unitLabel: { type: Type.STRING },
              sourceLabel: { type: Type.STRING },
            },
            required: [
              "prefix",
              "targetValue",
              "decimals",
              "suffix",
              "unitLabel",
              "sourceLabel",
            ],
          },
          tableRow: {
            type: Type.OBJECT,
            description:
              "Isi untuk menambahkan baris baru ke tabel ringkasan progresif di bagian atas layar.",
            properties: {
              taskLabel: { type: Type.STRING },
              aiAction: { type: Type.STRING },
              evidenceText: { type: Type.STRING },
              status: {
                type: Type.STRING,
                description: "Pilih satu: verified, warning, pending",
              },
            },
            required: ["taskLabel", "aiAction", "evidenceText", "status"],
          },
          newsCard: {
            type: Type.OBJECT,
            description:
              "Isi jika archetype adalah news_map_card untuk menampilkan kartu berita dan lokasi.",
            properties: {
              tag: { type: Type.STRING },
              headline: { type: Type.STRING },
              regionName: { type: Type.STRING },
              subDetail: { type: Type.STRING },
            },
            required: ["tag", "headline", "regionName"],
          },
          bullets: {
            type: Type.ARRAY,
            items: { type: Type.STRING },
            description: "Maksimal 3 poin kata kunci singkat.",
          },
        },
        required: [
          "archetype",
          "topTitle",
          "topHighlightWord",
          "topSubLabel",
          "narration",
          "sceneVisualSpec",
        ],
      },
    },
  },
  required: ["title", "subjectNameplate", "tableColumns", "scenes"],
};

function parseWavInfo(wavBuffer: Buffer): {
  durationSeconds: number;
  pcmData: Buffer;
  header: Buffer;
} {
  if (wavBuffer.length <= 44 || wavBuffer.toString("ascii", 0, 4) !== "RIFF") {
    const fallbackBytesPerSec = 24000 * 2;
    return {
      durationSeconds: Math.max(1.5, wavBuffer.length / fallbackBytesPerSec),
      pcmData: wavBuffer,
      header: Buffer.alloc(0),
    };
  }

  const numChannels = wavBuffer.readUInt16LE(22) || 1;
  const sampleRate = wavBuffer.readUInt32LE(24) || 24000;
  const bitsPerSample = wavBuffer.readUInt16LE(34) || 16;
  const byteRate = sampleRate * numChannels * (bitsPerSample / 8);

  let dataOffset = 36;
  while (dataOffset + 8 < wavBuffer.length) {
    const chunkId = wavBuffer.toString("ascii", dataOffset, dataOffset + 4);
    const chunkSize = wavBuffer.readUInt32LE(dataOffset + 4);
    if (chunkId === "data") {
      const pcmStart = dataOffset + 8;
      const pcmEnd = Math.min(wavBuffer.length, pcmStart + chunkSize);
      const pcmData = wavBuffer.subarray(pcmStart, pcmEnd);
      return {
        durationSeconds: Math.max(1.2, pcmData.length / byteRate),
        pcmData,
        header: wavBuffer.subarray(0, pcmStart),
      };
    }
    dataOffset += 8 + chunkSize;
  }

  const pcmData = wavBuffer.subarray(44);
  return {
    durationSeconds: Math.max(1.2, pcmData.length / byteRate),
    pcmData,
    header: wavBuffer.subarray(0, 44),
  };
}

function concatenateWavBuffers(wavBuffers: Buffer[]): {
  combinedBase64: string;
  durations: number[];
} {
  if (wavBuffers.length === 0) {
    return { combinedBase64: "", durations: [] };
  }

  const parsed = wavBuffers.map(parseWavInfo);
  const durations = parsed.map((p) => p.durationSeconds);
  const firstValidHeader = parsed.find((p) => p.header.length >= 44)?.header;

  if (!firstValidHeader) {
    return {
      combinedBase64: Buffer.concat(wavBuffers).toString("base64"),
      durations,
    };
  }

  const pcmChunks = parsed.map((p) => p.pcmData);
  const totalPcmBytes = pcmChunks.reduce((sum, buf) => sum + buf.length, 0);

  const header = Buffer.alloc(44);
  firstValidHeader.copy(header, 0, 0, Math.min(36, firstValidHeader.length));
  header.write("RIFF", 0, 4, "ascii");
  header.writeUInt32LE(36 + totalPcmBytes, 4);
  header.write("WAVE", 8, 4, "ascii");
  header.write("data", 36, 4, "ascii");
  header.writeUInt32LE(totalPcmBytes, 40);

  const combined = Buffer.concat([header, ...pcmChunks]);
  return {
    combinedBase64: combined.toString("base64"),
    durations,
  };
}

async function synthesizeSceneSpeech(
  ai: GoogleGenAI,
  text: string,
  voiceName: string,
  styleHint: string,
  options: {
    signal?: AbortSignal;
    onRetry?: (info: {
      modelName: string;
      attempt: number;
      maxRetries: number;
      delayMs: number;
      httpStatus: number | null;
    }) => void;
    onFallback?: (info: {
      primaryModel: string;
      fallbackModel: string;
      reason: string;
    }) => void;
  } = {}
): Promise<{ buffer: Buffer; report: ModelUsageReport }> {
  const validVoices = ["Puck", "Charon", "Kore", "Fenrir", "Zephyr"];
  const chosenVoice = validVoices.includes(voiceName) ? voiceName : "Kore";
  const safeText = text.trim() || " ";

  const { result, report } = await runModelWithRetryAndFallback(
    ai,
    "tts",
    async (modelName) => {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: [
          {
            role: "user",
            parts: [
              {
                text: safeText,
                speechMetadata: {
                  style: styleHint,
                },
              },
            ],
          },
        ],
        config: {
          responseModalities: ["AUDIO"],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: chosenVoice },
            },
          },
        },
      });

      const parts = response.candidates?.[0]?.content?.parts ?? [];
      const audioPart = parts.find((p) => p.inlineData?.data);
      const base64Audio = audioPart?.inlineData?.data;
      if (!base64Audio) {
        throw new Error("Model TTS tidak mengembalikan data audio yang valid.");
      }
      const buf = Buffer.from(base64Audio, "base64");
      if (buf.length === 0) {
        throw new Error("Data audio TTS kosong.");
      }
      return buf;
    },
    options
  );

  return { buffer: result, report };
}

function normalizeLanguagePreference(raw: unknown): LanguagePreference {
  if (raw === "id-ID" || raw === "en-US" || raw === "auto") return raw;
  return "auto";
}

function buildTtsStyleHint(
  style: string,
  narration: string,
  languagePreference: LanguagePreference,
  overallLanguage: SupportedLanguage
): string {
  const sceneLang =
    languagePreference === "auto"
      ? overallLanguage === "mixed"
        ? detectTextLanguage(narration, "auto")
        : detectSentenceLanguage(
            narration,
            overallLanguage === "en-US" ? "en-US" : "id-ID"
          )
      : languagePreference;

  const toneSuffix =
    style === "newsroom-brief"
      ? "authoritative broadcast news anchor pacing"
      : style === "audio-pulse"
      ? "warm, rhythmic narrative storytelling cadence"
      : "crisp, clear documentary explainer pacing";

  if (sceneLang === "en-US") {
    return `Clear, natural American English narrator with ${toneSuffix}`;
  }
  if (sceneLang === "mixed") {
    return `Natural bilingual Indonesian and English narrator: speak Indonesian smoothly while pronouncing English technical terms in clear English, with ${toneSuffix}`;
  }
  return `Clear, natural Indonesian narrator with accurate pronunciation of any English terms and ${toneSuffix}`;
}

async function synthesizeScenesInBatches(
  ai: GoogleGenAI,
  narrations: string[],
  voiceName: string,
  style: string,
  options: {
    languagePreference?: LanguagePreference;
    overallLanguage?: SupportedLanguage;
    signal?: AbortSignal;
    onProgress?: (completed: number, total: number) => void;
    onRetry?: (info: {
      modelName: string;
      attempt: number;
      maxRetries: number;
      delayMs: number;
      httpStatus: number | null;
    }) => void;
    onFallback?: (info: {
      primaryModel: string;
      fallbackModel: string;
      reason: string;
    }) => void;
  } = {}
): Promise<{ buffers: Buffer[]; reports: ModelUsageReport[] }> {
  const results: Buffer[] = new Array(narrations.length);
  const reports: ModelUsageReport[] = [];
  let completed = 0;
  const langPref = options.languagePreference || "auto";
  const overallLang = options.overallLanguage || "id-ID";

  for (let i = 0; i < narrations.length; i++) {
    if (options.signal?.aborted) {
      throw new Error("Permintaan dibatalkan oleh pengguna.");
    }
    const perSceneStyleHint = buildTtsStyleHint(
      style,
      narrations[i],
      langPref,
      overallLang
    );
    const { buffer, report } = await synthesizeSceneSpeech(
      ai,
      narrations[i],
      voiceName,
      perSceneStyleHint,
      {
        signal: options.signal,
        onRetry: options.onRetry,
        onFallback: options.onFallback,
      }
    );
    results[i] = buffer;
    reports.push(report);
    completed += 1;
    options.onProgress?.(completed, narrations.length);
  }

  return { buffers: results, reports };
}

function summarizeModelReports(reports: ModelUsageReport[]): ModelUsageReport[] {
  const byKey = new Map<string, ModelUsageReport>();
  for (const r of reports) {
    const key = `${r.task}:${r.primaryModel}->${r.usedModel}`;
    if (!byKey.has(key)) {
      byKey.set(key, r);
    }
  }
  return Array.from(byKey.values());
}

interface ServerFailureDiagnostic {
  endpoint: string;
  failedStage: "storyboard" | "tts" | "transcription" | "validation" | "server";
  model: string;
  httpStatus: number | null;
  causeType: "rate_limit" | "quota_exhausted" | "server_error" | "network" | "validation";
  retryAfterSeconds?: number;
  quotaMetric?: string;
  detail?: string;
}

function formatGeminiError(
  err: unknown,
  context?: {
    endpoint: string;
    failedStage: ServerFailureDiagnostic["failedStage"];
    fallbackModel?: string;
  }
): {
  status: number;
  message: string;
  diagnostics: ServerFailureDiagnostic;
} {
  const details = extractErrorDetails(err);
  const { httpStatus, codeName, message, retryAfterSeconds, quotaMetric, causeType, rawDiagnosticSnippet } =
    details;
  const resolvedModel =
    getAttachedModel(err) || context?.fallbackModel || "unknown";

  const diagnostics: ServerFailureDiagnostic = {
    endpoint: context?.endpoint || "unknown",
    failedStage: context?.failedStage || "server",
    model: resolvedModel,
    httpStatus,
    causeType,
    ...(retryAfterSeconds ? { retryAfterSeconds } : {}),
    ...(quotaMetric ? { quotaMetric } : {}),
    detail: rawDiagnosticSnippet,
  };

  console.error(
    `[gemini-diagnostic] endpoint=${diagnostics.endpoint} stage=${diagnostics.failedStage} model=${diagnostics.model} status=${
      diagnostics.httpStatus ?? "none"
    } cause=${diagnostics.causeType} retryAfter=${
      diagnostics.retryAfterSeconds ?? "none"
    }s detail=${diagnostics.detail}`
  );

  if (httpStatus === 400 || codeName === "API_KEY_INVALID") {
    return {
      status: 400,
      message:
        "Permintaan atau kunci API Gemini tidak valid (400). Periksa GEMINI_API_KEY pada panel Settings > Secrets.",
      diagnostics,
    };
  }
  if (httpStatus === 401 || httpStatus === 403 || codeName === "PERMISSION_DENIED") {
    return {
      status: 403,
      message:
        "Akses API Gemini ditolak (403). Pastikan GEMINI_API_KEY aktif dan memiliki izin di panel Settings > Secrets.",
      diagnostics,
    };
  }
  if (httpStatus === 404 || codeName === "NOT_FOUND") {
    return {
      status: 404,
      message: `Model Gemini (${resolvedModel}) tidak ditemukan atau belum tersedia (404 NOT_FOUND).`,
      diagnostics,
    };
  }
  if (httpStatus === 429 || codeName === "RESOURCE_EXHAUSTED") {
    const stageLabel =
      diagnostics.failedStage === "tts"
        ? "sintesis suara (TTS)"
        : diagnostics.failedStage === "transcription"
        ? "transkripsi audio"
        : diagnostics.failedStage === "storyboard"
        ? "penyusunan storyboard"
        : "permintaan AI";
    const waitNote = retryAfterSeconds
      ? ` Tunggu sekitar ${retryAfterSeconds} detik lalu klik Coba Lagi.`
      : " Tunggu sebentar lalu klik Coba Lagi.";
    const causeNote =
      causeType === "quota_exhausted"
        ? `Kuota harian/limit Gemini API untuk ${stageLabel} (${resolvedModel}) telah habis (429).`
        : `Batas laju permintaan (rate limit) Gemini API pada ${stageLabel} (${resolvedModel}) tercapai (429).`;
    return {
      status: 429,
      message: `${causeNote}${waitNote}`,
      diagnostics,
    };
  }
  if (httpStatus === 503 || codeName === "UNAVAILABLE" || codeName === "SERVICE_UNAVAILABLE") {
    return {
      status: 503,
      message: `Layanan Gemini AI (${resolvedModel}) sedang padat atau tidak tersedia sementara (503 UNAVAILABLE). Silakan klik Coba Lagi beberapa saat lagi.`,
      diagnostics,
    };
  }
  if (httpStatus === 504 || codeName === "DEADLINE_EXCEEDED" || codeName === "GATEWAY_TIMEOUT") {
    return {
      status: 504,
      message: `Waktu tunggu respons server Gemini (${resolvedModel}) habis (504 Gateway Timeout). Silakan klik Coba Lagi.`,
      diagnostics,
    };
  }
  if (httpStatus === 502 || codeName === "BAD_GATEWAY") {
    return {
      status: 502,
      message:
        "Gangguan gerbang jaringan menuju layanan AI (502 Bad Gateway). Silakan klik Coba Lagi.",
      diagnostics,
    };
  }
  if (httpStatus === 500 || codeName === "INTERNAL") {
    return {
      status: 500,
      message: `Terjadi gangguan internal pada server Gemini AI (${resolvedModel}) (500). Silakan klik Coba Lagi.`,
      diagnostics,
    };
  }

  return {
    status: 500,
    message: message || "Terjadi kesalahan saat memproses permintaan AI.",
    diagnostics,
  };
}

const VALID_ASSET_KEYS = new Set<VisualAssetKey>([
  "projectile_bullet",
  "human_silhouette",
  "human_anatomy",
  "heart_organ",
  "brain_organ",
  "vehicle_car",
  "solar_planet",
  "earthquake_seismic",
  "tech_circuit",
  "ocean_marine",
  "energy_solar",
  "money_economy",
  "server_cyber",
  "data_network",
  "law_balance",
  "news_globe",
  "editorial_desk",
  "concept_diagram",
]);

const VALID_CAMERAS = new Set<VisualCameraMovement>([
  "static",
  "zoom_in",
  "zoom_out",
  "dolly_in",
  "orbit",
  "tilt_focus",
  "pan_left",
  "pan_right",
  "track_object",
]);

const VALID_ANIMATIONS = new Set<VisualAnimationType>([
  "trajectory",
  "pulse",
  "orbit",
  "shake_wave",
  "flow_stream",
  "scan_highlight",
  "scale_compare",
  "float_drift",
]);

const VALID_TRANSITIONS = new Set<SceneTransition>([
  "fade",
  "slide",
  "zoom",
  "whip",
  "morph",
  "depth",
  "none",
]);

const VALID_ENV_EFFECTS = new Set<EnvironmentalEffectType>([
  "ambient_dust",
  "blood_flow",
  "starfield_drift",
  "seismic_tremor",
  "data_streams",
  "ocean_bubbles",
  "energy_sparks",
  "shockwave_rings",
]);

const VALID_INTENSITIES = new Set<AnimationIntensity>([
  "subtle",
  "balanced",
  "cinematic",
]);

const VALID_TIMINGS = new Set<MotionTimingCurve>([
  "ease_in_out",
  "spring",
  "linear_flow",
  "dramatic_ramp",
]);

function inferServerSemanticVisualSpec(
  scene: RawSceneSchema,
  blueprintTitle: string
): {
  assetKey: VisualAssetKey;
  subject: string;
  action: string;
  environment: string;
  objects: string[];
  visualDescription: string;
  cameraMovement: VisualCameraMovement;
  animationType: VisualAnimationType;
  focusRegion?: string;
  objectMovement: string;
  secondaryAnimation: string;
  environmentalEffect: EnvironmentalEffectType;
  animationIntensity: AnimationIntensity;
  motionTiming: MotionTimingCurve;
  narrationSyncCue: string;
} {
  const text = `${scene.topTitle || ""} ${scene.topSubLabel || ""} ${
    scene.narration || ""
  }`.toLowerCase();
  const fullContext = `${text} ${blueprintTitle.toLowerCase()}`;

  if (
    /\b(peluru|proyektil|bullet|projectile|firearm|gunshot|senjata|tembak|balistik|ballistic|kaliber|caliber|velocity|muzzle)\b/i.test(
      text
    ) &&
    !/\b(tubuh|body|organ|jaringan|tissue|paru|lung|jantung|heart|dada|chest|otot|tulang|bone|korban|victim|penetrasi|penetrat)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "projectile_bullet",
      subject: "Ballistic Projectile",
      action: "Melaju berkecepatan tinggi dengan gelombang kejut",
      environment: "Lintasan uji balistik & vektor energi kinetik",
      objects: ["Proyektil aerodinamis", "Gelombang kejut Mach", "Vektor kecepatan"],
      visualDescription:
        "3D-shaded projectile accelerating with Mach shockwave cones and kinetic trails.",
      cameraMovement: "track_object",
      animationType: "trajectory",
      focusRegion: "Ujung Proyektil",
      objectMovement: "High-speed horizontal acceleration with spin & motion trail",
      secondaryAnimation: "Expanding shockwave cones and compressed air vortex particles",
      environmentalEffect: "shockwave_rings",
      animationIntensity: "cinematic",
      motionTiming: "dramatic_ramp",
      narrationSyncCue: "Accelerate projectile and shockwaves on kinetic emphasis",
    };
  }
  if (
    /\b(jantung|heart|cardiac|heartbeat|beating|detak|pulse|kardiovaskular|cardiovascular|pembuluh darah|artery|arterial|vein|blood flow|nadi|bpm)\b/i.test(
      text
    )
  ) {
    const isAccel = /\b(faster|accelerate|speed|rapid|lebih cepat|kencang|meningkat)\b/i.test(
      text
    );
    return {
      assetKey: "heart_organ",
      subject: "Organ Jantung / 3D Heart",
      action: isAccel
        ? "Berdetak semakin cepat dengan aliran darah deras"
        : "Memompa sirkulasi darah & ritme detak",
      environment: "Tampilan anatomi kardiovaskular edukatif",
      objects: ["Ruang jantung 3D", "Pembuluh aorta & arteri", "Gelombang EKG"],
      visualDescription:
        "Pulsing 3D-shaded heart with streaming blood corpuscles, ECG waveform, and pulsing halo.",
      cameraMovement: "dolly_in",
      animationType: "pulse",
      focusRegion: "Katup & Ruang Jantung",
      objectMovement: isAccel
        ? "Progressive heartbeat acceleration with volumetric squeeze"
        : "Rhythmic dual-phase cardiac pulse",
      secondaryAnimation: "Arterial blood particles streaming through vessels + live ECG",
      environmentalEffect: "blood_flow",
      animationIntensity: "cinematic",
      motionTiming: "spring",
      narrationSyncCue: "Sync cardiac pulse rate and dolly push-in with beat intensity",
    };
  }
  if (
    /\b(otak|brain|saraf|nerve|neural|neuron|synapse|kognitif|cognitive|memori|memory|kesadaran|consciousness|kepala|mental)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "brain_organ",
      subject: "Otak & Sistem Saraf",
      action: "Mengirimkan impuls sinaptik aktif",
      environment: "Diagram neurologis edukatif",
      objects: ["Hemisfer otak", "Simpul saraf", "Sinyal sinaps bercahaya"],
      visualDescription:
        "Animated cerebral hemispheres with cascading synaptic impulses and glowing nodes.",
      cameraMovement: "dolly_in",
      animationType: "scan_highlight",
      focusRegion: "Korteks & Saraf",
      objectMovement: "Gentle floating cortex with propagating neural pulses",
      secondaryAnimation: "Cascading synaptic sparks and signal arcs",
      environmentalEffect: "data_streams",
      animationIntensity: "cinematic",
      motionTiming: "ease_in_out",
      narrationSyncCue: "Illuminate neural nodes sequentially with narration",
    };
  }
  if (
    /\b(anatomi|anatomy|organ|paru|lung|dada|chest|perut|abdomen|tulang|bone|rusuk|rib|jaringan|tissue|pembuluh|internal|penetrasi|penetrat|kavitasi|cavitation|trauma|wound)\b/i.test(
      text
    ) ||
    (/\b(dampak|akibat|impact|effect|energi kinetik|kinetic|gelombang tekan|shockwave)\b/i.test(
      text
    ) &&
      /\b(peluru|bullet|tubuh|body|manusia|human)\b/i.test(fullContext))
  ) {
    return {
      assetKey: "human_anatomy",
      subject: "Anatomi Tubuh Manusia",
      action: "Menyorot zona organ terdampak secara edukatif",
      environment: "Diagram pemindaian medis edukatif",
      objects: ["Rangka dada", "Zona organ", "Penanda fokus"],
      visualDescription:
        "Educational anatomical cross-section with scanning highlight beam and pulsing focus marker.",
      cameraMovement: "dolly_in",
      animationType: "scan_highlight",
      focusRegion: "Zona Organ Terdampak",
      objectMovement: "Layered torso breathing motion with laser depth scan",
      secondaryAnimation: "Pulsing organ callout rings and circulating blood motes",
      environmentalEffect: "blood_flow",
      animationIntensity: "cinematic",
      motionTiming: "ease_in_out",
      narrationSyncCue: "Sweep scan line toward focus region as explanation deepens",
    };
  }
  if (
    /\b(tubuh|body|manusia|human|fisik|physical|postur|posture|seseorang|person|korban|victim|pasien|patient)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "human_silhouette",
      subject: "Siluet Tubuh Manusia",
      action: "Menunjukkan bagian tubuh dan titik pengaruh energi",
      environment: "Pemetaan proporsi tubuh edukatif",
      objects: ["Siluet tubuh 2.5D", "Garis sumbu", "Cincin target fokus"],
      visualDescription:
        "Human figure silhouette with orbital target rings and directional kinetic vector.",
      cameraMovement: "tilt_focus",
      animationType: "scan_highlight",
      focusRegion: "Area Tubuh Utama",
      objectMovement: "Subtle breathing stance with concentric target tracking",
      secondaryAnimation: "Directional trajectory vector and expanding target halo",
      environmentalEffect: "ambient_dust",
      animationIntensity: "balanced",
      motionTiming: "spring",
      narrationSyncCue: "Lock focus ring onto body zone as narration introduces subject",
    };
  }
  if (/\b(peluru|proyektil|bullet|projectile)\b/i.test(text)) {
    return {
      assetKey: "projectile_bullet",
      subject: "Proyektil Peluru",
      action: "Menunjukkan lintasan dan energi tumbukan",
      environment: "Simulasi lintasan balistik",
      objects: ["Proyektil", "Garis lintasan", "Gelombang energi"],
      visualDescription: "Ilustrasi proyektil bergerak dengan gelombang energi.",
      cameraMovement: "track_object",
      animationType: "trajectory",
      focusRegion: "Lintasan Proyektil",
      objectMovement: "Linear high-velocity ballistic glide",
      secondaryAnimation: "Shockwave pressure waves trailing tip",
      environmentalEffect: "shockwave_rings",
      animationIntensity: "cinematic",
      motionTiming: "dramatic_ramp",
      narrationSyncCue: "Follow projectile speed along trajectory",
    };
  }
  if (
    /\b(planet|tata surya|solar system|matahari|sun|bumi|earth|mars|jupiter|saturn|saturnus|orbit|antariksa|space|galaksi|galaxy|bulan|moon|bintang|star|astronomi|astronomy)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "solar_planet",
      subject: "Planet & Tata Surya",
      action: "Mengorbit bintang pusat di jalur elips",
      environment: "Ruang angkasa berlatar bintang parallax",
      objects: ["Bintang pusat", "Planet bercincin", "Jalur orbit elips"],
      visualDescription: "Dynamic orbital planetary system with drifting deep-space starfield.",
      cameraMovement: "orbit",
      animationType: "orbit",
      focusRegion: "Jalur Orbit Planet",
      objectMovement: "Continuous multi-speed Keplerian elliptical orbits",
      secondaryAnimation: "Solar corona glow and drifting background starfield",
      environmentalEffect: "starfield_drift",
      animationIntensity: "cinematic",
      motionTiming: "linear_flow",
      narrationSyncCue: "Orbit camera smoothly around central star",
    };
  }
  if (
    /\b(gempa|earthquake|seismik|seismic|tektonik|tectonic|lempeng|plate|getaran|tremor|magnitudo|magnitude|reruntuhan|bangunan|building|tsunami|patahan|fault)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "earthquake_seismic",
      subject: "Bangunan & Getaran Tanah",
      action: "Menerima gelombang seismik dari patahan tanah",
      environment: "Penampang lapisan tanah & gedung",
      objects: ["Gedung bertingkat", "Gelombang seismik", "Garis patahan aktif"],
      visualDescription:
        "Architectural structures swaying atop fault strata with radiating seismic waves.",
      cameraMovement: "pan_left",
      animationType: "shake_wave",
      focusRegion: "Episentrum & Patahan",
      objectMovement: "Harmonic structural sway proportional to tremor intensity",
      secondaryAnimation: "Expanding concentric P/S waves & rising dust particles",
      environmentalEffect: "seismic_tremor",
      animationIntensity: "cinematic",
      motionTiming: "spring",
      narrationSyncCue: "Amplify ground waves on seismic energy words",
    };
  }
  if (
    /\b(mobil|car|vehicle|kendaraan|otomotif|automotive|transportasi|transportation|jalan raya|road|mesin|engine|traffic|aerodynamic)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "vehicle_car",
      subject: "Kendaraan Mobil",
      action: "Melaju di lintasan dengan aliran aerodinamis",
      environment: "Jalan raya & indikator kecepatan",
      objects: ["Mobil aerodinamis", "Roda berputar", "Garis aliran angin"],
      visualDescription: "Streamlined vehicle cruising smoothly with spinning wheels and airflow.",
      cameraMovement: "track_object",
      animationType: "trajectory",
      focusRegion: "Bodi & Penggerak",
      objectMovement: "Dynamic suspension bounce with high-RPM wheel rotation",
      secondaryAnimation: "Scrolling lane dashes & aerodynamic airflow ribbons",
      environmentalEffect: "shockwave_rings",
      animationIntensity: "cinematic",
      motionTiming: "ease_in_out",
      narrationSyncCue: "Match wheel & airflow velocity with speed narration",
    };
  }
  if (
    /\b(laut|ocean|sea|samudra|ombak|wave|gelombang laut|bawah laut|underwater|ikan|fish|terumbu karang|coral|ekosistem laut|marine)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "ocean_marine",
      subject: "Laut & Kehidupan Bawah Air",
      action: "Ombak bergulung dan biota berenang bebas",
      environment: "Permukaan ombak & dasar laut",
      objects: ["Gelombang permukaan", "Ikan berenang", "Terumbu & gelembung"],
      visualDescription:
        "Layered ocean depths with rolling surface swells, sunbeams, bubbles, and marine life.",
      cameraMovement: "pan_right",
      animationType: "float_drift",
      focusRegion: "Ekosistem Laut",
      objectMovement: "Fluid sinusoidal wave oscillation and swimming marine paths",
      secondaryAnimation: "Rising air bubbles & shimmering underwater light shafts",
      environmentalEffect: "ocean_bubbles",
      animationIntensity: "balanced",
      motionTiming: "linear_flow",
      narrationSyncCue: "Drift smoothly alongside swimming marine life",
    };
  }
  if (
    /\b(energi surya|solar energy|solar panel|panel surya|tenaga surya|baterai|battery|listrik bersih|renewable|electricity)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "energy_solar",
      subject: "Panel Surya & Energi",
      action: "Mengubah sinar matahari menjadi daya listrik",
      environment: "Area pembangkit energi bersih",
      objects: ["Panel fotovoltaik", "Aliran foton matahari", "Unit baterai"],
      visualDescription:
        "Solar array absorbing photon streams and charging an animated power cell.",
      cameraMovement: "dolly_in",
      animationType: "flow_stream",
      focusRegion: "Sel Fotovoltaik",
      objectMovement: "Rising charge bar & rhythmic solar array reflection",
      secondaryAnimation: "Streaming photon particles and rising energy sparks",
      environmentalEffect: "energy_sparks",
      animationIntensity: "cinematic",
      motionTiming: "ease_in_out",
      narrationSyncCue: "Pulse photon transfer as conversion rate is explained",
    };
  }
  if (
    /\b(teknologi|technology|komputer|computer|chip|microchip|mikroprosesor|processor|sirkuit|circuit|robot|perangkat|device|gadget|ai|algoritma|algorithm|sensor|digital)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "tech_circuit",
      subject: "Perangkat & Sirkuit Teknologi",
      action: "Memproses sinyal digital lewat jalur sirkuit",
      environment: "Papan sirkuit & modul komputasi",
      objects: ["Chip prosesor inti", "Jalur sirkuit aktif", "Pulsa data digital"],
      visualDescription:
        "Microprocessor core dispatching illuminated data packets across circuit traces.",
      cameraMovement: "dolly_in",
      animationType: "flow_stream",
      focusRegion: "Prosesor Inti",
      objectMovement: "Glowing core chip pulse with synchronized trace packets",
      secondaryAnimation: "Cascading digital data streams across background",
      environmentalEffect: "data_streams",
      animationIntensity: "cinematic",
      motionTiming: "spring",
      narrationSyncCue: "Accelerate circuit data pulses during processing explanation",
    };
  }
  if (
    /\b(server|data negara|ransomware|pdn|keamanan siber|cybersecurity|firewall|cloud)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "server_cyber",
      subject: "Server & Radar Keamanan",
      action: "Memindai ancaman jaringan 24 jam",
      environment: "Pusat data dengan radar pemantauan",
      objects: ["Rak server", "Radar pemindai", "Terminal status"],
      visualDescription: "Data center racks paired with live sweeping security radar.",
      cameraMovement: "tilt_focus",
      animationType: "scan_highlight",
      focusRegion: "Pemindaian Keamanan",
      objectMovement: "360-degree radar sweep across security perimeter",
      secondaryAnimation: "Server LED telemetry blink & background data streams",
      environmentalEffect: "data_streams",
      animationIntensity: "balanced",
      motionTiming: "linear_flow",
      narrationSyncCue: "Highlight security nodes as threat status is described",
    };
  }
  if (
    scene.archetype === "network_graph" ||
    /\b(jaringan|network|klaster|cluster|simpul|node|koneksi|connection|peta relasi)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "data_network",
      subject: "Jaringan & Klaster Data",
      action: "Menghubungkan simpul dan mendeteksi pola otomatis",
      environment: "Grafik simpul jaringan terhubung",
      objects: ["Simpul pusat", "Jalur koneksi", "Klaster aktif"],
      visualDescription: "Connected node network lighting up automated clusters.",
      cameraMovement: "zoom_out",
      animationType: "flow_stream",
      focusRegion: "Pola Koneksi Data",
      objectMovement: "Nodes breathing gently with traveling packet pulses",
      secondaryAnimation: "Dynamic link illumination & vertical data streams",
      environmentalEffect: "data_streams",
      animationIntensity: "balanced",
      motionTiming: "spring",
      narrationSyncCue: "Reveal outer network clusters progressively",
    };
  }
  if (
    /\b(rupiah|uang|money|anggaran|budget|tender|ekonomi|economy|transaksi|transaction|qris|umkm|miliar|billion|triliun|trillion|dollar|revenue|profit)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "money_economy",
      subject: "Aliran Ekonomi & Transaksi",
      action: "Menggambarkan nilai dan pertumbuhan ekonomi",
      environment: "Grafik keuangan & arus transaksi",
      objects: ["Grafik nilai bertumbuh", "Koin mengambang", "Indikator tren"],
      visualDescription: "Animated financial bar growth with floating currency indicators.",
      cameraMovement: "dolly_in",
      animationType: "scale_compare",
      focusRegion: "Volume Nilai",
      objectMovement: "Staggered bar rise with buoyant coin drift",
      secondaryAnimation: "Rising value sparks & luminous ambient backdrop",
      environmentalEffect: "energy_sparks",
      animationIntensity: "cinematic",
      motionTiming: "spring",
      narrationSyncCue: "Peak bar growth on numeric data mention",
    };
  }
  if (
    /\b(negara|country|dunia|world|global|wilayah|region|kota|city|indonesia|singapura|singapore|brasil|brazil|albania|berita|news)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "news_globe",
      subject: "Peta Wilayah & Lokasi",
      action: "Menandai wilayah studi kasus global",
      environment: "Peta geografis regional",
      objects: ["Pin lokasi berdenyut", "Siluet wilayah", "Kartu berita"],
      visualDescription: "Regional map spotlighting key location pins and news context.",
      cameraMovement: "pan_right",
      animationType: "pulse",
      focusRegion: "Lokasi Studi Kasus",
      objectMovement: "Pulsing radar location beacon across map coordinates",
      secondaryAnimation: "Drifting atmospheric particles & connecting grid lines",
      environmentalEffect: "ambient_dust",
      animationIntensity: "balanced",
      motionTiming: "ease_in_out",
      narrationSyncCue: "Focus camera pan onto regional beacon",
    };
  }
  if (
    /\b(kantor|office|meja|desk|kursi|chair|rapat|meeting|birokrasi|bureaucracy|wakil presiden|wapres|vice president|menteri|minister|kabinet|cabinet|pemerintah|government|regulasi|regulation|tender|undang|law|policy)\b/i.test(
      fullContext
    )
  ) {
    return {
      assetKey: scene.archetype === "balance_verdict" ? "law_balance" : "editorial_desk",
      subject: scene.archetype === "balance_verdict" ? "Timbangan Keputusan" : "Meja Kebijakan",
      action: "Menelaah kebijakan dan dokumen",
      environment: "Ruang kerja editorial & kebijakan",
      objects: ["Dokumen", "Monitor", "Indikator"],
      visualDescription: "Ilustrasi meja editorial analisis kebijakan.",
      cameraMovement: "tilt_focus",
      animationType: "float_drift",
      objectMovement: "Subtle desk parallax with glowing monitor & swinging scales",
      secondaryAnimation: "Soft ambient dust particles & warm desk lamp glow",
      environmentalEffect: "ambient_dust",
      animationIntensity: "balanced",
      motionTiming: "ease_in_out",
      narrationSyncCue: "Gentle focus shift across policy desk elements",
    };
  }

  return {
    assetKey: "concept_diagram",
    subject: scene.topTitle || blueprintTitle || "Konsep Utama",
    action: "Memetakan hubungan antar-unsur dalam narasi",
    environment: "Diagram explainer edukatif",
    objects:
      scene.bullets && scene.bullets.length > 0
        ? scene.bullets.slice(0, 3)
        : [scene.topSubLabel || "Faktor Utama", scene.calloutBadge || "Proses", "Dampak"],
    visualDescription: `Multi-layered animated explainer diagram illustrating "${scene.topTitle}".`,
    cameraMovement: "dolly_in",
    animationType: "scan_highlight",
    focusRegion: scene.topHighlightWord || "Inti Pembahasan",
    objectMovement: "Spring-pop central hub with orbiting data pulses",
    secondaryAnimation: "Streaming connector dots and ambient atmospheric particles",
    environmentalEffect: "ambient_dust",
    animationIntensity: "cinematic",
    motionTiming: "spring",
    narrationSyncCue: "Illuminate connected concept nodes progressively",
  };
}

function normalizeSceneVisualSpec(
  rawSpec: RawSceneVisualSpec | undefined,
  scene: RawSceneSchema,
  blueprintTitle: string
) {
  const inferred = inferServerSemanticVisualSpec(scene, blueprintTitle);
  const sceneText = `${scene.topTitle} ${scene.narration}`.toLowerCase();
  const fullContext = `${blueprintTitle} ${sceneText}`.toLowerCase();
  const isOfficePolicyTopic =
    /\b(kantor|office|meja|desk|rapat|meeting|birokrasi|bureaucracy|wakil presiden|wapres|vice president|menteri|minister|kabinet|cabinet|pemerintah|government|regulasi|regulation|tender|pejabat|korupsi|administrasi)\b/i.test(
      fullContext
    );

  const isMedicalOrHumanContext =
    /\b(tubuh|body|manusia|human|organ|jantung|heart|otak|brain|paru|lung|dada|chest|darah|blood|medis|medical|anatomi|anatomy|saraf|nerve|trauma|korban|pasien|patient|life|lives|jiwa|nyawa)\b/i.test(
      fullContext
    );
  const isTechContext =
    /\b(teknologi|technology|komputer|computer|chip|microchip|sirkuit|circuit|robot|perangkat|device|ai|algoritma|algorithm|sensor|digital|software|cyber|server|damper|engineering)\b/i.test(
      sceneText
    );

  let chosenKey: VisualAssetKey = inferred.assetKey;
  if (
    rawSpec?.assetKey &&
    VALID_ASSET_KEYS.has(rawSpec.assetKey as VisualAssetKey)
  ) {
    const candidate = rawSpec.assetKey as VisualAssetKey;
    if (candidate === "editorial_desk" && !isOfficePolicyTopic) {
      chosenKey =
        inferred.assetKey === "editorial_desk"
          ? "concept_diagram"
          : inferred.assetKey;
    } else if (
      (candidate === "human_anatomy" ||
        candidate === "heart_organ" ||
        candidate === "brain_organ") &&
      !isMedicalOrHumanContext
    ) {
      chosenKey = inferred.assetKey;
    } else if (
      candidate === "tech_circuit" &&
      !isTechContext &&
      inferred.assetKey !== "concept_diagram"
    ) {
      chosenKey = inferred.assetKey;
    } else if (
      inferred.assetKey === "earthquake_seismic" &&
      candidate === "human_anatomy" &&
      !/\b(jantung|heart|otak|brain|paru|lung|organ|anatomi|anatomy)\b/i.test(sceneText)
    ) {
      chosenKey = "earthquake_seismic";
    } else {
      chosenKey = candidate;
    }
  }

  const cameraMovement: VisualCameraMovement =
    rawSpec?.cameraMovement &&
    VALID_CAMERAS.has(rawSpec.cameraMovement as VisualCameraMovement)
      ? (rawSpec.cameraMovement as VisualCameraMovement)
      : inferred.cameraMovement;

  const animationType: VisualAnimationType =
    rawSpec?.animationType &&
    VALID_ANIMATIONS.has(rawSpec.animationType as VisualAnimationType)
      ? (rawSpec.animationType as VisualAnimationType)
      : inferred.animationType;

  const environmentalEffect: EnvironmentalEffectType =
    rawSpec?.environmentalEffect &&
    VALID_ENV_EFFECTS.has(rawSpec.environmentalEffect as EnvironmentalEffectType)
      ? (rawSpec.environmentalEffect as EnvironmentalEffectType)
      : defaultEnvironmentalEffectForAsset(chosenKey);

  const animationIntensity: AnimationIntensity =
    rawSpec?.animationIntensity &&
    VALID_INTENSITIES.has(rawSpec.animationIntensity as AnimationIntensity)
      ? (rawSpec.animationIntensity as AnimationIntensity)
      : inferred.animationIntensity;

  const motionTiming: MotionTimingCurve =
    rawSpec?.motionTiming &&
    VALID_TIMINGS.has(rawSpec.motionTiming as MotionTimingCurve)
      ? (rawSpec.motionTiming as MotionTimingCurve)
      : inferred.motionTiming;

  const objects =
    Array.isArray(rawSpec?.objects) && rawSpec.objects.filter(Boolean).length > 0
      ? rawSpec.objects.map((o) => String(o).trim()).filter(Boolean).slice(0, 4)
      : inferred.objects;

  return {
    assetKey: chosenKey,
    subject: rawSpec?.subject?.trim() || inferred.subject,
    action: rawSpec?.action?.trim() || inferred.action,
    environment: rawSpec?.environment?.trim() || inferred.environment,
    objects,
    visualDescription:
      rawSpec?.visualDescription?.trim() || inferred.visualDescription,
    cameraMovement,
    animationType,
    focusRegion: rawSpec?.focusRegion?.trim() || inferred.focusRegion,
    objectMovement: rawSpec?.objectMovement?.trim() || inferred.objectMovement,
    secondaryAnimation:
      rawSpec?.secondaryAnimation?.trim() || inferred.secondaryAnimation,
    environmentalEffect,
    animationIntensity,
    motionTiming,
    narrationSyncCue:
      rawSpec?.narrationSyncCue?.trim() || inferred.narrationSyncCue,
  };
}

function normalizeBlueprint(
  raw: RawBlueprintSchema,
  style: string,
  aspectRatio: string,
  brandHandle: string,
  sourceMode: "text" | "audio",
  voiceName: string | undefined,
  durations: number[],
  transcript?: string,
  audioMode?: "ai-narration" | "no-audio" | "uploaded-audio",
  languagePreference: LanguagePreference = "auto"
): VideoBlueprint {
  let cursor = 0;
  const resolvedAudioMode =
    audioMode || (sourceMode === "audio" ? "uploaded-audio" : "ai-narration");
  const titleText = raw.title || "Video Explainer Otomatis";

  const scenes = (raw.scenes || []).map((s, idx) => {
    const dur = Number(
      (durations[idx] ?? s.estimatedSeconds ?? 4.8).toFixed(2)
    );
    const startTime = Number(cursor.toFixed(2));
    cursor += dur;
    const endTime = Number(cursor.toFixed(2));
    const sceneVisualSpec = normalizeSceneVisualSpec(
      s.sceneVisualSpec,
      s,
      titleText
    );
    const transition: SceneTransition =
      s.transition && VALID_TRANSITIONS.has(s.transition as SceneTransition)
        ? (s.transition as SceneTransition)
        : idx === 0
        ? "depth"
        : (["morph", "slide", "zoom", "whip", "depth", "fade"] as SceneTransition[])[
            idx % 6
          ];

    return {
      id: `scene-${idx + 1}`,
      archetype: s.archetype || "kinetic_statement",
      transition,
      topTitle: s.topTitle || titleText || `Adegan ${idx + 1}`,
      topHighlightWord: s.topHighlightWord || "",
      topSubLabel: s.topSubLabel || "",
      narration: s.narration || "",
      durationSeconds: dur,
      startTime,
      endTime,
      calloutBadge: s.calloutBadge,
      sceneVisualSpec,
      visualMetric: s.visualMetric,
      tableRow: s.tableRow,
      newsCard: s.newsCard,
      bullets: s.bullets,
    };
  });

  const cols: [string, string, string] = [
    raw.tableColumns?.[0] || "Aspek",
    raw.tableColumns?.[1] || "Proses",
    raw.tableColumns?.[2] || "Dampak",
  ];

  const assembled: VideoBlueprint = {
    id: `proj-${Date.now()}`,
    title: titleText,
    subjectNameplate: (raw.subjectNameplate || "TOPIK UTAMA").toUpperCase(),
    brandHandle: brandHandle || "@IZZY.STUDIO",
    tableColumns: cols,
    style: style as VideoStyleId,
    aspectRatio: aspectRatio as AspectRatio,
    totalDuration: Number(cursor.toFixed(2)),
    sourceMode,
    audioMode: resolvedAudioMode,
    languagePreference,
    voiceName: voiceName as VoiceName | undefined,
    transcript,
    scenes,
  };

  // Run automated Quality Control (language tagging, sentence sync segments, multi-layer density & transitions)
  return runBlueprintQualityControl(assembled);
}

function attachRequestAbortSignal(_req: Request, res: Response): AbortSignal {
  const controller = new AbortController();
  const handleClose = () => {
    if (!res.writableFinished && !res.writableEnded) {
      controller.abort();
    }
  };
  res.on("close", handleClose);
  res.on("finish", () => {
    res.off("close", handleClose);
  });
  return controller.signal;
}

const SUPPORTED_TRANSCRIBE_MIMES = new Set([
  "audio/wav",
  "audio/mp3",
  "audio/aiff",
  "audio/aac",
  "audio/ogg",
  "audio/flac",
  "audio/mpeg",
  "audio/m4a",
  "audio/l16",
  "audio/opus",
  "audio/alaw",
  "audio/mulaw",
  "audio/webm",
]);

const MIME_ALIAS_MAP: Record<string, string> = {
  "audio/x-wav": "audio/wav",
  "audio/wave": "audio/wav",
  "audio/vnd.wave": "audio/wav",
  "audio/mpeg3": "audio/mp3",
  "audio/x-mpeg-3": "audio/mp3",
  "audio/x-mp3": "audio/mp3",
  "audio/mpeg": "audio/mp3",
  "audio/x-m4a": "audio/m4a",
  "audio/mp4": "audio/m4a",
  "audio/mp4a-latm": "audio/m4a",
  "audio/x-aac": "audio/aac",
  "audio/x-flac": "audio/flac",
  "audio/vorbis": "audio/ogg",
  "audio/x-ogg": "audio/ogg",
  "video/webm": "audio/webm",
};

const INLINE_AUDIO_THRESHOLD_BYTES = 4 * 1024 * 1024;
const MAX_AUDIO_UPLOAD_BYTES = 22 * 1024 * 1024;

interface ValidatedAudioPayload {
  cleanBase64: string;
  buffer: Buffer;
  normalizedMimeType: string;
}

class AudioValidationError extends Error {
  status = 400;
}

function validateAndNormalizeAudioInput(
  rawBase64: unknown,
  rawMimeType: unknown
): ValidatedAudioPayload {
  if (typeof rawBase64 !== "string" || !rawBase64.trim()) {
    throw new AudioValidationError("Data audio tidak ditemukan.");
  }

  let detectedDataUriMime: string | null = null;
  let base64Body = rawBase64.trim();
  const dataUriMatch = base64Body.match(/^data:([^;]+);base64,(.*)$/is);
  if (dataUriMatch) {
    detectedDataUriMime = dataUriMatch[1];
    base64Body = dataUriMatch[2];
  }
  const cleanBase64 = base64Body.replace(/\s+/g, "");

  if (!cleanBase64 || cleanBase64.length % 4 === 1 || !/^[A-Za-z0-9+/=]+$/.test(cleanBase64)) {
    throw new AudioValidationError(
      "Encoding data audio tidak valid (bukan base64 yang utuh)."
    );
  }

  const rawMimeCandidate =
    typeof rawMimeType === "string" && rawMimeType.trim()
      ? rawMimeType
      : detectedDataUriMime || "audio/webm";
  const baseMime = rawMimeCandidate.split(";")[0].trim().toLowerCase();
  const normalizedMimeType = MIME_ALIAS_MAP[baseMime] || baseMime;

  if (!SUPPORTED_TRANSCRIBE_MIMES.has(normalizedMimeType)) {
    throw new AudioValidationError(
      `Format MIME audio "${rawMimeCandidate}" tidak didukung. Gunakan WAV, MP3, WebM, OGG, M4A, AAC, FLAC, atau AIFF.`
    );
  }

  const buffer = Buffer.from(cleanBase64, "base64");
  if (buffer.length < 128) {
    throw new AudioValidationError(
      `Berkas audio terlalu pendek atau kosong (${buffer.length} byte). Rekam minimal 1 detik suara yang jelas.`
    );
  }
  if (buffer.length > MAX_AUDIO_UPLOAD_BYTES) {
    throw new AudioValidationError(
      `Ukuran data audio melebihi batas 22 MB (${(buffer.length / (1024 * 1024)).toFixed(1)} MB).`
    );
  }

  // Verify container magic bytes where signature is well-defined
  if (normalizedMimeType === "audio/wav") {
    const riff = buffer.subarray(0, 4).toString("ascii");
    const wave = buffer.subarray(8, 12).toString("ascii");
    if (riff !== "RIFF" || wave !== "WAVE") {
      throw new AudioValidationError(
        "Header file WAV tidak valid (diharapkan RIFF/WAVE). Pastikan file audio tidak rusak."
      );
    }
  } else if (normalizedMimeType === "audio/webm") {
    if (
      buffer[0] !== 0x1a ||
      buffer[1] !== 0x45 ||
      buffer[2] !== 0xdf ||
      buffer[3] !== 0xa3
    ) {
      throw new AudioValidationError(
        "Header file WebM tidak valid (EBML signature tidak ditemukan)."
      );
    }
  } else if (normalizedMimeType === "audio/ogg") {
    if (buffer.subarray(0, 4).toString("ascii") !== "OggS") {
      throw new AudioValidationError("Header file OGG tidak valid (diharapkan OggS).");
    }
  } else if (normalizedMimeType === "audio/flac") {
    if (buffer.subarray(0, 4).toString("ascii") !== "fLaC") {
      throw new AudioValidationError("Header file FLAC tidak valid.");
    }
  } else if (normalizedMimeType === "audio/m4a") {
    if (buffer.subarray(4, 8).toString("ascii") !== "ftyp") {
      throw new AudioValidationError("Header kontainer M4A/MP4 tidak valid.");
    }
  } else if (normalizedMimeType === "audio/aiff") {
    if (buffer.subarray(0, 4).toString("ascii") !== "FORM") {
      throw new AudioValidationError("Header file AIFF tidak valid.");
    }
  } else if (normalizedMimeType === "audio/mp3") {
    const isId3 = buffer.subarray(0, 3).toString("ascii") === "ID3";
    const isFrameSync = buffer[0] === 0xff && (buffer[1] & 0xe0) === 0xe0;
    if (!isId3 && !isFrameSync) {
      throw new AudioValidationError("Header frame MP3/ID3 tidak valid.");
    }
  }

  return { cleanBase64, buffer, normalizedMimeType };
}

function extractInteractionOutputText(interaction: unknown): string {
  const ix = interaction as
    | {
        output_text?: string | null;
        outputs?: Array<{ type?: string; text?: string }>;
        steps?: Array<{
          type?: string;
          content?: Array<{ type?: string; text?: string }>;
        }>;
      }
    | undefined;

  if (!ix) return "";
  if (typeof ix.output_text === "string" && ix.output_text.trim()) {
    return ix.output_text.trim();
  }
  if (Array.isArray(ix.outputs)) {
    const joined = ix.outputs
      .filter((o) => o?.type === "text" && typeof o.text === "string")
      .map((o) => o.text ?? "")
      .join("")
      .trim();
    if (joined) return joined;
  }
  if (Array.isArray(ix.steps)) {
    const joined = ix.steps
      .filter((s) => s?.type === "model_output")
      .flatMap((s) => s.content ?? [])
      .filter((c) => c?.type === "text" && typeof c.text === "string")
      .map((c) => c.text ?? "")
      .join("")
      .trim();
    if (joined) return joined;
  }
  return "";
}

async function uploadAudioToFilesApi(
  ai: GoogleGenAI,
  audio: ValidatedAudioPayload,
  signal?: AbortSignal
): Promise<{ uri: string; name: string; mimeType: string }> {
  const ext = audio.normalizedMimeType.split("/")[1] || "bin";
  const blob = new Blob([new Uint8Array(audio.buffer)], {
    type: audio.normalizedMimeType,
  });
  const uploaded = await ai.files.upload({
    file: blob,
    config: {
      mimeType: audio.normalizedMimeType,
      displayName: `izzy-audio-${Date.now()}.${ext}`,
      abortSignal: signal,
    },
  });

  if (!uploaded.uri || !uploaded.name) {
    throw new Error("Gagal mengunggah berkas audio ke Gemini Files API.");
  }

  let currentFile = uploaded;
  let attempts = 0;
  while (currentFile.state === "PROCESSING" && attempts < 15) {
    await sleepWithAbort(1000, signal);
    currentFile = await ai.files.get({ name: uploaded.name });
    attempts += 1;
  }

  if (currentFile.state === "FAILED") {
    throw new Error(
      `Pemrosesan file audio di Gemini Files API gagal: ${
        currentFile.error?.message || "FAILED"
      }`
    );
  }

  return {
    uri: currentFile.uri || uploaded.uri,
    name: currentFile.name || uploaded.name,
    mimeType: currentFile.mimeType || audio.normalizedMimeType,
  };
}

interface TranscriptionDiagnosticResult {
  transcript: string;
  apiMethod: "interactions.create" | "models.generateContent";
  usedFilesApi: boolean;
  normalizedMimeType: string;
  audioBytes: number;
}

async function transcribeWithModel(
  ai: GoogleGenAI,
  modelName: string,
  audio: ValidatedAudioPayload,
  signal?: AbortSignal,
  languagePreference: LanguagePreference = "auto"
): Promise<TranscriptionDiagnosticResult> {
  const useFilesApi = audio.buffer.length > INLINE_AUDIO_THRESHOLD_BYTES;
  let uploadedFileName: string | null = null;

  const langDirective =
    languagePreference === "id-ID"
      ? "The primary spoken language is Indonesian (or code-switched Indonesian with technical terms). Transcribe accurately verbatim in its original words without translating."
      : languagePreference === "en-US"
      ? "The primary spoken language is English. Transcribe accurately verbatim in English without translating."
      : "Auto-detect the spoken language(s) (Indonesian, English, or mixed Indonesian+English code-switching). Transcribe verbatim in the exact spoken words and original language(s) without translating.";

  try {
    let uploaded: { uri: string; name: string; mimeType: string } | null = null;
    if (useFilesApi) {
      uploaded = await uploadAudioToFilesApi(ai, audio, signal);
      uploadedFileName = uploaded.name;
    }

    if (modelName === "gemini-3.5-transcribe") {
      // Official Gemini Interactions API transcription pattern
      const audioInput = uploaded
        ? {
            type: "audio" as const,
            uri: uploaded.uri,
            mime_type: uploaded.mimeType,
          }
        : {
            type: "audio" as const,
            data: audio.cleanBase64,
            mime_type: audio.normalizedMimeType,
          };

      const interaction = await ai.interactions.create({
        model: "gemini-3.5-transcribe",
        input: [
          audioInput,
          {
            type: "text",
            text: `${langDirective} Return only the spoken transcript words without commentary.`,
          },
        ],
        store: false,
      });

      const extractedText = extractInteractionOutputText(interaction);
      if (!extractedText) {
        const ixStatus = (interaction as { status?: string })?.status ?? "UNKNOWN";
        const detail = `status=${ixStatus}, mime=${audio.normalizedMimeType}, bytes=${audio.buffer.length}, filesApi=${useFilesApi}`;
        console.warn(
          `[transcription] Empty output from ${modelName} via interactions.create (${detail})`
        );
        const err = new Error(
          `Transkripsi ${modelName} menghasilkan output kosong (${detail}).`
        ) as Error & { code?: string };
        err.code = "EMPTY_MODEL_OUTPUT";
        throw err;
      }

      return {
        transcript: extractedText,
        apiMethod: "interactions.create",
        usedFilesApi: useFilesApi,
        normalizedMimeType: audio.normalizedMimeType,
        audioBytes: audio.buffer.length,
      };
    }

    // Fallback multimodal transcription (e.g. gemini-4-hydrogen) via generateContent
    const audioPart = uploaded
      ? createPartFromUri(uploaded.uri, uploaded.mimeType)
      : {
          inlineData: {
            mimeType: audio.normalizedMimeType,
            data: audio.cleanBase64,
          },
        };

    const resp = await ai.models.generateContent({
      model: modelName,
      contents: {
        parts: [
          audioPart,
          {
            text: `${langDirective} Return only the transcript text. If no clear human speech exists, briefly describe the primary sound.`,
          },
        ],
      },
      ...(modelName === "gemini-4-hydrogen"
        ? { config: { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } }
        : {}),
    });

    const extractedText = (
      resp.text ||
      resp.candidates?.[0]?.content?.parts
        ?.map((p) => p.text ?? "")
        .join("") ||
      ""
    ).trim();

    if (!extractedText) {
      const finishReason = resp.candidates?.[0]?.finishReason ?? "UNKNOWN";
      const detail = `finishReason=${finishReason}, mime=${audio.normalizedMimeType}, bytes=${audio.buffer.length}, filesApi=${useFilesApi}`;
      console.warn(
        `[transcription] Empty output from ${modelName} via generateContent (${detail})`
      );
      const err = new Error(
        `Transkripsi ${modelName} menghasilkan output kosong (${detail}).`
      ) as Error & { code?: string };
      err.code = "EMPTY_MODEL_OUTPUT";
      throw err;
    }

    return {
      transcript: extractedText,
      apiMethod: "models.generateContent",
      usedFilesApi: useFilesApi,
      normalizedMimeType: audio.normalizedMimeType,
      audioBytes: audio.buffer.length,
    };
  } finally {
    if (uploadedFileName) {
      await ai.files.delete({ name: uploadedFileName }).catch(() => {});
    }
  }
}

interface ExecResult {
  code: number;
  stdout: string;
  stderr: string;
}

function runSubprocess(
  command: string,
  args: string[],
  signal?: AbortSignal
): Promise<ExecResult> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      reject(new Error("Proses dibatalkan oleh pengguna."));
      return;
    }
    const child = spawn(command, args, { stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";

    child.stdout.on("data", (chunk: Buffer) => {
      stdout += chunk.toString("utf8");
    });
    child.stderr.on("data", (chunk: Buffer) => {
      stderr += chunk.toString("utf8");
    });

    const onAbort = () => {
      try {
        child.kill("SIGKILL");
      } catch {
        // ignore
      }
      reject(new Error("Proses dibatalkan oleh pengguna."));
    };
    signal?.addEventListener("abort", onAbort, { once: true });

    child.on("error", (err) => {
      signal?.removeEventListener("abort", onAbort);
      reject(err);
    });
    child.on("close", (code) => {
      signal?.removeEventListener("abort", onAbort);
      resolve({ code: code ?? 1, stdout, stderr });
    });
  });
}

function getTargetExportSize(aspectRatio: string): { width: number; height: number } {
  if (aspectRatio === "16:9") return { width: 1920, height: 1080 };
  if (aspectRatio === "1:1") return { width: 1080, height: 1080 };
  return { width: 1080, height: 1920 };
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: "35mb" }));

  app.get("/api/health", (_req: Request, res: Response) => {
    res.json({ ok: true });
  });

  app.get("/api/models/status", async (_req: Request, res: Response) => {
    try {
      const ai = getGeminiClient();
      const tasks = Object.entries(MODEL_CONFIG) as [
        ModelTask,
        { primary: string; fallback: string }
      ][];

      const statuses = await Promise.all(
        tasks.map(async ([task, pair]) => {
          const [primaryStatus, fallbackStatus] = await Promise.all([
            checkModelAvailability(ai, pair.primary),
            checkModelAvailability(ai, pair.fallback),
          ]);
          return {
            task,
            primary: { model: pair.primary, ...primaryStatus },
            fallback: { model: pair.fallback, ...fallbackStatus },
          };
        })
      );

      res.json({ ok: true, models: statuses });
    } catch (err) {
      const formatted = formatGeminiError(err);
      res.status(formatted.status).json({ ok: false, error: formatted.message });
    }
  });

  app.post("/api/ai-director/revise", async (req: Request, res: Response) => {
    const signal = attachRequestAbortSignal(req, res);
    try {
      const instruction = typeof req.body?.instruction === "string" ? req.body.instruction.trim() : "";
      const current = req.body?.blueprint as VideoBlueprint | undefined;
      const revisionContext = Array.isArray(req.body?.revisionContext)
        ? req.body.revisionContext.filter((item: unknown): item is string => typeof item === "string").slice(-5)
        : [];
      if (!instruction) {
        res.status(400).json({ error: "Tuliskan instruksi revisi terlebih dahulu." });
        return;
      }
      if (!current || !Array.isArray(current.scenes) || current.scenes.length === 0) {
        res.status(400).json({ error: "Storyboard belum tersedia. Buat video terlebih dahulu." });
        return;
      }
      if (instruction.length > 3000) {
        res.status(400).json({ error: "Instruksi terlalu panjang. Maksimal 3.000 karakter." });
        return;
      }

      const ai = getGeminiClient();
      const langPref = normalizeLanguagePreference(current.languagePreference || "auto");
      const languageRule = langPref === "en-US"
        ? "Pertahankan seluruh teks video dalam bahasa Inggris natural."
        : langPref === "id-ID"
        ? "Pertahankan seluruh teks video dalam bahasa Indonesia natural."
        : "Pertahankan bahasa asli tiap adegan; jangan menerjemahkan tanpa diminta.";

      const systemInstruction = `Kamu adalah SUTRADARA AI senior untuk Izzy Studio, ahli motion graphic, storytelling visual, komposisi, kamera, dan animasi dinamis.
Tugasmu merevisi storyboard video yang sudah ada berdasarkan instruksi pengguna, bukan membuat proyek baru dari nol.
${languageRule}
ATURAN WAJIB:
1. Terapkan instruksi pengguna secara tepat. Jika instruksi menyebut adegan tertentu, prioritaskan adegan itu. Jika bersifat global, terapkan konsisten pada seluruh adegan yang relevan.
2. Pertahankan topik, fakta inti, urutan cerita, identitas proyek, gaya visual, rasio aspek, mode sumber, dan audio. Jangan mengubah hal yang tidak diminta.
3. Pertahankan jumlah adegan dan durasi masing-masing sedekat mungkin, kecuali pengguna secara eksplisit meminta mengubah durasi atau jumlah adegan.
4. Jangan menghapus narration atau mengubah maknanya kecuali diminta. Pastikan judul, subtitle, bullets, dan visual sesuai dengan narasi.
5. Tingkatkan kualitas visual secara konkret: subjek, aksi, objek pendukung, lingkungan, gerak objek, gerak kamera, efek atmosfer, intensitas, timing, sinkronisasi narasi, dan transisi. Hindari arahan visual generik atau adegan statis.
6. Kembalikan JSON storyboard lengkap dengan struktur yang sama seperti skema. Jangan sertakan markdown atau penjelasan di luar JSON.
7. Jika pengguna meminta perubahan terbatas (misalnya hanya warna, kamera, atau adegan 2), jangan mengubah elemen lain.
8. Jangan mengarang angka/fakta baru. Pertahankan informasi faktual dari storyboard yang diberikan.
9. Ini adalah proses revisi bertahap. Gunakan storyboard saat ini sebagai hasil kerja terbaru, dan gunakan riwayat instruksi sebelumnya hanya sebagai konteks keputusan kreatif. Instruksi terbaru selalu menjadi prioritas jika bertentangan dengan instruksi lama.
10. Jangan mengembalikan ke versi awal atau membatalkan perbaikan sebelumnya kecuali pengguna secara eksplisit memintanya.`;

      const { result, report } = await runModelWithRetryAndFallback(
        ai,
        "storyboard",
        (modelName) => ai.models.generateContent({
          model: modelName,
          contents: `RIWAYAT INSTRUKSI REVISI SEBELUMNYA (konteks, bukan perintah baru):\n${revisionContext.length ? revisionContext.map((item, index) => `${index + 1}. ${item}`).join("\n") : "Belum ada revisi sebelumnya."}\n\nINSTRUKSI REVISI TERBARU (prioritas utama):\n${instruction}\n\nSTORYBOARD TERKINI YANG HARUS DIREVISI (JSON):\n${JSON.stringify(current)}`,
          config: {
            systemInstruction,
            responseMimeType: "application/json",
            responseSchema: BLUEPRINT_RESPONSE_SCHEMA,
            ...(modelName === "gemini-4-hydrogen" ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } } : {}),
          },
        }),
        { signal }
      );

      const raw = parseJsonSafely<RawBlueprintSchema>(
        result.text ?? "",
        "Sutradara AI tidak menghasilkan revisi storyboard."
      );
      const durations = current.scenes.map((scene) => scene.durationSeconds);
      const revised = normalizeBlueprint(
        raw,
        current.style,
        current.aspectRatio,
        current.brandHandle,
        current.sourceMode,
        current.voiceName,
        durations,
        current.transcript,
        current.audioMode,
        langPref
      );
      // Keep project identity and source metadata stable across revisions.
      revised.id = current.id;
      revised.detectedLanguage = current.detectedLanguage;
      res.json({ blueprint: revised, modelReports: [report] });
    } catch (err) {
      const formatted = formatGeminiError(err);
      if (!res.headersSent) res.status(formatted.status).json({ error: formatted.message });
    }
  });

  app.post("/api/generate-from-text", async (req: Request, res: Response) => {
    const useStream = Boolean(req.body?.streamProgress);
    const signal = attachRequestAbortSignal(req, res);
    const sendNdjson = (payload: Record<string, unknown>) => {
      if (useStream && !res.writableEnded) {
        res.write(`${JSON.stringify(payload)}\n`);
      }
    };
    let currentStage: ServerFailureDiagnostic["failedStage"] = "storyboard";

    try {
      const {
        prompt,
        style = "editorial-desk",
        aspectRatio = "9:16",
        durationPreset = "medium",
        voiceName = "Kore",
        brandHandle = "@IZZY.STUDIO",
        generateAudio = true,
        audioMode,
        languagePreference: rawLangPref = "auto",
      } = req.body ?? {};

      const languagePreference = normalizeLanguagePreference(rawLangPref);

      const resolvedAudioMode: "ai-narration" | "no-audio" =
        audioMode === "no-audio" || generateAudio === false
          ? "no-audio"
          : "ai-narration";
      const shouldSynthesizeAudio = resolvedAudioMode === "ai-narration";

      if (!prompt || typeof prompt !== "string" || !prompt.trim()) {
        res
          .status(400)
          .json({ error: "Mohon masukkan teks topik atau naskah terlebih dahulu." });
        return;
      }

      const detectedInputLang = detectTextLanguage(prompt, languagePreference);

      if (useStream) {
        res.setHeader("Content-Type", "application/x-ndjson; charset=utf-8");
        res.setHeader("Cache-Control", "no-cache");
        res.flushHeaders?.();
      }

      const ai = getGeminiClient();
      const modelReports: ModelUsageReport[] = [];

      const targetScenes =
        durationPreset === "short"
          ? "4-5 adegan (total sekitar 20-25 detik)"
          : durationPreset === "long"
          ? "7-8 adegan (total sekitar 45-60 detik)"
          : "5-7 adegan (total sekitar 30-42 detik)";

      const estBase =
        durationPreset === "short" ? 7 : durationPreset === "long" ? 13 : 9;

      const langBadgeText =
        detectedInputLang === "en-US"
          ? "English (en-US)"
          : detectedInputLang === "mixed"
          ? "Bilingual (ID + EN)"
          : "Indonesian (id-ID)";

      sendNdjson({
        type: "progress",
        percent: 12,
        stageLabel: "Menyusun storyboard & animasi semantik per adegan...",
        detailLabel: `Model: ${MODEL_CONFIG.storyboard.primary} · Bahasa: ${langBadgeText}`,
        estimatedTotalSeconds: estBase,
      });

      const languageRule =
        languagePreference === "en-US"
          ? "ATURAN BAHASA OUTPUT: Seluruh 'title', 'subjectNameplate', 'tableColumns', 'topTitle', 'topHighlightWord', 'topSubLabel', 'narration' (subtitle), 'bullets', 'tableRow', dan 'visualMetric.unitLabel' HARUS ditulis dalam Bahasa Inggris (English) yang natural."
          : languagePreference === "id-ID"
          ? "ATURAN BAHASA OUTPUT: Seluruh 'title', 'subjectNameplate', 'tableColumns', 'topTitle', 'topHighlightWord', 'topSubLabel', 'narration' (subtitle), 'bullets', 'tableRow', dan 'visualMetric.unitLabel' HARUS ditulis dalam Bahasa Indonesia yang natural."
          : detectedInputLang === "en-US"
          ? "LANGUAGE RULE (AUTO-DETECTED ENGLISH): Write ALL 'title', 'subjectNameplate', 'tableColumns', 'topTitle', 'topHighlightWord', 'topSubLabel', 'narration' (subtitles), 'bullets', 'tableRow', and labels in crisp natural English matching the user's input."
          : detectedInputLang === "mixed"
          ? "LANGUAGE RULE (AUTO-DETECTED MIXED ID+EN): Preserve bilingual Indonesian + English phrasing cleanly per sentence! Keep Indonesian sentences in natural Indonesian and English sentences/phrases in natural English without forced translation."
          : "ATURAN BAHASA OUTPUT (TERDETEKSI INDONESIA): Seluruh 'title', 'subjectNameplate', 'tableColumns', 'topTitle', 'topHighlightWord', 'topSubLabel', 'narration' (subtitle), 'bullets', dan 'tableRow' HARUS dalam Bahasa Indonesia natural sesuai input pengguna.";

      const systemInstruction = `Kamu adalah sutradara motion-graphic explainer sinematik (multi-layer animation & dynamic camera).
Ubah teks atau topik pengguna menjadi struktur storyboard video animasi JSON yang akurat secara visual, dinamis, berlapis-lapis, dan tersinkronisasi per kalimat.
${languageRule}
Rancang ${targetScenes}.
Aturan KRUSIAL pemetaan visual & animasi per adegan (WAJIB DIPATUHI):
1. Rancang setiap adegan dengan beberapa lapisan gerak yang saling berhubungan lewat 'sceneVisualSpec':
   - 'subject': subjek/objek utama.
   - 'action': aktivitas/perubahan utama objek.
   - 'environment': lingkungan latar adegan.
   - 'objects': 2-3 objek pendukung bergerak di layar.
   - 'objectMovement': detail gerak objek utama (misal detak jantung makin cepat, peluru melesat dengan spin, planet mengorbit elips).
   - 'secondaryAnimation': gerak objek pendukung, partikel, atau indikator (misal partikel darah + EKG, jalur data, gelembung laut).
   - 'environmentalEffect': pilih efek atmosfer ('blood_flow', 'starfield_drift', 'seismic_tremor', 'data_streams', 'ocean_bubbles', 'energy_sparks', 'shockwave_rings', 'ambient_dust').
   - 'cameraMovement': pilih gerakan kamera sinematik ('dolly_in', 'orbit', 'tilt_focus', 'zoom_in', 'zoom_out', 'pan_left', 'pan_right', 'track_object'). Hindari seluruh adegan statis!
   - 'animationIntensity': 'cinematic' atau 'balanced' atau 'subtle'.
   - 'motionTiming': 'spring', 'ease_in_out', 'dramatic_ramp', atau 'linear_flow'.
   - 'narrationSyncCue': hubungan gerak dengan penekanan kalimat narasi.
   - 'transition': pilih transisi halus antar adegan ('morph', 'depth', 'whip', 'zoom', 'slide', 'fade').
   - 'assetKey': pilih aset visual paling cocok per adegan:
     * peluru/proyektil -> 'projectile_bullet'
     * siluet tubuh manusia -> 'human_silhouette'
     * anatomi tubuh/organ/cedera -> 'human_anatomy'
     * jantung/heart -> 'heart_organ'
     * otak/saraf/brain -> 'brain_organ'
     * mobil/kendaraan/car -> 'vehicle_car'
     * planet/tata surya/antariksa -> 'solar_planet'
     * gempa/earthquake -> 'earthquake_seismic'
     * teknologi/chip/AI/circuit -> 'tech_circuit'
     * laut/ombak/ocean -> 'ocean_marine'
     * energi/panel surya/solar -> 'energy_solar'
     * ekonomi/uang/economy -> 'money_economy'
     * server/keamanan siber -> 'server_cyber'
     * jaringan data -> 'data_network'
     * hukum/timbangan -> 'law_balance'
     * peta/negara/globe -> 'news_globe'
     * diagram konsep umum -> 'concept_diagram'
     * 'editorial_desk' HANYA boleh dipakai jika topik memang tentang kantor, pejabat, rapat, atau birokrasi!
2. Jangan memakai satu aset yang sama untuk seluruh adegan — variasikan visual & sudut kamera sesuai perkembangan tiap kalimat.
3. Isi 'tableRow' pada 2-4 adegan kunci jika ada poin perbandingan atau tahapan, dan pastikan setiap 'narration' padat (10-22 kata per adegan).`;

      const { result: blueprintResp, report: storyboardReport } =
        await runModelWithRetryAndFallback(
          ai,
          "storyboard",
          (modelName) =>
            ai.models.generateContent({
              model: modelName,
              contents: `Topik / Naskah Pengguna:\n${prompt.trim()}\n\nLanguage preference: ${languagePreference} (detected: ${detectedInputLang})\nModel visual terpilih: ${style}\nRasio aspek: ${aspectRatio}`,
              config: {
                systemInstruction,
                responseMimeType: "application/json",
                responseSchema: BLUEPRINT_RESPONSE_SCHEMA,
                ...(modelName === "gemini-4-hydrogen"
                  ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
                  : {}),
              },
            }),
          {
            signal,
            onRetry: ({ modelName, attempt, maxRetries, delayMs, httpStatus }) => {
              sendNdjson({
                type: "progress",
                percent: 15,
                stageLabel: `Server sibuk (${httpStatus ?? "sementara"}). Mencoba ulang otomatis ${attempt}/${maxRetries} dalam ${Math.round(
                  delayMs / 1000
                )}d...`,
                detailLabel: `Model: ${modelName}`,
                estimatedTotalSeconds: estBase + Math.round(delayMs / 1000),
                retryAttempt: attempt,
                maxRetries,
              });
            },
            onFallback: ({ primaryModel, fallbackModel, reason }) => {
              sendNdjson({
                type: "progress",
                percent: 20,
                stageLabel: `Beralih dari ${primaryModel} ke ${fallbackModel}...`,
                detailLabel: reason,
                estimatedTotalSeconds: estBase + 3,
              });
            },
          }
        );

      modelReports.push(storyboardReport);

      const parsedBlueprint = parseJsonSafely<RawBlueprintSchema>(
        blueprintResp.text ?? "",
        "AI tidak mengembalikan struktur storyboard."
      );

      if (
        !Array.isArray(parsedBlueprint.scenes) ||
        parsedBlueprint.scenes.length === 0 ||
        parsedBlueprint.scenes.some((s) => !s?.narration?.trim())
      ) {
        throw new Error(
          "AI tidak menghasilkan adegan dan narasi yang valid. Coba perjelas teks Anda."
        );
      }

      const sceneCount = parsedBlueprint.scenes.length;
      const estimatedDurations = parsedBlueprint.scenes.map(
        (s) => s.estimatedSeconds || 4.8
      );
      const visualBlueprint = normalizeBlueprint(
        parsedBlueprint,
        style,
        aspectRatio,
        brandHandle,
        "text",
        shouldSynthesizeAudio ? voiceName : undefined,
        estimatedDurations,
        undefined,
        resolvedAudioMode,
        languagePreference
      );

      sendNdjson({
        type: "progress",
        percent: shouldSynthesizeAudio ? 35 : 92,
        stageLabel: shouldSynthesizeAudio
          ? `Mensintesis suara narator (0/${sceneCount} adegan)...`
          : "Mode Tanpa Audio: menyelesaikan visual & subtitle...",
        detailLabel: shouldSynthesizeAudio
          ? `${sceneCount} adegan · ${langBadgeText} (${storyboardReport.usedModel})`
          : `${sceneCount} adegan siap tanpa memanggil Gemini TTS (${langBadgeText})`,
        estimatedTotalSeconds: estBase,
      });

      let audioBase64 = "";
      let sceneDurations = estimatedDurations;
      let ttsFailed = false;
      let ttsError: string | undefined;
      let ttsDiagnostics: ServerFailureDiagnostic | undefined;

      if (shouldSynthesizeAudio) {
        currentStage = "tts";

        try {
          const ttsOut = await synthesizeScenesInBatches(
            ai,
            parsedBlueprint.scenes.map((s) => s.narration),
            voiceName,
            style,
            {
              languagePreference,
              overallLanguage: visualBlueprint.detectedLanguage || detectedInputLang,
              signal,
              onProgress: (completed, total) => {
                const pct = 35 + Math.round((completed / Math.max(1, total)) * 58);
                sendNdjson({
                  type: "progress",
                  percent: pct,
                  stageLabel: `Mensintesis suara narator (${completed}/${total} adegan)...`,
                  detailLabel: `Karakter suara: ${voiceName} · ${langBadgeText}`,
                  estimatedTotalSeconds: estBase,
                });
              },
              onRetry: ({ modelName, attempt, maxRetries, delayMs, httpStatus }) => {
                sendNdjson({
                  type: "progress",
                  percent: 45,
                  stageLabel: `Sintesis suara tertunda (${httpStatus ?? "sementara"}). Coba ulang ${attempt}/${maxRetries} (${Math.round(
                    delayMs / 1000
                  )}d)...`,
                  detailLabel: `Model TTS: ${modelName}`,
                  estimatedTotalSeconds: estBase + Math.round(delayMs / 1000),
                  retryAttempt: attempt,
                  maxRetries,
                });
              },
              onFallback: ({ primaryModel, fallbackModel, reason }) => {
                sendNdjson({
                  type: "progress",
                  percent: 45,
                  stageLabel: `Beralih model suara dari ${primaryModel} ke ${fallbackModel}...`,
                  detailLabel: reason,
                  estimatedTotalSeconds: estBase + 2,
                });
              },
            }
          );

          modelReports.push(...ttsOut.reports);

          sendNdjson({
            type: "progress",
            percent: 96,
            stageLabel: "Menggabungkan audio & menyinkronkan waktu...",
            detailLabel: "Finalisasi berkas suara",
            estimatedTotalSeconds: estBase,
          });

          const combined = concatenateWavBuffers(ttsOut.buffers);
          if (!combined.combinedBase64) {
            throw new Error("Gagal menggabungkan audio narator video.");
          }
          audioBase64 = combined.combinedBase64;
          sceneDurations = combined.durations;
        } catch (ttsErr) {
          if (signal.aborted) {
            throw ttsErr;
          }
          const formattedTts = formatGeminiError(ttsErr, {
            endpoint: "/api/generate-from-text",
            failedStage: "tts",
            fallbackModel: MODEL_CONFIG.tts.primary,
          });
          ttsFailed = true;
          ttsError = `${formattedTts.message} Preview visual tetap tersedia dan dapat diekspor tanpa narasi.`;
          ttsDiagnostics = formattedTts.diagnostics;
        }
      }

      const blueprint =
        !shouldSynthesizeAudio || ttsFailed
          ? visualBlueprint
          : normalizeBlueprint(
              parsedBlueprint,
              style,
              aspectRatio,
              brandHandle,
              "text",
              voiceName,
              sceneDurations,
              undefined,
              resolvedAudioMode,
              languagePreference
            );

      const finalReports = summarizeModelReports(modelReports);
      const responsePayload = {
        blueprint,
        audioBase64,
        ttsSkipped: !shouldSynthesizeAudio,
        modelReports: finalReports,
        ...(ttsFailed
          ? {
              ttsFailed: true,
              ttsError,
              diagnostics: ttsDiagnostics,
            }
          : {}),
      };

      if (useStream) {
        sendNdjson({
          type: "done",
          ...responsePayload,
        });
        res.end();
      } else {
        res.json(responsePayload);
      }
    } catch (err) {
      const formatted = formatGeminiError(err, {
        endpoint: "/api/generate-from-text",
        failedStage: currentStage,
        fallbackModel:
          currentStage === "tts"
            ? MODEL_CONFIG.tts.primary
            : MODEL_CONFIG.storyboard.primary,
      });
      if (useStream && res.headersSent) {
        sendNdjson({
          type: "error",
          status: formatted.status,
          error: formatted.message,
          diagnostics: formatted.diagnostics,
        });
        res.end();
      } else {
        res.status(formatted.status).json({
          error: formatted.message,
          diagnostics: formatted.diagnostics,
        });
      }
    }
  });

  app.post("/api/generate-from-audio", async (req: Request, res: Response) => {
    const useStream = Boolean(req.body?.streamProgress);
    const signal = attachRequestAbortSignal(req, res);
    const sendNdjson = (payload: Record<string, unknown>) => {
      if (useStream && !res.writableEnded) {
        res.write(`${JSON.stringify(payload)}\n`);
      }
    };
    let currentStage: ServerFailureDiagnostic["failedStage"] = "transcription";
    let completedTranscript: string | undefined;

    try {
      const {
        audioBase64,
        mimeType = "audio/webm",
        durationSeconds = 30,
        style = "editorial-desk",
        aspectRatio = "9:16",
        visualHint = "",
        brandHandle = "@IZZY.STUDIO",
        cachedTranscript,
        languagePreference: rawLangPref = "auto",
      } = req.body ?? {};
      const languagePreference = normalizeLanguagePreference(rawLangPref);

      if (!audioBase64 || typeof audioBase64 !== "string") {
        res.status(400).json({ error: "Data audio tidak ditemukan." });
        return;
      }

      let validatedAudio: ValidatedAudioPayload | null = null;
      const hasCachedTranscript =
        typeof cachedTranscript === "string" && cachedTranscript.trim().length > 0;

      if (!hasCachedTranscript) {
        try {
          validatedAudio = validateAndNormalizeAudioInput(audioBase64, mimeType);
        } catch (validationErr) {
          const msg =
            validationErr instanceof Error
              ? validationErr.message
              : "File audio tidak valid.";
          res.status(400).json({ error: msg });
          return;
        }
      }

      if (useStream) {
        res.setHeader("Content-Type", "application/x-ndjson; charset=utf-8");
        res.setHeader("Cache-Control", "no-cache");
        res.flushHeaders?.();
      }

      const ai = getGeminiClient();
      const modelReports: ModelUsageReport[] = [];
      let transcript = "";
      let transcribeDiagnosticsInfo: Record<string, unknown> = {
        cachedTranscriptUsed: true,
      };

      if (hasCachedTranscript) {
        transcript = String(cachedTranscript).trim();
        completedTranscript = transcript;
        sendNdjson({
          type: "progress",
          percent: 55,
          stageLabel: "Menggunakan transkrip yang sudah berhasil...",
          detailLabel: `${transcript.split(/\s+/).length} kata siap disusun menjadi adegan`,
          estimatedTotalSeconds: 6,
        });
      } else if (validatedAudio) {
        sendNdjson({
          type: "progress",
          percent: 20,
          stageLabel: "Mentranskripsikan ucapan audio...",
          detailLabel: `Format: ${validatedAudio.normalizedMimeType} (${Math.round(
            validatedAudio.buffer.length / 1024
          )} KB) · Durasi ${Number(durationSeconds).toFixed(1)}d`,
          estimatedTotalSeconds: 8,
        });

        const { result: transcribeMeta, report: transcribeReport } =
          await runModelWithRetryAndFallback(
            ai,
            "transcription",
            (modelName) =>
              transcribeWithModel(
                ai,
                modelName,
                validatedAudio,
                signal,
                languagePreference
              ),
            {
              signal,
              onRetry: ({ modelName, attempt, maxRetries, delayMs, httpStatus }) => {
                sendNdjson({
                  type: "progress",
                  percent: 24,
                  stageLabel: `Transkripsi tertunda (${httpStatus ?? "sementara"}). Coba ulang ${attempt}/${maxRetries} dalam ${Math.round(
                    delayMs / 1000
                  )}d...`,
                  detailLabel: `Model: ${modelName}`,
                  estimatedTotalSeconds: 8 + Math.round(delayMs / 1000),
                  retryAttempt: attempt,
                  maxRetries,
                });
              },
              onFallback: ({ primaryModel, fallbackModel, reason }) => {
                sendNdjson({
                  type: "progress",
                  percent: 28,
                  stageLabel: `Beralih model transkripsi dari ${primaryModel} ke ${fallbackModel}...`,
                  detailLabel: reason,
                  estimatedTotalSeconds: 10,
                });
              },
            }
          );

        modelReports.push(transcribeReport);
        transcript = transcribeMeta.transcript.trim();
        if (!transcript) {
          throw new Error(
            `Transkripsi menghasilkan teks kosong (mime=${validatedAudio.normalizedMimeType}, bytes=${validatedAudio.buffer.length}). Pastikan audio berisi ucapan yang jelas.`
          );
        }
        completedTranscript = transcript;
        const detectedTranscriptLang = detectTextLanguage(
          transcript,
          languagePreference
        );
        transcribeDiagnosticsInfo = {
          apiMethod: transcribeMeta.apiMethod,
          usedFilesApi: transcribeMeta.usedFilesApi,
          normalizedMimeType: transcribeMeta.normalizedMimeType,
          audioBytes: transcribeMeta.audioBytes,
          model: transcribeReport.usedModel,
          detectedLanguage: detectedTranscriptLang,
        };

        sendNdjson({
          type: "progress",
          percent: 58,
          stageLabel: "Menyusun adegan visual dari transkrip...",
          detailLabel: `${transcript.split(/\s+/).length} kata (${detectedTranscriptLang}) · ${transcribeReport.usedModel}`,
          estimatedTotalSeconds: 8,
        });
      }

      const detectedTranscriptLang = detectTextLanguage(
        transcript,
        languagePreference
      );

      currentStage = "storyboard";
      const safeDuration = Math.max(4, Number(durationSeconds) || 25);
      const targetSceneCount = Math.min(
        8,
        Math.max(3, Math.round(safeDuration / 5.5))
      );

      const audioLangRule =
        detectedTranscriptLang === "en-US"
          ? "Keep all 'narration' faithfully in the original English words of the transcript, and write 'topTitle', 'topSubLabel', 'subjectNameplate', and 'tableColumns' in English."
          : detectedTranscriptLang === "mixed"
          ? "Preserve exact bilingual Indonesian + English words from the transcript verbatim in each 'narration' segment so subtitles stay synchronized with what is actually spoken."
          : "Pertahankan kata-kata asli Bahasa Indonesia dari transkrip pada setiap 'narration' agar subtitle tersinkron dengan suara asli.";

      const systemInstruction = `Kamu adalah sutradara motion-graphic yang menyinkronkan visual multi-lapisan otomatis terhadap rekaman suara pengguna.
Berdasarkan transkrip audio berdurasi total ${safeDuration.toFixed(1)} detik, pecah transkrip tersebut secara berurutan menjadi ${targetSceneCount} adegan visual.
${audioLangRule}
PENTING:
- Setiap adegan harus memuat potongan kalimat persis (atau mendekati persis) dari transkrip secara berurutan dari awal sampai akhir pada field 'narration' agar subtitle tersinkron dengan audio asli dalam bahasa aslinya.
- Jumlah total 'estimatedSeconds' seluruh adegan HARUS mendekati ${safeDuration.toFixed(1)} detik (proporsional dengan panjang kata tiap adegan).
- Isi 'sceneVisualSpec' pada SETIAP adegan dengan analisis semantik & gerak multi-lapisan lengkap (assetKey, subject, action, environment, objects, visualDescription, cameraMovement termasuk 'dolly_in'/'orbit'/'tilt_focus', animationType, focusRegion, objectMovement, secondaryAnimation, environmentalEffect, animationIntensity, motionTiming) plus 'transition'. Jangan menggunakan 'editorial_desk' jika topiknya bukan kantor/pemerintahan.
- Isi 'tableRow', 'visualMetric', atau 'newsCard' jika transkrip menyebut angka, perbandingan, lokasi, atau fakta kunci.`;

      const { result: blueprintResp, report: storyboardReport } =
        await runModelWithRetryAndFallback(
          ai,
          "storyboard",
          (modelName) =>
            ai.models.generateContent({
              model: modelName,
              contents: `Transkrip Audio (durasi total ${safeDuration.toFixed(1)} detik, bahasa terdeteksi: ${detectedTranscriptLang}):\n"""\n${transcript}\n"""\n\nArahan visual tambahan: ${
                visualHint || "Sesuaikan otomatis dengan konteks ucapan"
              }\nModel visual: ${style}`,
              config: {
                systemInstruction,
                responseMimeType: "application/json",
                responseSchema: BLUEPRINT_RESPONSE_SCHEMA,
                ...(modelName === "gemini-4-hydrogen"
                  ? { thinkingConfig: { thinkingLevel: ThinkingLevel.LOW } }
                  : {}),
              },
            }),
          {
            signal,
            onRetry: ({ modelName, attempt, maxRetries, delayMs, httpStatus }) => {
              sendNdjson({
                type: "progress",
                percent: 65,
                stageLabel: `Penyusunan adegan tertunda (${httpStatus ?? "sementara"}). Coba ulang ${attempt}/${maxRetries} (${Math.round(
                  delayMs / 1000
                )}d)...`,
                detailLabel: `Model: ${modelName}`,
                estimatedTotalSeconds: 8 + Math.round(delayMs / 1000),
                retryAttempt: attempt,
                maxRetries,
              });
            },
            onFallback: ({ primaryModel, fallbackModel, reason }) => {
              sendNdjson({
                type: "progress",
                percent: 70,
                stageLabel: `Beralih model adegan dari ${primaryModel} ke ${fallbackModel}...`,
                detailLabel: reason,
                estimatedTotalSeconds: 10,
              });
            },
          }
        );

      modelReports.push(storyboardReport);

      const parsedBlueprint = parseJsonSafely<RawBlueprintSchema>(
        blueprintResp.text ?? "",
        "AI tidak mengembalikan struktur adegan dari audio."
      );

      if (
        !Array.isArray(parsedBlueprint.scenes) ||
        parsedBlueprint.scenes.length === 0
      ) {
        throw new Error("Gagal memetakan adegan visual dari transkrip audio.");
      }

      sendNdjson({
        type: "progress",
        percent: 94,
        stageLabel: "Menyinkronkan durasi adegan ke audio asli...",
        detailLabel: `${parsedBlueprint.scenes.length} adegan dipetakan`,
        estimatedTotalSeconds: 8,
      });

      const rawWeights = parsedBlueprint.scenes.map((s) =>
        Math.max(
          1.8,
          s.estimatedSeconds || Math.max(2, s.narration.split(/\s+/).length * 0.42)
        )
      );
      const totalRaw = rawWeights.reduce((a, b) => a + b, 0) || 1;
      const scaledDurations = rawWeights.map((w) => (w / totalRaw) * safeDuration);

      const blueprint = normalizeBlueprint(
        parsedBlueprint,
        style,
        aspectRatio,
        brandHandle,
        "audio",
        undefined,
        scaledDurations,
        transcript,
        "uploaded-audio",
        languagePreference
      );

      const finalReports = summarizeModelReports(modelReports);
      if (useStream) {
        sendNdjson({
          type: "done",
          blueprint,
          transcript,
          modelReports: finalReports,
          transcriptionDiagnostics: transcribeDiagnosticsInfo,
        });
        res.end();
      } else {
        res.json({
          blueprint,
          transcript,
          modelReports: finalReports,
          transcriptionDiagnostics: transcribeDiagnosticsInfo,
        });
      }
    } catch (err) {
      const formatted = formatGeminiError(err, {
        endpoint: "/api/generate-from-audio",
        failedStage: currentStage,
        fallbackModel:
          currentStage === "transcription"
            ? MODEL_CONFIG.transcription.primary
            : MODEL_CONFIG.storyboard.primary,
      });
      if (useStream && res.headersSent) {
        sendNdjson({
          type: "error",
          status: formatted.status,
          error: formatted.message,
          diagnostics: formatted.diagnostics,
          ...(completedTranscript ? { transcript: completedTranscript } : {}),
        });
        res.end();
      } else {
        res.status(formatted.status).json({
          error: formatted.message,
          diagnostics: formatted.diagnostics,
          ...(completedTranscript ? { transcript: completedTranscript } : {}),
        });
      }
    }
  });

  app.post("/api/regenerate-voice", async (req: Request, res: Response) => {
    const useStream = Boolean(req.body?.streamProgress);
    const signal = attachRequestAbortSignal(req, res);
    const sendNdjson = (payload: Record<string, unknown>) => {
      if (useStream && !res.writableEnded) {
        res.write(`${JSON.stringify(payload)}\n`);
      }
    };

    try {
      const {
        narrations,
        voiceName = "Kore",
        style = "editorial-desk",
        languagePreference: rawLangPref = "auto",
      } = req.body ?? {};
      const languagePreference = normalizeLanguagePreference(rawLangPref);
      if (!Array.isArray(narrations) || narrations.length === 0) {
        res.status(400).json({ error: "Daftar narasi adegan tidak valid." });
        return;
      }

      if (useStream) {
        res.setHeader("Content-Type", "application/x-ndjson; charset=utf-8");
        res.setHeader("Cache-Control", "no-cache");
        res.flushHeaders?.();
      }

      const ai = getGeminiClient();
      const combinedText = narrations.map((n) => String(n || "")).join(" ");
      const overallLang = detectTextLanguage(combinedText, languagePreference);

      sendNdjson({
        type: "progress",
        percent: 12,
        stageLabel: `Menyiapkan sinkronisasi suara (0/${narrations.length} adegan)...`,
        detailLabel: `Karakter suara: ${voiceName} · Bahasa: ${overallLang} · Antrean 1/1`,
        estimatedTotalSeconds: Math.max(3, narrations.length * 2),
      });

      const ttsOut = await synthesizeScenesInBatches(
        ai,
        narrations.map((n) => String(n || " ")),
        voiceName,
        style,
        {
          languagePreference,
          overallLanguage: overallLang,
          signal,
          onProgress: (completed, total) => {
            const pct = 12 + Math.round((completed / Math.max(1, total)) * 82);
            sendNdjson({
              type: "progress",
              percent: pct,
              stageLabel: `Mensintesis ulang suara (${completed}/${total} adegan)...`,
              detailLabel: `Karakter suara: ${voiceName}`,
              estimatedTotalSeconds: Math.max(3, total * 2),
            });
          },
          onRetry: ({ modelName, attempt, maxRetries, delayMs, httpStatus }) => {
            sendNdjson({
              type: "progress",
              percent: 35,
              stageLabel: `Sintesis suara tertunda (${httpStatus ?? "sementara"}). Coba ulang ${attempt}/${maxRetries} (${Math.round(
                delayMs / 1000
              )}d)...`,
              detailLabel: `Model TTS: ${modelName}`,
              estimatedTotalSeconds:
                Math.max(3, narrations.length * 2) + Math.round(delayMs / 1000),
              retryAttempt: attempt,
              maxRetries,
            });
          },
          onFallback: ({ primaryModel, fallbackModel, reason }) => {
            sendNdjson({
              type: "progress",
              percent: 40,
              stageLabel: `Beralih model suara dari ${primaryModel} ke ${fallbackModel}...`,
              detailLabel: reason,
              estimatedTotalSeconds: Math.max(3, narrations.length * 2) + 2,
            });
          },
        }
      );

      const combined = concatenateWavBuffers(ttsOut.buffers);
      if (!combined.combinedBase64) {
        throw new Error("Gagal menggabungkan audio suara narator.");
      }

      const finalReports = summarizeModelReports(ttsOut.reports);
      if (useStream) {
        sendNdjson({
          type: "done",
          audioBase64: combined.combinedBase64,
          durations: combined.durations,
          modelReports: finalReports,
        });
        res.end();
      } else {
        res.json({
          audioBase64: combined.combinedBase64,
          durations: combined.durations,
          modelReports: finalReports,
        });
      }
    } catch (err) {
      const formatted = formatGeminiError(err, {
        endpoint: "/api/regenerate-voice",
        failedStage: "tts",
        fallbackModel: MODEL_CONFIG.tts.primary,
      });
      if (useStream && res.headersSent) {
        sendNdjson({
          type: "error",
          status: formatted.status,
          error: formatted.message,
          diagnostics: formatted.diagnostics,
        });
        res.end();
      } else {
        res.status(formatted.status).json({
          error: formatted.message,
          diagnostics: formatted.diagnostics,
        });
      }
    }
  });

  app.post(
    "/api/export-mp4",
    express.raw({
      type: ["video/webm", "video/mp4", "application/octet-stream"],
      limit: "150mb",
    }),
    async (req: Request, res: Response) => {
      const signal = attachRequestAbortSignal(req, res);
      let tempDir: string | null = null;

      try {
        const rawBody = req.body;
        if (!Buffer.isBuffer(rawBody) || rawBody.length < 512) {
          res.status(400).json({
            error: "Data video sumber kosong atau terlalu kecil untuk dikonversi ke MP4.",
          });
          return;
        }

        const aspectRatio = String(req.query.aspectRatio || "9:16");
        const { width: targetW, height: targetH } = getTargetExportSize(aspectRatio);
        const contentType = String(req.headers["content-type"] || "video/webm").toLowerCase();
        const inputExt = contentType.includes("mp4") ? "mp4" : "webm";

        tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "izzy-mp4-"));
        const inputPath = path.join(tempDir, `source.${inputExt}`);
        const outputPath = path.join(tempDir, "output.mp4");
        fs.writeFileSync(inputPath, rawBody);

        // Probe input streams cleanly to check video presence and audio track existence
        const probeIn = await runSubprocess(
          "ffprobe",
          [
            "-v",
            "error",
            "-show_entries",
            "stream=codec_type,codec_name,width,height",
            "-of",
            "json",
            inputPath,
          ],
          signal
        );
        if (probeIn.code !== 0) {
          res.status(400).json({
            error: `Video sumber tidak dapat dibaca FFprobe: ${probeIn.stderr.slice(0, 200)}`,
          });
          return;
        }

        const parsedIn = JSON.parse(probeIn.stdout || "{}") as {
          streams?: Array<{ codec_type?: string }>;
        };
        const hasVideoStream = parsedIn.streams?.some((s) => s.codec_type === "video");
        const hasAudioStream = parsedIn.streams?.some((s) => s.codec_type === "audio");

        if (!hasVideoStream) {
          res.status(400).json({
            error: "Video sumber tidak memiliki track gambar (video stream).",
          });
          return;
        }

        const ffmpegArgs = [
          "-y",
          "-fflags",
          "+genpts",
          "-i",
          inputPath,
          "-vf",
          `scale=${targetW}:${targetH}:force_original_aspect_ratio=decrease,pad=${targetW}:${targetH}:(ow-iw)/2:(oh-ih)/2:black,setsar=1`,
          "-c:v",
          "libx264",
          "-preset",
          "fast",
          "-crf",
          "20",
          "-profile:v",
          "high",
          "-level:v",
          "4.1",
          "-pix_fmt",
          "yuv420p",
          "-r",
          "30",
          "-vsync",
          "cfr",
          ...(hasAudioStream
            ? [
                "-c:a",
                "aac",
                "-b:a",
                "192k",
                "-ar",
                "48000",
                "-ac",
                "2",
                "-af",
                "aresample=async=1:first_pts=0",
                "-shortest",
              ]
            : ["-an"]),
          "-movflags",
          "+faststart",
          outputPath,
        ];

        const transcode = await runSubprocess("ffmpeg", ffmpegArgs, signal);
        if (transcode.code !== 0 || !fs.existsSync(outputPath)) {
          throw new Error(
            `Konversi MP4 gagal di FFmpeg: ${transcode.stderr.slice(-300)}`
          );
        }

        // Verify generated MP4 integrity, dimensions, codec, and playability
        const probeOut = await runSubprocess(
          "ffprobe",
          [
            "-v",
            "error",
            "-show_entries",
            "stream=codec_type,codec_name,width,height,pix_fmt",
            "-show_entries",
            "format=duration,size",
            "-of",
            "json",
            outputPath,
          ],
          signal
        );
        if (probeOut.code !== 0) {
          throw new Error("Verifikasi hasil MP4 dengan FFprobe gagal.");
        }

        const parsedOut = JSON.parse(probeOut.stdout || "{}") as {
          streams?: Array<{
            codec_type?: string;
            codec_name?: string;
            width?: number;
            height?: number;
            pix_fmt?: string;
          }>;
          format?: { duration?: string; size?: string };
        };

        const outVideo = parsedOut.streams?.find((s) => s.codec_type === "video");
        const outDuration = Number(parsedOut.format?.duration || 0);
        const mp4Buffer = fs.readFileSync(outputPath);

        if (!outVideo || mp4Buffer.length < 512 || outDuration <= 0) {
          throw new Error("Hasil konversi MP4 kosong atau tidak memiliki durasi yang valid.");
        }

        res.setHeader("Content-Type", "video/mp4");
        res.setHeader("Content-Length", String(mp4Buffer.length));
        res.setHeader("X-Video-Width", String(outVideo.width ?? targetW));
        res.setHeader("X-Video-Height", String(outVideo.height ?? targetH));
        res.setHeader("X-Video-Codec", String(outVideo.codec_name ?? "h264"));
        res.setHeader("X-Video-Duration", outDuration.toFixed(2));
        res.send(mp4Buffer);
      } catch (err) {
        if (signal.aborted) {
          return;
        }
        const message =
          err instanceof Error ? err.message : "Gagal mengonversi video ke MP4.";
        if (!res.headersSent) {
          res.status(500).json({ error: message });
        }
      } finally {
        if (tempDir) {
          fs.rmSync(tempDir, { recursive: true, force: true });
        }
      }
    }
  );

  if (process.env.NODE_ENV === "production") {
    const distPath = path.resolve(__dirname, "dist");
    app.use(express.static(distPath));
    app.use((_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  } else {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Izzy Studio server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
  process.exit(1);
});
