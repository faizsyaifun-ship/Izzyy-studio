import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  Download,
  Loader2,
  Pause,
  Play,
  RotateCcw,
  RotateCw,
  Volume1,
  Volume2,
  VolumeX,
  X,
} from "lucide-react";
import { VIDEO_STYLES } from "../data/presets";
import { getCanvasDimensions, renderVideoFrame } from "../lib/videoEngine";
import type {
  FailureDiagnostic,
  GenerationWorkflowState,
  ProcessProgress,
  VideoBlueprint,
} from "../types/video";

interface VideoPreviewStageProps {
  blueprint: VideoBlueprint;
  audioUrl: string | null;
  currentTime: number;
  isPlaying: boolean;
  workflowState?: GenerationWorkflowState;
  genProgress?: ProcessProgress;
  errorMsg?: string | null;
  failureDiagnostic?: FailureDiagnostic | null;
  retryLabel?: string;
  onExportWithoutAudio?: () => void;
  canRetry?: boolean;
  onRetry?: () => void;
  onTimeUpdate: (t: number) => void;
  onPlayStateChange: (playing: boolean) => void;
  exportRequestCounter: number;
}

export const VideoPreviewStage: React.FC<VideoPreviewStageProps> = ({
  blueprint,
  audioUrl,
  currentTime,
  isPlaying,
  workflowState = "idle",
  genProgress,
  errorMsg,
  failureDiagnostic = null,
  retryLabel = "Coba Lagi",
  onExportWithoutAudio,
  canRetry = false,
  onRetry,
  onTimeUpdate,
  onPlayStateChange,
  exportRequestCounter,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const mediaSourceConnectedRef = useRef<boolean>(false);
  const binsBufferRef = useRef<Uint8Array<ArrayBuffer> | null>(null);
  const cancelExportRef = useRef<boolean>(false);
  const exportAbortRef = useRef<AbortController | null>(null);

  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(1);
  const [playbackRate, setPlaybackRate] = useState<number>(1);
  const [exportFormat, setExportFormat] = useState<"mp4" | "webm">("mp4");
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportProgress, setExportProgress] = useState<number>(0);
  const [exportStageLabel, setExportStageLabel] = useState<string>(
    "Merender Video"
  );
  const [exportElapsed, setExportElapsed] = useState<number>(0);
  const [exportFps, setExportFps] = useState<number>(30);
  const [exportError, setExportError] = useState<string | null>(null);
  const [fallbackWebmUrl, setFallbackWebmUrl] = useState<string | null>(null);
  const [fallbackWebmName, setFallbackWebmName] = useState<string>("izzy-video.webm");
  const [genNowMs, setGenNowMs] = useState<number>(() => Date.now());

  const currentTimeRef = useRef<number>(currentTime);
  currentTimeRef.current = currentTime;

  const isPlayingRef = useRef<boolean>(isPlaying);
  isPlayingRef.current = isPlaying;

  const blueprintRef = useRef<VideoBlueprint>(blueprint);
  blueprintRef.current = blueprint;

  const dims = getCanvasDimensions(blueprint.aspectRatio);
  const styleMeta = VIDEO_STYLES.find((s) => s.id === blueprint.style);

  useEffect(() => {
    return () => {
      if (fallbackWebmUrl) URL.revokeObjectURL(fallbackWebmUrl);
    };
  }, [fallbackWebmUrl]);

  const ensureAudioAnalyser = useCallback(() => {
    const audioEl = audioRef.current;
    if (!audioEl || !audioUrl) return;
    if (!audioCtxRef.current) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      audioCtxRef.current = new AudioCtx();
    }
    if (audioCtxRef.current.state === "suspended") {
      void audioCtxRef.current.resume();
    }
    if (!mediaSourceConnectedRef.current) {
      try {
        const source = audioCtxRef.current.createMediaElementSource(audioEl);
        const analyser = audioCtxRef.current.createAnalyser();
        analyser.fftSize = 128;
        source.connect(analyser);
        analyser.connect(audioCtxRef.current.destination);
        analyserRef.current = analyser;
        binsBufferRef.current = new Uint8Array(
          new ArrayBuffer(analyser.frequencyBinCount)
        );
        mediaSourceConnectedRef.current = true;
      } catch {
        // Already connected or blocked; safe fallback without analyser
      }
    }
  }, [audioUrl]);

  // Draw frame immediately whenever blueprint or scrubbed currentTime changes while paused
  useEffect(() => {
    const canvas = canvasRef.current;
    if (canvas) {
      const ctx = canvas.getContext("2d");
      if (ctx) renderVideoFrame(ctx, blueprint, currentTime);
    }
    if (!isPlaying && audioRef.current && audioUrl) {
      if (Math.abs(audioRef.current.currentTime - currentTime) > 0.1) {
        audioRef.current.currentTime = currentTime;
      }
    }
  }, [blueprint, currentTime, isPlaying, audioUrl]);

  useEffect(() => {
    if (!genProgress?.active) return;
    setGenNowMs(Date.now());
    const id = window.setInterval(() => setGenNowMs(Date.now()), 150);
    return () => window.clearInterval(id);
  }, [genProgress?.active]);

  // Sync audio element properties
  useEffect(() => {
    const audioEl = audioRef.current;
    if (!audioEl) return;
    audioEl.muted = isMuted || volume === 0;
    audioEl.volume = volume;
    audioEl.playbackRate = playbackRate;
  }, [isMuted, volume, playbackRate]);

  // Sync external seek into audio element when paused or jumped
  const seekTo = useCallback(
    (targetTime: number) => {
      const clamped = Math.max(
        0,
        Math.min(blueprintRef.current.totalDuration, targetTime)
      );
      onTimeUpdate(clamped);
      if (audioRef.current && audioUrl) {
        if (Math.abs(audioRef.current.currentTime - clamped) > 0.08) {
          audioRef.current.currentTime = clamped;
        }
      }
    },
    [audioUrl, onTimeUpdate]
  );

  // Playback animation loop
  useEffect(() => {
    if (!isPlaying) {
      if (audioRef.current && !audioRef.current.paused) {
        audioRef.current.pause();
      }
      return;
    }

    let rafId = 0;
    let lastTimestamp = performance.now();

    if (audioRef.current && audioUrl) {
      ensureAudioAnalyser();
      if (Math.abs(audioRef.current.currentTime - currentTimeRef.current) > 0.12) {
        audioRef.current.currentTime = currentTimeRef.current;
      }
      void audioRef.current.play().catch(() => {
        // Ignore autoplay restriction if triggered programmatically
      });
    }

    const tick = (now: number) => {
      const dt = (now - lastTimestamp) / 1000;
      lastTimestamp = now;

      const bp = blueprintRef.current;
      let nextTime = currentTimeRef.current;

      if (audioRef.current && audioUrl && !audioRef.current.paused) {
        nextTime = audioRef.current.currentTime;
      } else {
        nextTime = currentTimeRef.current + dt * playbackRate;
      }

      if (nextTime >= bp.totalDuration) {
        onTimeUpdate(0);
        if (audioRef.current && audioUrl) {
          audioRef.current.currentTime = 0;
          audioRef.current.pause();
        }
        onPlayStateChange(false);
        return;
      }

      onTimeUpdate(nextTime);

      const canvas = canvasRef.current;
      const ctx = canvas?.getContext("2d");
      if (ctx) {
        let bins: Uint8Array | undefined;
        if (analyserRef.current && binsBufferRef.current) {
          analyserRef.current.getByteFrequencyData(binsBufferRef.current);
          bins = binsBufferRef.current;
        }
        renderVideoFrame(ctx, bp, nextTime, bins);
      }

      if (isPlayingRef.current) {
        rafId = requestAnimationFrame(tick);
      }
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [
    isPlaying,
    audioUrl,
    playbackRate,
    ensureAudioAnalyser,
    onPlayStateChange,
    onTimeUpdate,
  ]);

  const handleTogglePlay = () => {
    if (currentTime >= blueprint.totalDuration - 0.05) {
      seekTo(0);
    }
    if (!isPlaying && audioUrl) {
      ensureAudioAnalyser();
    }
    onPlayStateChange(!isPlaying);
  };

  const detectExportCapabilities = useCallback(() => {
    if (typeof window === "undefined") {
      return {
        supported: false,
        reason: "Lingkungan browser tidak tersedia.",
        nativeMp4Mime: null as string | null,
        webmMime: null as string | null,
        isIosSafari: false,
      };
    }

    const ua = navigator.userAgent || "";
    const isIos =
      /iPad|iPhone|iPod/.test(ua) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    const isSafari = /Safari/i.test(ua) && !/Chrome|CriOS|FxiOS|Edg/i.test(ua);
    const isIosSafari = isIos || isSafari;

    if (typeof MediaRecorder === "undefined") {
      return {
        supported: false,
        reason:
          "Browser ini belum mendukung perekaman video (MediaRecorder tidak tersedia). Gunakan Chrome, Edge, atau Safari iOS 15+.",
        nativeMp4Mime: null as string | null,
        webmMime: null as string | null,
        isIosSafari,
      };
    }

    const testCanvas = document.createElement("canvas");
    const hasCaptureStream =
      typeof (testCanvas as HTMLCanvasElement & { captureStream?: unknown })
        .captureStream === "function";
    if (!hasCaptureStream) {
      return {
        supported: false,
        reason:
          "Browser ini tidak mendukung canvas.captureStream untuk merender video secara langsung.",
        nativeMp4Mime: null as string | null,
        webmMime: null as string | null,
        isIosSafari,
      };
    }

    const canCheckType = typeof MediaRecorder.isTypeSupported === "function";
    const mp4Candidates = [
      "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
      "video/mp4;codecs=avc1,mp4a.40.2",
      "video/mp4;codecs=h264,aac",
      "video/mp4",
    ];
    const webmCandidates = [
      "video/webm;codecs=vp9,opus",
      "video/webm;codecs=vp8,opus",
      "video/webm;codecs=vp9",
      "video/webm;codecs=vp8",
      "video/webm",
    ];

    const nativeMp4Mime = canCheckType
      ? mp4Candidates.find((m) => MediaRecorder.isTypeSupported(m)) ?? null
      : null;
    const webmMime = canCheckType
      ? webmCandidates.find((m) => MediaRecorder.isTypeSupported(m)) ?? null
      : isIosSafari
      ? null
      : "video/webm";

    if (!nativeMp4Mime && !webmMime) {
      return {
        supported: false,
        reason:
          "Browser tidak melaporkan codec rekaman video MP4 atau WebM yang didukung.",
        nativeMp4Mime: null,
        webmMime: null,
        isIosSafari,
      };
    }

    return {
      supported: true,
      reason: undefined,
      nativeMp4Mime,
      webmMime,
      isIosSafari,
    };
  }, []);

  const verifyBlobPlayable = async (blob: Blob): Promise<void> => {
    if (!blob || blob.size < 512) {
      throw new Error("Berkas video hasil render kosong atau terlalu kecil.");
    }
    const probeUrl = URL.createObjectURL(blob);
    try {
      await new Promise<void>((resolve, reject) => {
        const video = document.createElement("video");
        video.muted = true;
        video.playsInline = true;
        video.preload = "metadata";

        const timer = window.setTimeout(() => {
          cleanup();
          // Don't hard-fail if browser lacks decoder for WebM on Safari before server MP4 step,
          // just resolve once size > 512 has been verified.
          resolve();
        }, 2500);

        const cleanup = () => {
          window.clearTimeout(timer);
          video.onloadedmetadata = null;
          video.onerror = null;
          video.removeAttribute("src");
          video.load();
        };

        video.onloadedmetadata = () => {
          const widthOk = video.videoWidth > 0;
          const durOk = !Number.isFinite(video.duration) || video.duration >= 0;
          cleanup();
          if (!widthOk && !durOk) {
            reject(new Error("Metadata video hasil render tidak valid."));
          } else {
            resolve();
          }
        };
        video.onerror = () => {
          cleanup();
          // Non-empty blob could still be decoded by another player if MIME differs,
          // only reject when size is trivially corrupt; otherwise allow server conversion/download.
          if (blob.size < 1024) {
            reject(new Error("Video hasil render tidak dapat diputar."));
          } else {
            resolve();
          }
        };

        video.src = probeUrl;
      });
    } finally {
      URL.revokeObjectURL(probeUrl);
    }
  };

  const triggerBlobDownload = (blob: Blob, filename: string) => {
    const dlUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = dlUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(dlUrl), 30_000);
  };

  // Real Canvas + Audio MediaRecorder video export (MP4 native/FFmpeg + WebM fallback)
  const handleExportVideo = useCallback(async () => {
    if (isExporting) return;

    const caps = detectExportCapabilities();
    if (!caps.supported) {
      setExportError(
        caps.reason || "Perangkat/browser tidak mendukung ekspor video."
      );
      return;
    }

    cancelExportRef.current = false;
    exportAbortRef.current = new AbortController();
    setExportError(null);
    if (fallbackWebmUrl) {
      URL.revokeObjectURL(fallbackWebmUrl);
      setFallbackWebmUrl(null);
    }
    setIsExporting(true);
    setExportProgress(0);
    setExportStageLabel("Menyiapkan kanvas & audio...");
    setExportElapsed(0);
    setExportFps(30);
    onPlayStateChange(false);

    let exportAudioCtx: AudioContext | null = null;
    try {
      const bp = blueprintRef.current;
      const { width, height } = getCanvasDimensions(bp.aspectRatio);
      const offscreen = document.createElement("canvas");
      offscreen.width = width;
      offscreen.height = height;
      const ctx = offscreen.getContext("2d");
      if (!ctx) throw new Error("Kanvas ekspor 2D tidak tersedia.");

      // Draw initial frame before captureStream (required on Safari / iOS WebKit)
      renderVideoFrame(ctx, bp, 0);

      const stream = offscreen.captureStream(30);
      if (!stream || stream.getVideoTracks().length === 0) {
        throw new Error("Stream video kanvas gagal dibuat oleh browser.");
      }

      let audioSource: AudioBufferSourceNode | null = null;
      let exportAnalyser: AnalyserNode | null = null;
      let exportBins: Uint8Array<ArrayBuffer> | null = null;

      if (audioUrl) {
        const resp = await fetch(audioUrl);
        if (!resp.ok) {
          throw new Error("Audio narator gagal dibaca untuk proses ekspor.");
        }
        const arr = await resp.arrayBuffer();
        const AudioCtx =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext })
            .webkitAudioContext;
        exportAudioCtx = new AudioCtx();
        if (exportAudioCtx.state === "suspended") {
          await exportAudioCtx.resume();
        }
        const decoded = await exportAudioCtx.decodeAudioData(arr);
        const dest = exportAudioCtx.createMediaStreamDestination();
        exportAnalyser = exportAudioCtx.createAnalyser();
        exportAnalyser.fftSize = 128;
        exportBins = new Uint8Array(
          new ArrayBuffer(exportAnalyser.frequencyBinCount)
        );

        audioSource = exportAudioCtx.createBufferSource();
        audioSource.buffer = decoded;
        audioSource.connect(exportAnalyser);
        exportAnalyser.connect(dest);
        dest.stream.getAudioTracks().forEach((track) => stream.addTrack(track));
      }

      const wantMp4 = exportFormat === "mp4";
      let chosenMime: string;
      let needsServerMp4Conversion = false;

      if (wantMp4) {
        if (caps.nativeMp4Mime) {
          chosenMime = caps.nativeMp4Mime;
        } else if (caps.webmMime) {
          chosenMime = caps.webmMime;
          needsServerMp4Conversion = true;
        } else {
          throw new Error("Format MP4 atau WebM tidak didukung oleh browser ini.");
        }
      } else {
        if (caps.webmMime) {
          chosenMime = caps.webmMime;
        } else if (caps.nativeMp4Mime) {
          chosenMime = caps.nativeMp4Mime;
        } else {
          throw new Error("Format WebM tidak didukung oleh browser ini.");
        }
      }

      let recorder: MediaRecorder;
      try {
        recorder = new MediaRecorder(stream, {
          mimeType: chosenMime,
          videoBitsPerSecond: 6_000_000,
        });
      } catch {
        try {
          recorder = new MediaRecorder(stream, { mimeType: chosenMime });
        } catch {
          recorder = new MediaRecorder(stream);
        }
      }

      const recordedMimeType = recorder.mimeType || chosenMime;
      const chunks: Blob[] = [];
      recorder.ondataavailable = (ev) => {
        if (ev.data && ev.data.size > 0) chunks.push(ev.data);
      };

      const donePromise = new Promise<Blob>((resolve, reject) => {
        recorder.onerror = () => {
          reject(new Error("Terjadi kegagalan pada MediaRecorder saat merekam."));
        };
        recorder.onstop = () => {
          const outBlob = new Blob(chunks, {
            type: recordedMimeType.split(";")[0] || "video/webm",
          });
          resolve(outBlob);
        };
      });

      setExportStageLabel(
        needsServerMp4Conversion
          ? "Merender Video (Tahap 1/2: Perekaman)"
          : "Merender Video"
      );
      recorder.start(250);
      if (audioSource) audioSource.start(0);

      const startWall = performance.now();
      const total = Math.max(0.5, bp.totalDuration);
      let frameCount = 0;
      const maxRenderPct = needsServerMp4Conversion ? 82 : 99;

      const wasCancelled = await new Promise<boolean>((resolve) => {
        const step = () => {
          if (cancelExportRef.current) {
            resolve(true);
            return;
          }
          const elapsed = (performance.now() - startWall) / 1000;
          frameCount += 1;
          if (elapsed > 0.25) {
            setExportElapsed(elapsed);
            setExportFps(Math.max(1, Math.round(frameCount / elapsed)));
          }

          if (elapsed >= total) {
            renderVideoFrame(ctx, bp, total);
            setExportProgress(needsServerMp4Conversion ? 82 : 100);
            setExportElapsed(total);
            resolve(false);
            return;
          }
          if (exportAnalyser && exportBins) {
            exportAnalyser.getByteFrequencyData(exportBins);
          }
          renderVideoFrame(ctx, bp, elapsed, exportBins ?? undefined);
          setExportProgress(
            Math.min(maxRenderPct, Math.round((elapsed / total) * maxRenderPct))
          );
          requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
      });

      if (audioSource) {
        try {
          audioSource.stop();
        } catch {
          // ignore
        }
      }
      if (recorder.state !== "inactive") {
        recorder.stop();
      }
      const recordedBlob = await donePromise;

      if (wasCancelled || cancelExportRef.current) {
        return;
      }

      if (recordedBlob.size < 512) {
        throw new Error(
          "Rekaman video kanvas menghasilkan file kosong. Pastikan tab tetap aktif selama ekspor."
        );
      }

      const safeName =
        bp.title
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-|-$/g, "") || "izzy-video";

      if (needsServerMp4Conversion) {
        setExportStageLabel("Mengonversi ke MP4 (H.264 + AAC)...");
        setExportProgress(86);

        try {
          const convResp = await fetch(
            `/api/export-mp4?aspectRatio=${encodeURIComponent(bp.aspectRatio)}`,
            {
              method: "POST",
              headers: {
                "Content-Type":
                  recordedBlob.type || "video/webm",
              },
              body: recordedBlob,
              signal: exportAbortRef.current?.signal,
            }
          );

          if (!convResp.ok) {
            const errJson = (await convResp.json().catch(() => ({}))) as {
              error?: string;
            };
            throw new Error(
              errJson.error || `Konversi MP4 gagal (HTTP ${convResp.status}).`
            );
          }

          setExportProgress(96);
          const mp4Blob = await convResp.blob();
          await verifyBlobPlayable(mp4Blob);
          setExportProgress(100);
          triggerBlobDownload(mp4Blob, `${safeName}.mp4`);
          return;
        } catch (mp4Err) {
          if (cancelExportRef.current || exportAbortRef.current?.signal.aborted) {
            return;
          }
          // Keep valid WebM recording available as fallback instead of losing work
          const fbUrl = URL.createObjectURL(recordedBlob);
          setFallbackWebmUrl(fbUrl);
          setFallbackWebmName(`${safeName}.webm`);
          throw new Error(
            `${
              mp4Err instanceof Error ? mp4Err.message : "Konversi MP4 gagal."
            } Anda dapat mengunduh versi WebM cadangan di bawah.`
          );
        }
      }

      await verifyBlobPlayable(recordedBlob);
      const isMp4Output = recordedMimeType.includes("mp4");
      const ext = isMp4Output ? "mp4" : "webm";
      setExportProgress(100);
      triggerBlobDownload(recordedBlob, `${safeName}.${ext}`);
    } catch (err) {
      if (!cancelExportRef.current) {
        setExportError(
          err instanceof Error ? err.message : "Gagal mengekspor video."
        );
      }
    } finally {
      if (exportAudioCtx) {
        await exportAudioCtx.close().catch(() => {});
      }
      exportAbortRef.current = null;
      setIsExporting(false);
      cancelExportRef.current = false;
    }
  }, [
    audioUrl,
    detectExportCapabilities,
    exportFormat,
    fallbackWebmUrl,
    isExporting,
    onPlayStateChange,
  ]);

  const lastExportReqRef = useRef<number>(0);
  useEffect(() => {
    if (
      exportRequestCounter > 0 &&
      exportRequestCounter !== lastExportReqRef.current
    ) {
      lastExportReqRef.current = exportRequestCounter;
      void handleExportVideo();
    }
  }, [exportRequestCounter, handleExportVideo]);

  const aspectContainerClass =
    blueprint.aspectRatio === "9:16"
      ? "aspect-[9/16] max-h-[600px] w-auto mx-auto"
      : blueprint.aspectRatio === "1:1"
      ? "aspect-square max-h-[540px] w-auto mx-auto"
      : "aspect-video w-full max-w-[760px] mx-auto";

  return (
    <section className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col gap-4">
      {/* Stage Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div className="min-w-0">
          <h1 className="text-base font-bold text-slate-900 truncate">
            {blueprint.title}
          </h1>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mt-0.5 tabular-nums">
            <span>{styleMeta?.name}</span>
            <span aria-hidden="true">·</span>
            <span>{blueprint.aspectRatio}</span>
            <span aria-hidden="true">·</span>
            <span>{blueprint.scenes.length} adegan</span>
            <span aria-hidden="true">·</span>
            <span>
              {audioUrl
                ? blueprint.sourceMode === "audio"
                  ? "Audio Asli Tersinkron"
                  : "Suara Narator AI Aktif"
                : blueprint.audioMode === "no-audio"
                ? "Tanpa Audio · Visual & Subtitle"
                : "Pratinjau Visual"}
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center p-0.5 bg-slate-100 rounded-lg border border-slate-200">
            {(["mp4", "webm"] as const).map((fmt) => (
              <button
                key={fmt}
                type="button"
                disabled={isExporting}
                onClick={() => setExportFormat(fmt)}
                className={`px-2.5 py-1 text-[11px] font-semibold uppercase rounded-md transition-colors disabled:opacity-60 ${
                  exportFormat === fmt
                    ? "bg-white text-slate-900 shadow-xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                {fmt}
              </button>
            ))}
          </div>

          <button
            type="button"
            disabled={isExporting}
            onClick={() => void handleExportVideo()}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-slate-900 hover:bg-slate-800 disabled:bg-slate-400 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
          >
            {isExporting ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                <span className="tabular-nums">
                  Loading ({exportProgress}%)
                </span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                <span>Unduh Video (.{exportFormat})</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Canvas Viewport */}
      <div className="bg-[#EFECE6] border border-slate-200 rounded-xl p-4 sm:p-6 flex items-center justify-center min-h-[420px] relative">
        <div
          className={`${aspectContainerClass} relative shadow-lg rounded-lg overflow-hidden bg-slate-900`}
        >
          <canvas
            ref={canvasRef}
            width={dims.width}
            height={dims.height}
            onClick={handleTogglePlay}
            className="w-full h-full block cursor-pointer"
          />

          {genProgress?.active && (
            <div className="absolute inset-0 bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-5">
              <div className="w-full max-w-xs bg-white border border-slate-200 rounded-xl p-4 shadow-xl flex flex-col gap-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-900 flex items-center gap-1.5">
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-700" />
                    <span>Loading ({genProgress.percent}%)</span>
                  </span>
                  <span className="font-mono font-bold text-blue-700 tabular-nums">
                    {genProgress.percent}%
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-blue-700 transition-all duration-300"
                    style={{ width: `${Math.max(4, genProgress.percent)}%` }}
                  />
                </div>
                <p className="text-xs text-slate-700 font-medium">
                  {genProgress.stageLabel}
                </p>
                {genProgress.detailLabel && (
                  <p className="text-[11px] text-slate-500 leading-snug">
                    {genProgress.detailLabel}
                  </p>
                )}
                <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 tabular-nums">
                  <span>
                    Berjalan:{" "}
                    {Math.max(
                      0.1,
                      (genNowMs - genProgress.startedAt) / 1000
                    ).toFixed(1)}
                    d
                  </span>
                  <span>
                    Est. total: ~{genProgress.estimatedTotalSeconds || 9}d
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {workflowState === "failed" && errorMsg && !genProgress?.active && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 flex flex-col gap-2">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-start gap-2 text-xs text-red-800 min-w-0 flex-1">
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span className="leading-snug">{errorMsg}</span>
            </div>
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              {canRetry && onRetry && (
                <button
                  type="button"
                  onClick={onRetry}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-red-700 hover:bg-red-800 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>{retryLabel}</span>
                </button>
              )}
              {failureDiagnostic?.failedStage === "tts" &&
                onExportWithoutAudio && (
                  <button
                    type="button"
                    onClick={onExportWithoutAudio}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Ekspor Tanpa Narasi</span>
                  </button>
                )}
            </div>
          </div>
          {failureDiagnostic && (
            <div className="text-[11px] font-mono text-red-900/90 bg-white/75 border border-red-200 rounded px-2.5 py-1 break-words">
              Endpoint: {failureDiagnostic.endpoint} · Tahap:{" "}
              {failureDiagnostic.failedStage} · Model:{" "}
              {failureDiagnostic.model} · Status:{" "}
              {failureDiagnostic.httpStatus ?? "-"} · Penyebab:{" "}
              {failureDiagnostic.causeType === "quota_exhausted"
                ? "Kuota API habis"
                : failureDiagnostic.causeType === "rate_limit"
                ? "Rate limit API"
                : failureDiagnostic.causeType}
              {failureDiagnostic.retryAfterSeconds
                ? ` · Retry-After: ${failureDiagnostic.retryAfterSeconds}d`
                : ""}
            </div>
          )}
        </div>
      )}

      <audio ref={audioRef} src={audioUrl ?? undefined} preload="auto" className="hidden" />

      {isExporting && (
        <div className="rounded-lg border border-slate-200 bg-slate-50 p-3.5 flex flex-col gap-2">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-900">
              <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-700" />
              <span>Loading · {exportStageLabel}</span>
              <span className="font-mono font-bold text-blue-700 tabular-nums">
                ({exportProgress}%)
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                cancelExportRef.current = true;
                exportAbortRef.current?.abort();
              }}
              className="inline-flex items-center gap-1 px-2 py-1 rounded border border-slate-200 bg-white hover:bg-slate-100 text-[11px] font-semibold text-slate-700"
            >
              <X className="w-3 h-3" />
              <span>Batal</span>
            </button>
          </div>
          <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-700 transition-all duration-150"
              style={{ width: `${Math.max(2, exportProgress)}%` }}
            />
          </div>
          <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-slate-600 tabular-nums">
            <span>
              Berjalan: {exportElapsed.toFixed(1)}d /{" "}
              {blueprint.totalDuration.toFixed(1)}d
            </span>
            <span>
              Sisa waktu: ~
              {Math.max(0, blueprint.totalDuration - exportElapsed).toFixed(1)}d
            </span>
            <span>Kecepatan: 1.0x ({exportFps} fps)</span>
          </div>
        </div>
      )}

      {exportError && (
        <div className="text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2 flex flex-wrap items-center justify-between gap-2">
          <span>{exportError}</span>
          {fallbackWebmUrl && (
            <a
              href={fallbackWebmUrl}
              download={fallbackWebmName}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 hover:bg-slate-800 text-white text-[11px] font-semibold shrink-0"
            >
              <Download className="w-3 h-3" />
              <span>Unduh Fallback (.webm)</span>
            </a>
          )}
        </div>
      )}

      {/* Playback Transport & Scene Timeline */}
      <div className="flex flex-col gap-3 pt-1">
        {/* Segmented Timeline Scrubber */}
        <div className="flex flex-col gap-1.5">
          <div className="relative flex items-center gap-1 h-7 bg-slate-100 rounded-lg p-1 overflow-hidden">
            {blueprint.scenes.map((scene, idx) => {
              const widthPct =
                (scene.durationSeconds / Math.max(0.1, blueprint.totalDuration)) *
                100;
              const isPassed = currentTime >= scene.endTime;
              const isCurrent =
                currentTime >= scene.startTime && currentTime < scene.endTime;
              const localPct = isCurrent
                ? ((currentTime - scene.startTime) /
                    Math.max(0.1, scene.durationSeconds)) *
                  100
                : isPassed
                ? 100
                : 0;

              return (
                <button
                  key={scene.id}
                  type="button"
                  title={`${idx + 1}. ${scene.topTitle} (${scene.durationSeconds.toFixed(1)}s)`}
                  onClick={() => seekTo(scene.startTime + 0.02)}
                  style={{ width: `${widthPct}%` }}
                  className="relative h-full rounded-sm bg-slate-200 overflow-hidden text-left group focus-visible:outline-2 focus-visible:outline-blue-700"
                >
                  <div
                    className="h-full bg-blue-700 transition-none"
                    style={{ width: `${localPct}%` }}
                  />
                </button>
              );
            })}
          </div>

          <input
            type="range"
            aria-label="Garis waktu video"
            min={0}
            max={Math.max(0.1, blueprint.totalDuration)}
            step={0.05}
            value={currentTime}
            onChange={(e) => seekTo(Number(e.target.value))}
            className="w-full accent-blue-700 cursor-pointer h-1.5"
          />
        </div>

        {/* Transport Controls Row */}
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleTogglePlay}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
            >
              {isPlaying ? (
                <>
                  <Pause className="w-3.5 h-3.5 fill-current" />
                  <span>Jeda</span>
                </>
              ) : (
                <>
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Putar</span>
                </>
              )}
            </button>

            <button
              type="button"
              onClick={() => {
                seekTo(0);
                onPlayStateChange(true);
              }}
              title="Ulangi dari awal"
              className="p-2 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2 border border-slate-200 rounded-lg px-2 py-1 bg-white shrink-0">
              <button
                type="button"
                onClick={() => {
                  if (isMuted || volume === 0) {
                    setIsMuted(false);
                    if (volume === 0) setVolume(0.8);
                  } else {
                    setIsMuted(true);
                  }
                }}
                title={isMuted || volume === 0 ? "Bunyikan audio" : "Bisukan audio"}
                aria-label={
                  isMuted || volume === 0 ? "Bunyikan audio" : "Bisukan audio"
                }
                className="p-1 rounded text-slate-700 hover:bg-slate-100 transition-colors"
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-4 h-4" />
                ) : volume < 0.5 ? (
                  <Volume1 className="w-4 h-4" />
                ) : (
                  <Volume2 className="w-4 h-4" />
                )}
              </button>

              <input
                type="range"
                aria-label="Volume audio"
                min={0}
                max={1}
                step={0.01}
                value={isMuted ? 0 : volume}
                onChange={(e) => {
                  const nextVolume = Number(e.target.value);
                  setVolume(nextVolume);
                  setIsMuted(nextVolume === 0);
                  if (audioRef.current) {
                    audioRef.current.volume = nextVolume;
                    audioRef.current.muted = nextVolume === 0;
                  }
                }}
                className="w-20 accent-blue-700 cursor-pointer h-1.5"
              />

              <span className="hidden sm:inline-block w-8 text-right text-[11px] font-mono text-slate-500 tabular-nums">
                {Math.round((isMuted ? 0 : volume) * 100)}%
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-1 p-0.5 bg-slate-100 rounded-md">
              {[0.75, 1, 1.25].map((rate) => (
                <button
                  key={rate}
                  type="button"
                  onClick={() => setPlaybackRate(rate)}
                  className={`px-2 py-1 text-xs font-mono rounded-sm transition-colors ${
                    playbackRate === rate
                      ? "bg-white text-slate-900 shadow-xs font-semibold"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  {rate}x
                </button>
              ))}
            </div>

            <span className="text-xs font-mono font-semibold text-slate-700 tabular-nums whitespace-nowrap">
              {currentTime.toFixed(1)}s / {blueprint.totalDuration.toFixed(1)}s
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};
