import React, { useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  FileAudio,
  Loader2,
  Mic,
  RotateCw,
  Square,
  Type as TypeIcon,
  Upload,
} from "lucide-react";
import {
  LANGUAGE_PREFERENCE_OPTIONS,
  TOPIC_PRESETS,
  VIDEO_STYLES,
  VOICE_OPTIONS,
} from "../data/presets";
import type {
  AspectRatio,
  FailureDiagnostic,
  GenerationWorkflowState,
  LanguagePreference,
  ModelUsageReport,
  ProcessProgress,
  VideoStyleId,
  VoiceName,
} from "../types/video";
import { StyleLoopPreview } from "./StyleLoopPreview";

type TextAudioMode = "ai-narration" | "no-audio";

interface InputDirectorPanelProps {
  activeStyle: VideoStyleId;
  onSelectStyle: (style: VideoStyleId) => void;
  activeAspectRatio: AspectRatio;
  onSelectAspectRatio: (ratio: AspectRatio) => void;
  isGenerating: boolean;
  workflowState: GenerationWorkflowState;
  genProgress: ProcessProgress;
  errorMsg: string | null;
  failureDiagnostic?: FailureDiagnostic | null;
  retryLabel?: string;
  onExportWithoutAudio?: () => void;
  modelReports: ModelUsageReport[];
  canRetry: boolean;
  onRetry: () => void;
  onGenerateFromText: (params: {
    prompt: string;
    style: VideoStyleId;
    aspectRatio: AspectRatio;
    durationPreset: "short" | "medium" | "long";
    voiceName: VoiceName;
    brandHandle: string;
    audioMode: TextAudioMode;
    languagePreference: LanguagePreference;
  }) => void;
  onGenerateFromAudio: (params: {
    audioBase64: string;
    mimeType: string;
    audioUrl: string;
    durationSeconds: number;
    style: VideoStyleId;
    aspectRatio: AspectRatio;
    visualHint: string;
    brandHandle: string;
    languagePreference: LanguagePreference;
  }) => void;
}

export const InputDirectorPanel: React.FC<InputDirectorPanelProps> = ({
  activeStyle,
  onSelectStyle,
  activeAspectRatio,
  onSelectAspectRatio,
  isGenerating,
  workflowState,
  genProgress,
  errorMsg,
  failureDiagnostic = null,
  retryLabel = "Coba Lagi",
  onExportWithoutAudio,
  modelReports,
  canRetry,
  onRetry,
  onGenerateFromText,
  onGenerateFromAudio,
}) => {
  const [inputMode, setInputMode] = useState<"text" | "audio">("text");
  const [prompt, setPrompt] = useState<string>(TOPIC_PRESETS[0].prompt);
  const [durationPreset, setDurationPreset] = useState<
    "short" | "medium" | "long"
  >("medium");
  const [voiceName, setVoiceName] = useState<VoiceName>("Kore");
  const [audioMode, setAudioMode] = useState<TextAudioMode>("ai-narration");
  const [languagePreference, setLanguagePreference] =
    useState<LanguagePreference>("auto");
  const [brandHandle, setBrandHandle] = useState<string>("@IZZY.STUDIO");

  // Audio mode state
  const [audioFileName, setAudioFileName] = useState<string>("");
  const [audioBase64, setAudioBase64] = useState<string>("");
  const [audioMimeType, setAudioMimeType] = useState<string>("audio/webm");
  const [audioUrl, setAudioUrl] = useState<string>("");
  const [audioDuration, setAudioDuration] = useState<number>(0);
  const [visualHint, setVisualHint] = useState<string>("");
  const [audioError, setAudioError] = useState<string | null>(null);

  // Live mic recorder state
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingSeconds, setRecordingSeconds] = useState<number>(0);
  const [nowMs, setNowMs] = useState<number>(() => Date.now());
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordChunksRef = useRef<Blob[]>([]);
  const recordTimerRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (!isGenerating) return;
    setNowMs(Date.now());
    const id = window.setInterval(() => setNowMs(Date.now()), 150);
    return () => window.clearInterval(id);
  }, [isGenerating]);

  const elapsedSec = isGenerating
    ? Math.max(0.1, (nowMs - genProgress.startedAt) / 1000)
    : 0;
  const estTotal = genProgress.estimatedTotalSeconds || 9;
  const remainingSec =
    genProgress.percent >= 98
      ? 0.2
      : genProgress.percent > 15
      ? Math.max(
          0.5,
          (elapsedSec / genProgress.percent) * (100 - genProgress.percent)
        )
      : Math.max(1, estTotal - elapsedSec);
  const speedText =
    elapsedSec > 0 && genProgress.percent > 0
      ? genProgress.percent / elapsedSec >= 9
        ? "Cepat"
        : "Normal"
      : "Menghitung...";

  useEffect(() => {
    return () => {
      if (recordTimerRef.current) window.clearInterval(recordTimerRef.current);
      if (audioUrl) URL.revokeObjectURL(audioUrl);
    };
  }, [audioUrl]);

  const decodeAudioMetadata = async (blob: Blob, label: string) => {
    setAudioError(null);
    if (blob.size < 128) {
      setAudioError("File audio kosong atau terlalu kecil untuk diproses.");
      return;
    }
    if (blob.size > 20 * 1024 * 1024) {
      setAudioError("Ukuran file audio maksimal 20 MB.");
      return;
    }

    const url = URL.createObjectURL(blob);
    try {
      const arrayBuf = await blob.arrayBuffer();
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext;
      const ctx = new AudioCtx();
      const decoded = await ctx.decodeAudioData(arrayBuf.slice(0));
      await ctx.close();

      if (!Number.isFinite(decoded.duration) || decoded.duration < 0.3) {
        URL.revokeObjectURL(url);
        setAudioError("Durasi audio terlalu pendek (minimal 0.3 detik).");
        return;
      }

      // Convert to base64
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const result = String(reader.result || "");
          const comma = result.indexOf(",");
          resolve(comma >= 0 ? result.slice(comma + 1) : result);
        };
        reader.onerror = () => reject(new Error("Gagal membaca file audio."));
        reader.readAsDataURL(blob);
      });

      const normalizedMime =
        (blob.type || "audio/webm").split(";")[0].trim().toLowerCase() ||
        "audio/webm";

      if (audioUrl) URL.revokeObjectURL(audioUrl);
      setAudioUrl(url);
      setAudioBase64(base64);
      setAudioMimeType(normalizedMime);
      setAudioDuration(decoded.duration);
      setAudioFileName(label);
    } catch {
      URL.revokeObjectURL(url);
      setAudioError(
        "Format audio tidak terbaca oleh browser. Gunakan MP3, WAV, M4A, atau rekam langsung."
      );
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    void decodeAudioMetadata(file, file.name);
  };

  const toggleRecording = async () => {
    if (isRecording) {
      mediaRecorderRef.current?.stop();
      setIsRecording(false);
      if (recordTimerRef.current) {
        window.clearInterval(recordTimerRef.current);
        recordTimerRef.current = null;
      }
      return;
    }

    setAudioError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimeType = MediaRecorder.isTypeSupported("audio/webm;codecs=opus")
        ? "audio/webm;codecs=opus"
        : "audio/webm";
      const recorder = new MediaRecorder(stream, { mimeType });
      recordChunksRef.current = [];

      recorder.ondataavailable = (ev) => {
        if (ev.data.size > 0) recordChunksRef.current.push(ev.data);
      };
      recorder.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(recordChunksRef.current, { type: "audio/webm" });
        void decodeAudioMetadata(blob, `Rekaman Suara (${recordingSeconds}d).webm`);
      };

      mediaRecorderRef.current = recorder;
      recorder.start(250);
      setRecordingSeconds(0);
      setIsRecording(true);
      recordTimerRef.current = window.setInterval(() => {
        setRecordingSeconds((s) => s + 1);
      }, 1000);
    } catch {
      setAudioError(
        "Izin mikrofon ditolak atau tidak tersedia. Anda tetap dapat mengunggah file audio."
      );
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isGenerating) return;
    if (inputMode === "text") {
      onGenerateFromText({
        prompt,
        style: activeStyle,
        aspectRatio: activeAspectRatio,
        durationPreset,
        voiceName,
        brandHandle,
        audioMode,
        languagePreference,
      });
    } else {
      if (!audioBase64 || !audioDuration) {
        setAudioError("Unggah file audio atau rekam suara terlebih dahulu.");
        return;
      }
      onGenerateFromAudio({
        audioBase64,
        mimeType: audioMimeType,
        audioUrl,
        durationSeconds: audioDuration,
        style: activeStyle,
        aspectRatio: activeAspectRatio,
        visualHint,
        brandHandle,
        languagePreference,
      });
    }
  };

  return (
    <aside className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col gap-5 h-fit">
      <form onSubmit={handleSubmit} className="flex flex-col gap-5">
        {/* Source Mode Switcher */}
        <div>
          <span className="block text-xs font-semibold text-slate-500 mb-2">
            Sumber Konten Otomatis
          </span>
          <div className="grid grid-cols-2 gap-1 p-1 bg-slate-100 rounded-lg">
            <button
              type="button"
              disabled={isGenerating}
              onClick={() => setInputMode("text")}
              className={`flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 disabled:opacity-60 ${
                inputMode === "text"
                  ? "bg-white text-slate-900 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <TypeIcon className="w-3.5 h-3.5" />
              <span>Input Teks</span>
            </button>
            <button
              type="button"
              disabled={isGenerating}
              onClick={() => setInputMode("audio")}
              className={`flex items-center justify-center gap-2 py-2 px-3 text-xs font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 disabled:opacity-60 ${
                inputMode === "audio"
                  ? "bg-white text-slate-900 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              <FileAudio className="w-3.5 h-3.5" />
              <span>Input Audio</span>
            </button>
          </div>
        </div>

        {/* Mode 1: Text Input */}
        {inputMode === "text" ? (
          <div className="flex flex-col gap-3">
            <div className="flex items-center justify-between">
              <label
                htmlFor="topic-prompt"
                className="text-xs font-semibold text-slate-700"
              >
                Topik atau Naskah Video
              </label>
              <span className="text-xs text-slate-400 tabular-nums">
                {prompt.length} karakter
              </span>
            </div>

            <textarea
              id="topic-prompt"
              rows={5}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Tuliskan topik berita, poin data, atau naskah narasi Anda di sini..."
              className="w-full rounded-lg border border-slate-200 bg-slate-50/70 px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-700 focus:bg-white focus:outline-none transition-colors leading-relaxed"
            />

            <div className="flex flex-wrap gap-1.5">
              {TOPIC_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => setPrompt(preset.prompt)}
                  className="text-xs font-medium px-2.5 py-1.5 rounded-md border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:border-slate-300 transition-colors whitespace-nowrap shrink-0"
                >
                  {preset.label}
                </button>
              ))}
            </div>

            {/* Duration & Voice */}
            <div className="grid grid-cols-1 gap-3 pt-1 border-t border-slate-100">
              <div>
                <span className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Durasi & Tempo Adegan
                </span>
                <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-lg">
                  {(
                    [
                      { id: "short", label: "Ringkas 20d" },
                      { id: "medium", label: "Standar 35d" },
                      { id: "long", label: "Penuh 55d" },
                    ] as const
                  ).map((item) => (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => setDurationPreset(item.id)}
                      className={`py-1.5 px-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                        durationPreset === item.id
                          ? "bg-white text-slate-900 shadow-xs"
                          : "text-slate-600 hover:text-slate-900"
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="block text-xs font-semibold text-slate-700 mb-1.5">
                  Audio Video
                </span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    disabled={isGenerating}
                    onClick={() => setAudioMode("ai-narration")}
                    className={`text-left px-3 py-2 rounded-lg border transition-colors disabled:opacity-60 ${
                      audioMode === "ai-narration"
                        ? "border-blue-700 bg-blue-50/70 text-slate-900"
                        : "border-slate-200 bg-white text-slate-700 hover:border-slate-300"
                    }`}
                  >
                    <div className="text-xs font-bold leading-tight">
                      Dengan Narasi AI
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                      Suara Gemini TTS
                    </div>
                  </button>

                  <button
                    type="button"
                    disabled={isGenerating}
                    onClick={() => setAudioMode("no-audio")}
                    className={`text-left px-3 py-2 rounded-lg border transition-colors disabled:opacity-60 ${
                      audioMode === "no-audio"
                        ? "border-blue-700 bg-blue-50/70 text-slate-900"
                        : "border-slate-200 bg-white text-slate-700 hover:border-slate-300"
                    }`}
                  >
                    <div className="text-xs font-bold leading-tight">
                      Tanpa Audio
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5 leading-snug">
                      Visual & subtitle saja
                    </div>
                  </button>
                </div>
                <p className="text-[11px] text-slate-500 mt-1.5 leading-snug">
                  Tanpa Audio menghemat kuota Gemini TTS.
                </p>
              </div>

              {audioMode === "ai-narration" && (
                <div>
                  <label
                    htmlFor="voice-select"
                    className="block text-xs font-semibold text-slate-700 mb-1.5"
                  >
                    Suara Narator AI
                  </label>
                  <select
                    id="voice-select"
                    value={voiceName}
                    onChange={(e) => setVoiceName(e.target.value as VoiceName)}
                    className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-700 focus:outline-none"
                  >
                    {VOICE_OPTIONS.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.label} — {v.tone}
                      </option>
                    ))}
                  </select>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* Mode 2: Sound / Audio Input */
          <div className="flex flex-col gap-3">
            <span className="text-xs font-semibold text-slate-700">
              Unggah File Suara atau Rekam Langsung
            </span>

            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-800 transition-colors whitespace-nowrap shrink-0"
              >
                <Upload className="w-4 h-4" />
                <span>Pilih File Audio</span>
              </button>

              <button
                type="button"
                onClick={() => void toggleRecording()}
                className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-lg border text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                  isRecording
                    ? "border-red-600 bg-red-600 text-white"
                    : "border-slate-200 bg-white hover:bg-slate-50 text-slate-800"
                }`}
              >
                {isRecording ? (
                  <>
                    <Square className="w-3.5 h-3.5 fill-current" />
                    <span className="tabular-nums">Stop ({recordingSeconds}d)</span>
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4" />
                    <span>Rekam Suara</span>
                  </>
                )}
              </button>
            </div>

            <input
              ref={fileInputRef}
              type="file"
              accept="audio/*"
              onChange={handleFileChange}
              className="hidden"
            />

            {audioUrl && (
              <div className="border border-slate-200 rounded-lg p-3 bg-slate-50 flex flex-col gap-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-800 truncate max-w-[200px]">
                    {audioFileName}
                  </span>
                  <span className="font-mono text-slate-500 tabular-nums">
                    {audioDuration.toFixed(1)}s
                  </span>
                </div>
                <audio controls src={audioUrl} className="w-full h-8" />
              </div>
            )}

            <div>
              <label
                htmlFor="visual-hint"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Arahan Visual Tambahan (Opsional)
              </label>
              <input
                id="visual-hint"
                type="text"
                value={visualHint}
                onChange={(e) => setVisualHint(e.target.value)}
                placeholder="Misal: tampilkan grafik pertumbuhan dan tabel bukti"
                className="w-full rounded-lg border border-slate-200 bg-slate-50/70 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-700 focus:bg-white focus:outline-none"
              />
            </div>

            {audioError && (
              <p className="text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                {audioError}
              </p>
            )}
          </div>
        )}

        {/* Multilingual Mode Selector */}
        <div className="pt-2 border-t border-slate-100">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-semibold text-slate-700">
              Bahasa Narasi & Subtitle
            </span>
            <span className="text-[11px] text-slate-400">
              {LANGUAGE_PREFERENCE_OPTIONS.find(
                (o) => o.id === languagePreference
              )?.description}
            </span>
          </div>
          <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-lg">
            {LANGUAGE_PREFERENCE_OPTIONS.map((opt) => (
              <button
                key={opt.id}
                type="button"
                disabled={isGenerating}
                onClick={() => setLanguagePreference(opt.id)}
                className={`py-1.5 px-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 disabled:opacity-60 ${
                  languagePreference === opt.id
                    ? "bg-white text-slate-900 shadow-xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Model Selection (5 Video Models) */}
        <div className="pt-2 border-t border-slate-100">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-semibold text-slate-700">
              Model Visual Video
            </span>
            <span className="text-xs text-slate-400">5 model tersedia</span>
          </div>

          <div className="flex flex-col gap-2">
            {VIDEO_STYLES.map((style) => {
              const selected = activeStyle === style.id;
              return (
                <button
                  key={style.id}
                  type="button"
                  onClick={() => onSelectStyle(style.id)}
                  className={`w-full text-left p-2 rounded-lg border transition-colors flex items-center gap-3 ${
                    selected
                      ? "border-blue-700 bg-blue-50/50"
                      : "border-slate-200 bg-white hover:border-slate-300"
                  }`}
                >
                  <StyleLoopPreview
                    styleId={style.id}
                    resolution="thumb"
                    className="w-24 aspect-video rounded-md border border-slate-200 shrink-0"
                  />
                  <div className="min-w-0 flex-1">
                    <div className="text-xs font-bold text-slate-900 leading-tight truncate">
                      {style.name}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1 leading-snug line-clamp-2">
                      {style.tagline}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Aspect Ratio & Handle */}
        <div className="grid grid-cols-1 gap-3 pt-2 border-t border-slate-100">
          <div>
            <span className="block text-xs font-semibold text-slate-700 mb-1.5">
              Rasio Aspek Kanvas
            </span>
            <div className="grid grid-cols-3 gap-1 p-1 bg-slate-100 rounded-lg">
              {(
                [
                  { id: "9:16", label: "9:16 Reels" },
                  { id: "16:9", label: "16:9 Wide" },
                  { id: "1:1", label: "1:1 Feed" },
                ] as const
              ).map((r) => (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => onSelectAspectRatio(r.id)}
                  className={`py-1.5 px-2 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    activeAspectRatio === r.id
                      ? "bg-white text-slate-900 shadow-xs"
                      : "text-slate-600 hover:text-slate-900"
                  }`}
                >
                  {r.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label
              htmlFor="brand-handle"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Watermark Akun
            </label>
            <input
              id="brand-handle"
              type="text"
              value={brandHandle}
              onChange={(e) => setBrandHandle(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-1.5 text-xs font-mono text-slate-800 focus:border-blue-700 focus:outline-none"
            />
          </div>
        </div>

        {errorMsg && (
          <div className="text-xs text-red-800 bg-red-50 border border-red-200 rounded-lg p-3 flex flex-col gap-2.5">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">{errorMsg}</div>
            </div>
            {failureDiagnostic && (
              <div className="text-[11px] font-mono bg-white/80 border border-red-200 rounded px-2.5 py-1.5 text-red-900 space-y-0.5 break-words">
                <div>
                  Endpoint: {failureDiagnostic.endpoint} · Tahap:{" "}
                  {failureDiagnostic.failedStage} · Model:{" "}
                  {failureDiagnostic.model}
                </div>
                <div>
                  Status: {failureDiagnostic.httpStatus ?? "-"} · Penyebab:{" "}
                  {failureDiagnostic.causeType === "quota_exhausted"
                    ? "Kuota API habis"
                    : failureDiagnostic.causeType === "rate_limit"
                    ? "Rate limit API"
                    : failureDiagnostic.causeType}
                  {failureDiagnostic.retryAfterSeconds
                    ? ` · Retry-After: ${failureDiagnostic.retryAfterSeconds}d`
                    : ""}
                </div>
                {failureDiagnostic.quotaMetric && (
                  <div className="text-[10px] text-red-700">
                    Metrik: {failureDiagnostic.quotaMetric}
                  </div>
                )}
              </div>
            )}
            <div className="flex flex-wrap items-center gap-2">
              {canRetry && !isGenerating && (
                <button
                  type="button"
                  onClick={onRetry}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-red-700 hover:bg-red-800 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
                >
                  <RotateCw className="w-3.5 h-3.5" />
                  <span>{retryLabel}</span>
                </button>
              )}
              {failureDiagnostic?.failedStage === "tts" &&
                onExportWithoutAudio &&
                !isGenerating && (
                  <button
                    type="button"
                    onClick={onExportWithoutAudio}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
                  >
                    <span>Ekspor Tanpa Narasi</span>
                  </button>
                )}
            </div>
          </div>
        )}

        {workflowState === "completed" && !errorMsg && !isGenerating && (
          <div className="text-xs text-emerald-900 bg-emerald-50 border border-emerald-200 rounded-lg p-3 flex flex-col gap-1.5">
            <div className="flex items-center gap-1.5 font-semibold">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>{genProgress.stageLabel || "Video selesai dibuat."}</span>
            </div>
            {modelReports.some((r) => r.fallbackUsed) && (
              <div className="text-[11px] text-amber-900 bg-amber-50 border border-amber-200 rounded-md px-2.5 py-1.5 mt-1 leading-snug">
                {modelReports
                  .filter((r) => r.fallbackUsed)
                  .map((r) => (
                    <div key={`${r.task}-${r.usedModel}`}>
                      Pemberitahuan model: beralih dari{" "}
                      <span className="font-mono font-semibold">{r.primaryModel}</span> ke{" "}
                      <span className="font-mono font-semibold">{r.usedModel}</span>
                      {r.fallbackReason ? ` (${r.fallbackReason})` : ""}.
                    </div>
                  ))}
              </div>
            )}
          </div>
        )}

        {isGenerating && (
          <div className="rounded-lg border border-blue-200 bg-blue-50/70 p-3 flex flex-col gap-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-900">
                Loading ({genProgress.percent}%)
              </span>
              <span className="font-mono font-bold text-blue-700 tabular-nums">
                {genProgress.percent}%
              </span>
            </div>
            <div className="w-full h-2 bg-blue-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-blue-700 transition-all duration-300"
                style={{ width: `${Math.max(4, genProgress.percent)}%` }}
              />
            </div>
            <p className="text-xs text-slate-700 leading-snug">
              {genProgress.stageLabel}
            </p>
            {genProgress.detailLabel && (
              <p className="text-[11px] text-slate-500 leading-snug">
                {genProgress.detailLabel}
              </p>
            )}
            <div className="flex items-center justify-between text-[11px] font-mono text-slate-500 tabular-nums pt-0.5">
              <span>Berjalan: {elapsedSec.toFixed(1)}d</span>
              <span>Sisa: ~{remainingSec.toFixed(1)}d</span>
              <span>{speedText}</span>
            </div>
          </div>
        )}

        <button
          type="submit"
          disabled={isGenerating}
          className="w-full py-3 px-4 rounded-lg bg-blue-700 hover:bg-blue-800 disabled:bg-blue-400 disabled:cursor-not-allowed text-white text-sm font-semibold transition-colors flex items-center justify-center gap-2 whitespace-nowrap shrink-0"
        >
          {isGenerating ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span className="tabular-nums">
                Loading ({genProgress.percent}%)...
              </span>
            </>
          ) : (
            <span>
              {inputMode === "text"
                ? "Buat Video dari Teks"
                : "Buat Video dari Audio"}
            </span>
          )}
        </button>
      </form>
    </aside>
  );
};
