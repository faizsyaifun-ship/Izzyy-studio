import React from "react";
import { ArrowRight, Check } from "lucide-react";
import { VIDEO_STYLES } from "../data/presets";
import type { VideoStyleId } from "../types/video";
import { StyleLoopPreview } from "./StyleLoopPreview";

interface ReferenceAndModelsViewProps {
  mode: "models" | "reference" | "guide";
  activeStyle: VideoStyleId;
  onSelectStyleAndOpenStudio: (style: VideoStyleId) => void;
  onBackToStudio: () => void;
}

export const ReferenceAndModelsView: React.FC<ReferenceAndModelsViewProps> = ({
  mode,
  activeStyle,
  onSelectStyleAndOpenStudio,
  onBackToStudio,
}) => {
  if (mode === "models") {
    return (
      <div className="max-w-[1200px] mx-auto py-8 px-4 sm:px-6 flex flex-col gap-6">
        <div className="flex flex-wrap items-end justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              Katalog Model Visual Video
            </h1>
            <p className="text-sm text-slate-600 mt-1 max-w-2xl">
              Setiap model mengubah keseluruhan tata letak, palet warna, tipografi,
              dan cara data disajikan secara otomatis tanpa perlu menyusun ulang
              naskah Anda.
            </p>
          </div>
          <button
            type="button"
            onClick={onBackToStudio}
            className="px-4 py-2 rounded-lg border border-slate-200 bg-white hover:bg-slate-50 text-xs font-semibold text-slate-800 whitespace-nowrap shrink-0"
          >
            Kembali ke Studio
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {VIDEO_STYLES.map((style) => {
            const isSelected = activeStyle === style.id;
            return (
              <div
                key={style.id}
                className={`bg-white rounded-xl border p-5 flex flex-col justify-between gap-4 transition-colors ${
                  isSelected ? "border-blue-700" : "border-slate-200"
                }`}
              >
                <div className="flex flex-col gap-3">
                  {/* Live 3-second looping animated model preview */}
                  <StyleLoopPreview
                    styleId={style.id}
                    resolution="card"
                    showLoopBar
                    className="w-full aspect-video rounded-lg border border-slate-200"
                  />

                  <div>
                    <h3 className="text-sm font-bold text-slate-900">
                      {style.name}
                    </h3>
                    <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                      {style.tagline}
                    </p>
                  </div>

                  <div className="text-xs text-slate-500 pt-2 border-t border-slate-100">
                    Cocok untuk: {style.bestFor}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => onSelectStyleAndOpenStudio(style.id)}
                  className={`w-full py-2.5 px-4 rounded-lg text-xs font-semibold transition-colors flex items-center justify-center gap-2 whitespace-nowrap shrink-0 ${
                    isSelected
                      ? "bg-blue-50 text-blue-800 border border-blue-200"
                      : "bg-slate-900 hover:bg-slate-800 text-white"
                  }`}
                >
                  {isSelected ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Sedang Digunakan</span>
                    </>
                  ) : (
                    <>
                      <span>Terapkan Model Ini</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  if (mode === "reference") {
    return (
      <div className="max-w-[1100px] mx-auto py-8 px-4 sm:px-6 flex flex-col gap-6">
        <div className="flex flex-wrap items-end justify-between gap-4 pb-4 border-b border-slate-200">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              Komponen Visual Otomatis
            </h1>
            <p className="text-sm text-slate-600 mt-1">
              Delapan modul grafis gerak yang dirangkai otomatis oleh mesin
              motion-graphic Izzy Studio berdasarkan naskah atau audio Anda.
            </p>
          </div>
          <button
            type="button"
            onClick={onBackToStudio}
            className="px-4 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold whitespace-nowrap shrink-0"
          >
            Buka Studio Pembuat Video
          </button>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              {
                title: "01. Meja & Monitor Pembuka",
                desc: "Ilustrasi 2.5D lengkap dengan papan nama topik dinamis, monitor grafik bergerak, dan bendera.",
              },
              {
                title: "02. Tabel Bukti Progresif",
                desc: "Tabel perbandingan di bagian atas layar yang otomatis bertambah barisnya seiring pergantian adegan.",
              },
              {
                title: "03. Penghitung Angka & Perangkat",
                desc: "Animasi angka bertumbuh (tabular numerals) lengkap dengan ilustrasi perangkat dan arus partikel.",
              },
              {
                title: "04. Grafik Jaringan Simpul",
                desc: "Visualisasi klaster jaringan interaktif dengan titik pusat berdenyut untuk menjelaskan skala besar.",
              },
              {
                title: "05. Server & Radar Keamanan",
                desc: "Rak server dengan LED aktif, terminal terhubung, dan sapuan radar 360 derajat.",
              },
              {
                title: "06. Kartu Berita & Peta Wilayah",
                desc: "Kartu siaran berita berpadu dengan siluet peta dan pin lokasi yang berdenyut.",
              },
              {
                title: "07. Timbangan & Kesimpulan",
                desc: "Timbangan keadilan animasi di atas meja untuk menutup video dengan pertanyaan reflektif.",
              },
              {
                title: "08. Subtitle Karaoke Tersinkron",
                desc: "Teks narasi di bagian bawah dengan sorotan kata aktif mengikuti durasi audio secara presisi.",
              },
            ].map((item) => (
              <div
                key={item.title}
                className="p-4 rounded-lg border border-slate-200 bg-slate-50/50"
              >
                <h3 className="text-xs font-bold text-slate-900">
                  {item.title}
                </h3>
                <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-[960px] mx-auto py-8 px-4 sm:px-6 flex flex-col gap-6">
      <div className="flex flex-wrap items-end justify-between gap-4 pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">
            Panduan Alur Kerja Otomatis
          </h1>
          <p className="text-sm text-slate-600 mt-1">
            Dua cara cepat menghasilkan video infografis bergerak beserta audio
            dan subtitle tersinkronisasi.
          </p>
        </div>
        <button
          type="button"
          onClick={onBackToStudio}
          className="px-4 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 text-white text-xs font-semibold whitespace-nowrap shrink-0"
        >
          Mulai di Studio
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-3">
          <h2 className="text-sm font-bold text-slate-900">
            Alur 1: Dari Teks ke Video + Suara
          </h2>
          <ol className="text-xs text-slate-600 space-y-2.5 leading-relaxed list-decimal list-inside">
            <li>
              Pilih tab <strong>Input Teks</strong> dan masukkan topik, berita,
              atau naskah lengkap Anda.
            </li>
            <li>
              Pilih salah satu dari <strong>5 Model Visual</strong>, rasio aspek
              (9:16, 16:9, atau 1:1), serta karakter suara narator.
            </li>
            <li>
              Platform memecah teks menjadi storyboard multi-adegan, mengisi
              tabel bukti, sekaligus mensintesis suara narator per adegan agar
              transisi visual 100% pas dengan ucapan.
            </li>
            <li>
              Sunting judul atau teks di panel kanan kapan saja, lalu klik{" "}
              <strong>Unduh Video (.mp4 / .webm)</strong>.
            </li>
          </ol>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col gap-3">
          <h2 className="text-sm font-bold text-slate-900">
            Alur 2: Dari Sound / Audio ke Video
          </h2>
          <ol className="text-xs text-slate-600 space-y-2.5 leading-relaxed list-decimal list-inside">
            <li>
              Pilih tab <strong>Input Audio</strong> lalu unggah file rekaman
              (MP3/WAV/M4A) atau klik <strong>Rekam Suara</strong> langsung dari
              mikrofon.
            </li>
            <li>
              Sistem membaca durasi asli audio dan mentranskripsikan ucapan
              secara otomatis.
            </li>
            <li>
              Adegan visual, grafik angka, tabel perbandingan, dan subtitle
              karaoke disusun tepat mengikuti durasi dan ritme audio Anda.
            </li>
            <li>
              Pilih model <strong>Sonic Pulse Visualizer</strong> jika ingin
              spektrum gelombang suara reaktif tampil di layar.
            </li>
          </ol>
        </div>
      </div>
    </div>
  );
};
