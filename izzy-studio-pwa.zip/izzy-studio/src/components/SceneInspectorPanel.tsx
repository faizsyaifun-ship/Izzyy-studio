import React from "react";
import { RefreshCw } from "lucide-react";
import {
  ANIMATION_INTENSITY_LABELS,
  ANIMATION_TYPE_LABELS,
  ARCHETYPE_LABELS,
  CAMERA_MOVEMENT_LABELS,
  ENVIRONMENTAL_EFFECT_LABELS,
  LANGUAGE_PREFERENCE_OPTIONS,
  MOTION_TIMING_LABELS,
  TRANSITION_LABELS,
  VISUAL_ASSET_LABELS,
} from "../data/presets";
import { buildNarrationSegments } from "../lib/languageSync";
import { resolveSceneVisualSpec } from "../lib/visualAssets";
import type {
  AnimationIntensity,
  EnvironmentalEffectType,
  LanguagePreference,
  MotionTimingCurve,
  SceneArchetype,
  SceneTransition,
  SceneVisualSpec,
  SupportedLanguage,
  VideoBlueprint,
  VideoScene,
  VisualAnimationType,
  VisualAssetKey,
  VisualCameraMovement,
} from "../types/video";

interface SceneInspectorPanelProps {
  blueprint: VideoBlueprint;
  currentTime: number;
  isBusy?: boolean;
  isRegeneratingVoice: boolean;
  voiceProgressPercent?: number;
  onSeekToScene: (startTime: number) => void;
  onUpdateScene: (sceneId: string, patch: Partial<VideoScene>) => void;
  onUpdateSubjectNameplate: (nameplate: string) => void;
  onChangeAudioMode?: (mode: "ai-narration" | "no-audio") => void;
  onChangeLanguagePreference?: (pref: LanguagePreference) => void;
  onRegenerateVoice: () => void;
}

const ARCHETYPE_OPTIONS: SceneArchetype[] = [
  "desk_intro",
  "metric_counter",
  "network_graph",
  "document_audit",
  "server_radar",
  "news_map_card",
  "balance_verdict",
  "kinetic_statement",
];

const TRANSITION_OPTIONS: SceneTransition[] = [
  "fade",
  "slide",
  "zoom",
  "whip",
  "morph",
  "depth",
  "none",
];

function formatLanguageLabel(
  lang?: SupportedLanguage,
  pref?: LanguagePreference
): string {
  const base =
    lang === "mixed"
      ? "ID + EN (Campuran)"
      : lang === "en-US"
      ? "English (EN)"
      : "Indonesia (ID)";
  if (!pref || pref === "auto") return `Auto · ${base}`;
  return base;
}

export const SceneInspectorPanel: React.FC<SceneInspectorPanelProps> = ({
  blueprint,
  currentTime,
  isBusy = false,
  isRegeneratingVoice,
  voiceProgressPercent,
  onSeekToScene,
  onUpdateScene,
  onUpdateSubjectNameplate,
  onChangeAudioMode,
  onChangeLanguagePreference,
  onRegenerateVoice,
}) => {
  const activeIndex = Math.max(
    0,
    blueprint.scenes.findIndex(
      (s) => currentTime >= s.startTime && currentTime < s.endTime
    )
  );
  const activeScene = blueprint.scenes[activeIndex] || blueprint.scenes[0];
  const activeVisualSpec = activeScene
    ? resolveSceneVisualSpec(activeScene, blueprint.title)
    : null;
  const activeSegments =
    activeScene && activeVisualSpec
      ? activeScene.narrationSegments && activeScene.narrationSegments.length > 0
        ? activeScene.narrationSegments
        : buildNarrationSegments(
            activeScene.narration,
            activeScene.durationSeconds,
            activeVisualSpec,
            blueprint.languagePreference || "auto"
          )
      : [];
  const projectAudioMode =
    blueprint.audioMode ||
    (blueprint.sourceMode === "audio" ? "uploaded-audio" : "ai-narration");
  const projectLangPref: LanguagePreference = blueprint.languagePreference || "auto";

  const updateActiveVisualSpec = (patch: Partial<SceneVisualSpec>) => {
    if (!activeScene || !activeVisualSpec) return;
    onUpdateScene(activeScene.id, {
      sceneVisualSpec: {
        ...activeVisualSpec,
        ...patch,
      },
    });
  };

  return (
    <aside className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col gap-5 h-fit">
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <div>
          <h2 className="text-sm font-bold text-slate-900">
            Storyboard & Editor Adegan
          </h2>
          <p className="text-xs text-slate-500 mt-0.5 tabular-nums">
            {blueprint.scenes.length} adegan · {blueprint.totalDuration.toFixed(1)} detik
          </p>
        </div>

        {blueprint.sourceMode === "text" && projectAudioMode !== "no-audio" && (
          <button
            type="button"
            disabled={isBusy || isRegeneratingVoice}
            onClick={onRegenerateVoice}
            title="Perbarui audio narator sesuai naskah terbaru"
            className="inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-md border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-semibold text-slate-700 transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${isRegeneratingVoice ? "animate-spin" : ""}`}
            />
            <span className="tabular-nums">
              {isRegeneratingVoice
                ? `Loading (${voiceProgressPercent ?? 0}%)`
                : "Sinkron Suara"}
            </span>
          </button>
        )}
      </div>

      {blueprint.sourceMode === "text" && onChangeAudioMode && (
        <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-2.5 flex flex-col gap-1.5">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] font-semibold text-slate-700">
              Audio Video
            </span>
            <span className="text-[10px] text-slate-500">
              Ubah tanpa buat ulang storyboard
            </span>
          </div>
          <div className="grid grid-cols-2 gap-1 p-0.5 bg-slate-200/70 rounded-md">
            <button
              type="button"
              disabled={isBusy}
              onClick={() => onChangeAudioMode("ai-narration")}
              className={`py-1 px-2 text-[11px] font-semibold rounded transition-colors disabled:opacity-50 ${
                projectAudioMode === "ai-narration"
                  ? "bg-white text-slate-900 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              Dengan Narasi AI
            </button>
            <button
              type="button"
              disabled={isBusy}
              onClick={() => onChangeAudioMode("no-audio")}
              className={`py-1 px-2 text-[11px] font-semibold rounded transition-colors disabled:opacity-50 ${
                projectAudioMode === "no-audio"
                  ? "bg-white text-slate-900 shadow-xs"
                  : "text-slate-600 hover:text-slate-900"
              }`}
            >
              Tanpa Audio
            </button>
          </div>
          <p className="text-[10px] text-slate-500">
            Tanpa Audio menghemat kuota Gemini TTS.
          </p>
        </div>
      )}

      {/* Project Detected Language & Override */}
      <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-2.5 flex flex-col gap-1.5">
        <div className="flex items-center justify-between gap-2">
          <span className="text-[11px] font-semibold text-slate-700">
            Bahasa Terdeteksi
          </span>
          <span className="text-[10px] font-mono font-semibold text-blue-700 bg-blue-50 border border-blue-200 rounded px-1.5 py-0.5">
            {formatLanguageLabel(blueprint.detectedLanguage, projectLangPref)}
          </span>
        </div>
        {onChangeLanguagePreference && (
          <div className="grid grid-cols-3 gap-1 p-0.5 bg-slate-200/70 rounded-md">
            {LANGUAGE_PREFERENCE_OPTIONS.map((opt) => (
              <button
                key={opt.id}
                type="button"
                disabled={isBusy}
                onClick={() => onChangeLanguagePreference(opt.id)}
                className={`py-1 px-1.5 text-[10px] font-semibold rounded transition-colors disabled:opacity-50 ${
                  projectLangPref === opt.id
                    ? "bg-white text-slate-900 shadow-xs"
                    : "text-slate-600 hover:text-slate-900"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Global Subject Nameplate */}
      <div>
        <label
          htmlFor="nameplate-input"
          className="block text-xs font-semibold text-slate-700 mb-1"
        >
          Label Papan Nama / Topik Meja
        </label>
        <input
          id="nameplate-input"
          type="text"
          value={blueprint.subjectNameplate}
          onChange={(e) => onUpdateSubjectNameplate(e.target.value.toUpperCase())}
          className="w-full rounded-lg border border-slate-200 bg-slate-50/70 px-3 py-1.5 text-xs font-mono font-semibold text-slate-900 focus:border-blue-700 focus:bg-white focus:outline-none"
        />
      </div>

      {/* Scene Timeline List */}
      <div className="flex flex-col gap-2 max-h-[290px] overflow-y-auto pr-1">
        {blueprint.scenes.map((scene, idx) => {
          const isActive = scene.id === activeScene?.id;
          return (
            <div
              key={scene.id}
              className={`w-full rounded-lg border transition-colors ${
                isActive
                  ? "border-blue-700 bg-blue-50/50"
                  : "border-slate-200 bg-white hover:bg-slate-50"
              }`}
            >
              <button
                type="button"
                onClick={() => onSeekToScene(scene.startTime + 0.05)}
                className="w-full text-left px-3 pt-2.5 pb-1.5"
              >
                <div className="flex items-center justify-between gap-2 text-xs">
                  <span className="font-bold text-slate-900 truncate">
                    {String(idx + 1).padStart(2, "0")}. {scene.topTitle}
                  </span>
                  <span className="font-mono text-slate-500 tabular-nums shrink-0">
                    {scene.startTime.toFixed(1)}s
                  </span>
                </div>
                <div className="text-xs text-slate-500 mt-1 truncate">
                  {VISUAL_ASSET_LABELS[
                    resolveSceneVisualSpec(scene, blueprint.title).assetKey
                  ] || ARCHETYPE_LABELS[scene.archetype]}{" "}
                  · {scene.durationSeconds.toFixed(1)}d
                </div>
              </button>

              <div className="px-3 pb-2.5 pt-1 border-t border-slate-100/80 flex items-center justify-between gap-2">
                <label
                  htmlFor={`transition-${scene.id}`}
                  className="text-[11px] font-semibold text-slate-500 whitespace-nowrap"
                >
                  Efek Transisi
                </label>
                <select
                  id={`transition-${scene.id}`}
                  value={scene.transition || "fade"}
                  onChange={(e) =>
                    onUpdateScene(scene.id, {
                      transition: e.target.value as SceneTransition,
                    })
                  }
                  className="rounded-md border border-slate-200 bg-white px-2 py-1 text-[11px] font-medium text-slate-800 focus:border-blue-700 focus:outline-none"
                >
                  {TRANSITION_OPTIONS.map((tr) => (
                    <option key={tr} value={tr}>
                      {TRANSITION_LABELS[tr]}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Scene Live Inspector */}
      {activeScene && (
        <div className="pt-4 border-t border-slate-200 flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-900">
              Edit Adegan {String(activeIndex + 1).padStart(2, "0")}
            </span>
            <span className="text-xs font-mono text-slate-500 tabular-nums">
              {activeScene.startTime.toFixed(1)}s – {activeScene.endTime.toFixed(1)}s
            </span>
          </div>

          {activeVisualSpec && (
            <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-3 flex flex-col gap-2.5">
              <span className="text-xs font-bold text-slate-800">
                Visual & Animasi Adegan
              </span>

              <div>
                <label
                  htmlFor="visual-asset-select"
                  className="block text-[11px] font-semibold text-slate-600 mb-1"
                >
                  Aset Visual Semantik
                </label>
                <select
                  id="visual-asset-select"
                  value={activeVisualSpec.assetKey}
                  onChange={(e) =>
                    updateActiveVisualSpec({
                      assetKey: e.target.value as VisualAssetKey,
                    })
                  }
                  className="w-full rounded-md border border-slate-200 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
                >
                  {(Object.keys(VISUAL_ASSET_LABELS) as VisualAssetKey[]).map(
                    (key) => (
                      <option key={key} value={key}>
                        {VISUAL_ASSET_LABELS[key]}
                      </option>
                    )
                  )}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label
                    htmlFor="visual-subject-input"
                    className="block text-[11px] font-semibold text-slate-600 mb-1"
                  >
                    Subjek Visual
                  </label>
                  <input
                    id="visual-subject-input"
                    type="text"
                    value={activeVisualSpec.subject}
                    onChange={(e) =>
                      updateActiveVisualSpec({ subject: e.target.value })
                    }
                    className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                  />
                </div>

                <div>
                  <label
                    htmlFor="visual-focus-input"
                    className="block text-[11px] font-semibold text-slate-600 mb-1"
                  >
                    Area Fokus
                  </label>
                  <input
                    id="visual-focus-input"
                    type="text"
                    value={activeVisualSpec.focusRegion || ""}
                    onChange={(e) =>
                      updateActiveVisualSpec({ focusRegion: e.target.value })
                    }
                    placeholder="Bagian disorot"
                    className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label
                    htmlFor="visual-camera-select"
                    className="block text-[11px] font-semibold text-slate-600 mb-1"
                  >
                    Gerakan Kamera
                  </label>
                  <select
                    id="visual-camera-select"
                    value={activeVisualSpec.cameraMovement}
                    onChange={(e) =>
                      updateActiveVisualSpec({
                        cameraMovement: e.target.value as VisualCameraMovement,
                      })
                    }
                    className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                  >
                    {(
                      Object.keys(
                        CAMERA_MOVEMENT_LABELS
                      ) as VisualCameraMovement[]
                    ).map((cam) => (
                      <option key={cam} value={cam}>
                        {CAMERA_MOVEMENT_LABELS[cam]}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="visual-anim-select"
                    className="block text-[11px] font-semibold text-slate-600 mb-1"
                  >
                    Jenis Animasi
                  </label>
                  <select
                    id="visual-anim-select"
                    value={activeVisualSpec.animationType}
                    onChange={(e) =>
                      updateActiveVisualSpec({
                        animationType: e.target.value as VisualAnimationType,
                      })
                    }
                    className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                  >
                    {(
                      Object.keys(ANIMATION_TYPE_LABELS) as VisualAnimationType[]
                    ).map((anim) => (
                      <option key={anim} value={anim}>
                        {ANIMATION_TYPE_LABELS[anim]}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label
                  htmlFor="visual-action-input"
                  className="block text-[11px] font-semibold text-slate-600 mb-1"
                >
                  Aksi / Proses Visual
                </label>
                <input
                  id="visual-action-input"
                  type="text"
                  value={activeVisualSpec.action}
                  onChange={(e) =>
                    updateActiveVisualSpec({ action: e.target.value })
                  }
                  className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="visual-objects-input"
                  className="block text-[11px] font-semibold text-slate-600 mb-1"
                >
                  Objek Pendukung (pisah koma)
                </label>
                <input
                  id="visual-objects-input"
                  type="text"
                  value={activeVisualSpec.objects.join(", ")}
                  onChange={(e) =>
                    updateActiveVisualSpec({
                      objects: e.target.value
                        .split(",")
                        .map((s) => s.trim())
                        .filter(Boolean),
                    })
                  }
                  className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                />
              </div>

              <div>
                <label
                  htmlFor="visual-env-select"
                  className="block text-[11px] font-semibold text-slate-600 mb-1"
                >
                  Efek Lingkungan & Partikel
                </label>
                <select
                  id="visual-env-select"
                  value={activeVisualSpec.environmentalEffect || "ambient_dust"}
                  onChange={(e) =>
                    updateActiveVisualSpec({
                      environmentalEffect: e.target
                        .value as EnvironmentalEffectType,
                    })
                  }
                  className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                >
                  {(
                    Object.keys(
                      ENVIRONMENTAL_EFFECT_LABELS
                    ) as EnvironmentalEffectType[]
                  ).map((env) => (
                    <option key={env} value={env}>
                      {ENVIRONMENTAL_EFFECT_LABELS[env]}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label
                    htmlFor="visual-intensity-select"
                    className="block text-[11px] font-semibold text-slate-600 mb-1"
                  >
                    Intensitas Gerak
                  </label>
                  <select
                    id="visual-intensity-select"
                    value={activeVisualSpec.animationIntensity || "cinematic"}
                    onChange={(e) =>
                      updateActiveVisualSpec({
                        animationIntensity: e.target
                          .value as AnimationIntensity,
                      })
                    }
                    className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                  >
                    {(
                      Object.keys(
                        ANIMATION_INTENSITY_LABELS
                      ) as AnimationIntensity[]
                    ).map((lvl) => (
                      <option key={lvl} value={lvl}>
                        {ANIMATION_INTENSITY_LABELS[lvl]}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="visual-timing-select"
                    className="block text-[11px] font-semibold text-slate-600 mb-1"
                  >
                    Kurva Fisika
                  </label>
                  <select
                    id="visual-timing-select"
                    value={activeVisualSpec.motionTiming || "spring"}
                    onChange={(e) =>
                      updateActiveVisualSpec({
                        motionTiming: e.target.value as MotionTimingCurve,
                      })
                    }
                    className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                  >
                    {(
                      Object.keys(MOTION_TIMING_LABELS) as MotionTimingCurve[]
                    ).map((curve) => (
                      <option key={curve} value={curve}>
                        {MOTION_TIMING_LABELS[curve]}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-2">
                <div>
                  <label
                    htmlFor="visual-obj-move-input"
                    className="block text-[11px] font-semibold text-slate-600 mb-1"
                  >
                    Gerak Objek Utama
                  </label>
                  <input
                    id="visual-obj-move-input"
                    type="text"
                    value={activeVisualSpec.objectMovement || ""}
                    onChange={(e) =>
                      updateActiveVisualSpec({ objectMovement: e.target.value })
                    }
                    placeholder="Contoh: Accelerating 3D pulse"
                    className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                  />
                </div>
                <div>
                  <label
                    htmlFor="visual-sec-anim-input"
                    className="block text-[11px] font-semibold text-slate-600 mb-1"
                  >
                    Lapisan Animasi Sekunder
                  </label>
                  <input
                    id="visual-sec-anim-input"
                    type="text"
                    value={activeVisualSpec.secondaryAnimation || ""}
                    onChange={(e) =>
                      updateActiveVisualSpec({
                        secondaryAnimation: e.target.value,
                      })
                    }
                    placeholder="Contoh: Blood flow + glowing ECG halo"
                    className="w-full rounded-md border border-slate-200 bg-white px-2 py-1.5 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          <div>
            <label
              htmlFor="archetype-select"
              className="block text-xs font-semibold text-slate-600 mb-1"
            >
              Tata Letak Kartu & Tabel
            </label>
            <select
              id="archetype-select"
              value={activeScene.archetype}
              onChange={(e) =>
                onUpdateScene(activeScene.id, {
                  archetype: e.target.value as SceneArchetype,
                })
              }
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs font-medium text-slate-900 focus:border-blue-700 focus:outline-none"
            >
              {ARCHETYPE_OPTIONS.map((arch) => (
                <option key={arch} value={arch}>
                  {ARCHETYPE_LABELS[arch]}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label
                htmlFor="top-title-input"
                className="block text-xs font-semibold text-slate-600 mb-1"
              >
                Headline Atas
              </label>
              <input
                id="top-title-input"
                type="text"
                value={activeScene.topTitle}
                onChange={(e) =>
                  onUpdateScene(activeScene.id, { topTitle: e.target.value })
                }
                className="w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
              />
            </div>

            <div>
              <label
                htmlFor="hl-word-input"
                className="block text-xs font-semibold text-slate-600 mb-1"
              >
                Kata Disorot
              </label>
              <input
                id="hl-word-input"
                type="text"
                value={activeScene.topHighlightWord}
                onChange={(e) =>
                  onUpdateScene(activeScene.id, {
                    topHighlightWord: e.target.value,
                  })
                }
                className="w-full rounded-lg border border-slate-200 bg-white px-2.5 py-1.5 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label
                htmlFor="narration-input"
                className="block text-xs font-semibold text-slate-600"
              >
                Narasi & Subtitle Tersinkron
              </label>
              {activeScene.language && (
                <span className="text-[10px] font-mono text-slate-500 uppercase">
                  {activeScene.language}
                </span>
              )}
            </div>
            <textarea
              id="narration-input"
              rows={3}
              value={activeScene.narration}
              onChange={(e) =>
                onUpdateScene(activeScene.id, { narration: e.target.value })
              }
              className="w-full rounded-lg border border-slate-200 bg-white px-2.5 py-2 text-xs text-slate-900 leading-relaxed focus:border-blue-700 focus:outline-none"
            />
          </div>

          {activeSegments.length > 0 && (
            <div className="rounded-lg border border-slate-200 bg-slate-50/70 p-2.5 flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-700">
                  Sinkronisasi Kalimat & Kamera
                </span>
                <span className="text-[10px] text-slate-500 tabular-nums">
                  {activeSegments.length} segmen
                </span>
              </div>
              <div className="flex flex-col gap-1.5 max-h-[140px] overflow-y-auto">
                {activeSegments.map((seg, sIdx) => (
                  <div
                    key={`${activeScene.id}-seg-${sIdx}`}
                    className="rounded border border-slate-200 bg-white px-2 py-1.5 text-[11px]"
                  >
                    <div className="flex items-center justify-between gap-2 text-[10px] font-mono text-slate-500">
                      <span>
                        {seg.startTime.toFixed(1)}s–{seg.endTime.toFixed(1)}s ·{" "}
                        {seg.language === "en-US" ? "EN" : "ID"}
                      </span>
                      <span className="text-blue-700 font-semibold">
                        {seg.animationTrigger} · {seg.cameraEvent}
                      </span>
                    </div>
                    <p className="text-slate-700 mt-0.5 line-clamp-2">
                      {seg.visualEvent}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeScene.tableRow && (
            <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
              <span className="text-xs font-semibold text-slate-600">
                Baris Tabel Bukti
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                <input
                  type="text"
                  value={activeScene.tableRow.taskLabel}
                  onChange={(e) =>
                    onUpdateScene(activeScene.id, {
                      tableRow: {
                        ...activeScene.tableRow!,
                        taskLabel: e.target.value,
                      },
                    })
                  }
                  placeholder="Topik"
                  className="rounded-md border border-slate-200 px-2 py-1 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                />
                <input
                  type="text"
                  value={activeScene.tableRow.aiAction}
                  onChange={(e) =>
                    onUpdateScene(activeScene.id, {
                      tableRow: {
                        ...activeScene.tableRow!,
                        aiAction: e.target.value,
                      },
                    })
                  }
                  placeholder="Aksi"
                  className="rounded-md border border-slate-200 px-2 py-1 text-xs text-slate-900 focus:border-blue-700 focus:outline-none"
                />
                <input
                  type="text"
                  value={activeScene.tableRow.evidenceText}
                  onChange={(e) =>
                    onUpdateScene(activeScene.id, {
                      tableRow: {
                        ...activeScene.tableRow!,
                        evidenceText: e.target.value,
                      },
                    })
                  }
                  placeholder="Bukti"
                  className="rounded-md border border-slate-200 px-2 py-1 text-xs font-mono text-slate-900 focus:border-blue-700 focus:outline-none"
                />
              </div>
            </div>
          )}
        </div>
      )}
    </aside>
  );
};
