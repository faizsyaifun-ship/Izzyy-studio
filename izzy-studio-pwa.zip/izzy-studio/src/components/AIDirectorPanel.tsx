import React, { useState } from "react";
import { Bot, Sparkles, WandSparkles, LoaderCircle, RotateCcw } from "lucide-react";

interface AIDirectorPanelProps {
  isBusy: boolean;
  onRevise: (instruction: string) => Promise<void>;
  canUndo: boolean;
  revisionCount: number;
  onUndo: () => void;
}

export const AIDirectorPanel: React.FC<AIDirectorPanelProps> = ({ isBusy, onRevise, canUndo, revisionCount, onUndo }) => {
  const [instruction, setInstruction] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [lastInstruction, setLastInstruction] = useState("");

  const submit = async () => {
    const value = instruction.trim();
    if (!value || isBusy) return;
    setError(null);
    try {
      await onRevise(value);
      setLastInstruction(value);
      setInstruction("");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Revisi AI gagal dijalankan.");
    }
  };

  return (
    <section className="rounded-2xl border border-violet-200 bg-gradient-to-br from-white to-violet-50/70 p-4 shadow-sm">
      <div className="flex items-start gap-3">
        <div className="rounded-xl bg-violet-700 p-2.5 text-white"><Bot size={20} /></div>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h2 className="font-display text-sm font-extrabold text-slate-900">Sutradara AI</h2>
            <span className="rounded-full bg-violet-100 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-violet-700">Revisi langsung</span>
          </div>
          <p className="mt-1 text-xs leading-relaxed text-slate-600">Berikan instruksi perubahan. AI akan membaca storyboard saat ini, merevisi adegan yang relevan, lalu memperbarui preview tanpa membuat proyek dari awal.</p>
        </div>
      </div>

      {lastInstruction && (
        <div className="mt-3 rounded-lg border border-violet-100 bg-white/80 px-3 py-2 text-[11px] text-slate-600">
          <span className="font-bold text-violet-700">Revisi terakhir:</span> {lastInstruction}
        </div>
      )}

      <label htmlFor="ai-director-instruction" className="mt-4 block text-xs font-bold text-slate-700">Apa yang ingin direvisi?</label>
      <textarea
        id="ai-director-instruction"
        value={instruction}
        onChange={(event) => setInstruction(event.target.value)}
        onKeyDown={(event) => { if ((event.metaKey || event.ctrlKey) && event.key === "Enter") void submit(); }}
        disabled={isBusy}
        rows={3}
        placeholder="Contoh: Buat animasi kamera lebih dinamis, ubah latar menjadi laboratorium futuristik, sederhanakan teks adegan 2, dan tambahkan efek partikel..."
        className="mt-2 w-full resize-y rounded-xl border border-slate-200 bg-white px-3 py-3 text-sm text-slate-800 outline-none transition placeholder:text-slate-400 focus:border-violet-400 focus:ring-2 focus:ring-violet-100 disabled:opacity-60"
      />
      {error && <p className="mt-2 text-xs text-red-600">{error}</p>}
      <div className="mt-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-3">
          <span className="text-[10px] text-slate-500">Ctrl/⌘ + Enter untuk menjalankan revisi</span>
          <span className="text-[10px] font-semibold text-violet-700">{revisionCount} revisi tersimpan</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onUndo}
            disabled={isBusy || !canUndo}
            className="inline-flex items-center gap-1.5 rounded-xl border border-violet-200 bg-white px-3 py-2.5 text-xs font-bold text-violet-800 transition hover:bg-violet-50 disabled:cursor-not-allowed disabled:opacity-40"
          >
            <RotateCcw size={13} /> Urungkan
          </button>
          <button
          type="button"
          onClick={() => void submit()}
          disabled={isBusy || !instruction.trim()}
          className="inline-flex items-center gap-2 rounded-xl bg-violet-700 px-4 py-2.5 text-xs font-bold text-white shadow-sm transition hover:bg-violet-800 disabled:cursor-not-allowed disabled:bg-violet-300"
        >
          {isBusy ? <><LoaderCircle size={14} className="animate-spin" /> Merevisi...</> : <><WandSparkles size={14} /> Revisi dengan AI <Sparkles size={13} /></>}
          </button>
        </div>
      </div>
      <div className="mt-3 flex items-start gap-2 rounded-lg bg-violet-100/70 px-3 py-2 text-[10px] leading-relaxed text-violet-900">
        <RotateCcw size={13} className="mt-0.5 shrink-0" /> Revisi mempertahankan rasio, gaya visual, dan audio proyek. Periksa hasil di preview sebelum ekspor.
      </div>
    </section>
  );
};
