import React, { useEffect, useMemo, useRef, useState } from "react";
import { renderVideoFrame } from "../lib/videoEngine";
import type { VideoBlueprint, VideoStyleId } from "../types/video";

interface StyleLoopPreviewProps {
  styleId: VideoStyleId;
  className?: string;
  resolution?: "thumb" | "card";
  showLoopBar?: boolean;
}

const LOOP_SECONDS = 3.0;

function buildPreviewBlueprint(styleId: VideoStyleId): VideoBlueprint {
  switch (styleId) {
    case "tech-blueprint":
      return {
        id: `preview-${styleId}`,
        title: "Tech Blueprint",
        subjectNameplate: "ARUS DATA",
        brandHandle: "",
        tableColumns: ["Modul", "Status", "Beban"],
        style: "tech-blueprint",
        aspectRatio: "16:9",
        totalDuration: LOOP_SECONDS,
        sourceMode: "text",
        scenes: [
          {
            id: "p1",
            archetype: "network_graph",
            transition: "fade",
            topTitle: "Pemetaan node otomatis",
            topHighlightWord: "otomatis",
            topSubLabel: "ARSITEKTUR JARINGAN",
            narration: "Deteksi pola sistem secara real-time.",
            durationSeconds: 1.5,
            startTime: 0,
            endTime: 1.5,
            visualMetric: {
              prefix: "",
              targetValue: 200,
              decimals: 0,
              suffix: " Jt",
              unitLabel: "koneksi aktif",
              sourceLabel: "200 Jt simpul terhubung",
            },
          },
          {
            id: "p2",
            archetype: "server_radar",
            transition: "zoom",
            topTitle: "Radar keamanan 24 jam",
            topHighlightWord: "24 jam",
            topSubLabel: "PEMANTAUAN SERVER",
            narration: "Sistem siaga mendeteksi anomali.",
            durationSeconds: 1.5,
            startTime: 1.5,
            endTime: 3.0,
            calloutBadge: "SISTEM AMAN",
          },
        ],
      };

    case "kinetic-cards":
      return {
        id: `preview-${styleId}`,
        title: "Kinetic Cards",
        subjectNameplate: "STATISTIK",
        brandHandle: "",
        tableColumns: ["Metrik", "Aksi", "Hasil"],
        style: "kinetic-cards",
        aspectRatio: "16:9",
        totalDuration: LOOP_SECONDS,
        sourceMode: "text",
        scenes: [
          {
            id: "p1",
            archetype: "kinetic_statement",
            transition: "slide",
            topTitle: "Lonjakan adopsi digital",
            topHighlightWord: "digital",
            topSubLabel: "RINGKASAN DATA",
            narration: "Pertumbuhan cepat dalam tiga tahun.",
            durationSeconds: 1.5,
            startTime: 0,
            endTime: 1.5,
            visualMetric: {
              prefix: "+",
              targetValue: 142,
              decimals: 0,
              suffix: "%",
              unitLabel: "pertumbuhan tahunan",
              sourceLabel: "Laporan Industri",
            },
            bullets: ["Otomasi alur visual", "Subtitle tersinkronisasi"],
          },
          {
            id: "p2",
            archetype: "metric_counter",
            transition: "slide",
            topTitle: "Nilai transaksi tercatat",
            topHighlightWord: "tercatat",
            topSubLabel: "REKAPITULASI",
            narration: "Angka bergerak mengikuti narasi.",
            durationSeconds: 1.5,
            startTime: 1.5,
            endTime: 3.0,
            visualMetric: {
              prefix: "Rp ",
              targetValue: 48.5,
              decimals: 1,
              suffix: " T",
              unitLabel: "volume tahunan",
              sourceLabel: "Data Terverifikasi",
            },
          },
        ],
      };

    case "newsroom-brief":
      return {
        id: `preview-${styleId}`,
        title: "Newsroom Brief",
        subjectNameplate: "REDAKSI",
        brandHandle: "",
        tableColumns: ["Wilayah", "Status", "Fakta"],
        style: "newsroom-brief",
        aspectRatio: "16:9",
        totalDuration: LOOP_SECONDS,
        sourceMode: "text",
        scenes: [
          {
            id: "p1",
            archetype: "news_map_card",
            transition: "fade",
            topTitle: "Laporan utama hari ini",
            topHighlightWord: "hari ini",
            topSubLabel: "SIARAN BERITA",
            narration: "Sorotan lokasi dan berita terkini.",
            durationSeconds: 1.6,
            startTime: 0,
            endTime: 1.6,
            newsCard: {
              tag: "BERITA · UTAMA",
              headline: "Kebijakan Baru",
              regionName: "Asia Tenggara",
              subDetail: "Pembaruan regulasi publik",
            },
          },
          {
            id: "p2",
            archetype: "document_audit",
            transition: "slide",
            topTitle: "Verifikasi dokumen resmi",
            topHighlightWord: "resmi",
            topSubLabel: "ARSIP REDAKSI",
            narration: "Dokumen diperiksa berlapis.",
            durationSeconds: 1.4,
            startTime: 1.6,
            endTime: 3.0,
            tableRow: {
              taskLabel: "Audit",
              aiAction: "cek berkas",
              evidenceText: "Terverifikasi",
              status: "verified",
            },
          },
        ],
      };

    case "creator-showcase":
      return {
        id: `preview-${styleId}`,
        title: "Creator Portfolio Motion",
        subjectNameplate: "CREATOR",
        brandHandle: "@CREATOR.STUDIO",
        tableColumns: ["Work", "Style", "Contact"],
        style: "creator-showcase",
        aspectRatio: "16:9",
        totalDuration: LOOP_SECONDS,
        sourceMode: "text",
        scenes: [
          {
            id: "p1", archetype: "kinetic_statement", transition: "fade",
            topTitle: "Still looking for a creative?",
            topHighlightWord: "creative?", topSubLabel: "CREATOR PORTFOLIO",
            narration: "A clean creator portfolio motion design.",
            durationSeconds: 1.5, startTime: 0, endTime: 1.5,
          },
          {
            id: "p2", archetype: "kinetic_statement", transition: "zoom",
            topTitle: "Let's work together",
            topHighlightWord: "together", topSubLabel: "AVAILABLE FOR PROJECTS",
            narration: "Showcase your profile and projects.",
            durationSeconds: 0.75, startTime: 1.5, endTime: 2.25,
          },
          {
            id: "p3", archetype: "kinetic_statement", transition: "fade",
            topTitle: "Creator Studio", topHighlightWord: "Studio", topSubLabel: "OUTRO",
            narration: "Creator Studio end card.", durationSeconds: 0.75, startTime: 2.25, endTime: 3.0,
          },
        ],
      };

    case "audio-pulse":
      return {
        id: `preview-${styleId}`,
        title: "Sonic Pulse",
        subjectNameplate: "AUDIO",
        brandHandle: "",
        tableColumns: ["Kanal", "Ritme", "Level"],
        style: "audio-pulse",
        aspectRatio: "16:9",
        totalDuration: LOOP_SECONDS,
        sourceMode: "audio",
        scenes: [
          {
            id: "p1",
            archetype: "kinetic_statement",
            transition: "fade",
            topTitle: "Visual mengikuti gelombang suara",
            topHighlightWord: "suara",
            topSubLabel: "SPEKTRUM AUDIO REAKTIF",
            narration: "Gelombang suara langsung menggerakkan grafis.",
            durationSeconds: LOOP_SECONDS,
            startTime: 0,
            endTime: LOOP_SECONDS,
          },
        ],
      };

    case "editorial-desk":
    default:
      return {
        id: `preview-${styleId}`,
        title: "Editorial Desk",
        subjectNameplate: "TOPIK UTAMA",
        brandHandle: "",
        tableColumns: ["Bidang", "Tugas AI", "Bukti"],
        style: "editorial-desk",
        aspectRatio: "16:9",
        totalDuration: LOOP_SECONDS,
        sourceMode: "text",
        scenes: [
          {
            id: "p1",
            archetype: "desk_intro",
            transition: "fade",
            topTitle: "Simulasi topik utama?",
            topHighlightWord: "utama?",
            topSubLabel: "GAYA EDITORIAL DESK",
            narration: "Ilustrasi meja 2.5D dan grafik bergerak.",
            durationSeconds: 1.5,
            startTime: 0,
            endTime: 1.5,
          },
          {
            id: "p2",
            archetype: "metric_counter",
            transition: "slide",
            topTitle: "Data & tabel terisi",
            topHighlightWord: "terisi",
            topSubLabel: "RINGKASAN BUKTI",
            narration: "Angka dan tabel tersinkron otomatis.",
            durationSeconds: 1.5,
            startTime: 1.5,
            endTime: 3.0,
            visualMetric: {
              prefix: "Rp ",
              targetValue: 359.8,
              decimals: 1,
              suffix: " T",
              unitLabel: "nilai terukur",
              sourceLabel: "Data Terverifikasi",
            },
            tableRow: {
              taskLabel: "Fokus 1",
              aiAction: "lacak pola",
              evidenceText: "Rp359,8 T",
              status: "verified",
            },
          },
        ],
      };
  }
}

export const StyleLoopPreview: React.FC<StyleLoopPreviewProps> = ({
  styleId,
  className = "",
  resolution = "thumb",
  showLoopBar = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [loopSec, setLoopSec] = useState<number>(0);
  const [isVisible, setIsVisible] = useState<boolean>(true);

  const previewBlueprint = useMemo(
    () => buildPreviewBlueprint(styleId),
    [styleId]
  );

  const canvasW = resolution === "card" ? 640 : 384;
  const canvasH = resolution === "card" ? 360 : 216;

  useEffect(() => {
    const el = canvasRef.current;
    if (!el || typeof IntersectionObserver === "undefined") return;
    const observer = new IntersectionObserver(
      (entries) => {
        setIsVisible(entries[0]?.isIntersecting ?? true);
      },
      { threshold: 0.05 }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const prefersReduced =
      typeof window !== "undefined" &&
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches;

    const drawAt = (t: number) => {
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvasW, canvasH);
      ctx.scale(canvasW / 1920, canvasH / 1080);

      let bins: Uint8Array | undefined;
      if (styleId === "audio-pulse") {
        bins = new Uint8Array(32);
        for (let i = 0; i < 32; i++) {
          bins[i] = Math.round(
            90 +
              Math.sin(t * 7.5 + i * 0.5) * 70 +
              Math.cos(t * 4.2 - i * 0.3) * 55
          );
        }
      }

      renderVideoFrame(ctx, previewBlueprint, t, bins);
      ctx.restore();
    };

    if (prefersReduced || !isVisible) {
      drawAt(1.8);
      return;
    }

    let rafId = 0;
    const startMs = performance.now();
    let lastDrawMs = 0;

    const frame = (now: number) => {
      if (now - lastDrawMs >= 33) {
        lastDrawMs = now;
        const t = ((now - startMs) / 1000) % LOOP_SECONDS;
        drawAt(t);
        if (showLoopBar) {
          setLoopSec(t);
        }
      }
      rafId = requestAnimationFrame(frame);
    };

    rafId = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(rafId);
  }, [previewBlueprint, styleId, canvasW, canvasH, isVisible, showLoopBar]);

  return (
    <div
      className={`relative overflow-hidden bg-slate-900 ${className}`}
    >
      <canvas
        ref={canvasRef}
        width={canvasW}
        height={canvasH}
        className="w-full h-full block"
      />
      {showLoopBar && (
        <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 via-black/30 to-transparent pt-5 pb-1.5 px-2.5 flex items-center gap-2">
          <div className="flex-1 h-1 bg-white/25 rounded-full overflow-hidden">
            <div
              className="h-full bg-white transition-none"
              style={{ width: `${(loopSec / LOOP_SECONDS) * 100}%` }}
            />
          </div>
          <span className="text-[10px] font-mono font-semibold text-white tabular-nums">
            {loopSec.toFixed(1)}s / 3.0s
          </span>
        </div>
      )}
    </div>
  );
};
