import { useCallback, useEffect, useRef, useState } from "react";
import { InputDirectorPanel } from "./components/InputDirectorPanel";
import { AIDirectorPanel } from "./components/AIDirectorPanel";
import { ReferenceAndModelsView } from "./components/ReferenceAndModelsView";
import { SceneInspectorPanel } from "./components/SceneInspectorPanel";
import { VideoPreviewStage } from "./components/VideoPreviewStage";
import { DEFAULT_BLUEPRINT } from "./data/presets";
import { runBlueprintQualityControl } from "./lib/languageSync";
import type {
  AspectRatio,
  FailureDiagnostic,
  GenerationWorkflowState,
  LanguagePreference,
  ModelUsageReport,
  ProcessProgress,
  VideoBlueprint,
  VideoScene,
  VideoStyleId,
  VoiceName,
} from "./types/video";

type NavTab = "studio" | "models" | "reference" | "guide";

export interface TextGenerateParams {
  prompt: string;
  style: VideoStyleId;
  aspectRatio: AspectRatio;
  durationPreset: "short" | "medium" | "long";
  voiceName: VoiceName;
  brandHandle: string;
  audioMode: "ai-narration" | "no-audio";
  languagePreference?: LanguagePreference;
}

export interface AudioGenerateParams {
  audioBase64: string;
  mimeType: string;
  audioUrl: string;
  durationSeconds: number;
  style: VideoStyleId;
  aspectRatio: AspectRatio;
  visualHint: string;
  brandHandle: string;
  languagePreference?: LanguagePreference;
  cachedTranscript?: string;
}

type FailedAction =
  | { type: "text"; params: TextGenerateParams }
  | { type: "audio"; params: AudioGenerateParams }
  | { type: "voice" };

interface DiagnosticError extends Error {
  diagnostics?: FailureDiagnostic;
  transcript?: string;
}

function createDiagnosticError(
  message: string,
  diagnostics?: FailureDiagnostic,
  transcript?: string
): DiagnosticError {
  const err = new Error(message) as DiagnosticError;
  if (diagnostics) err.diagnostics = diagnostics;
  if (transcript) err.transcript = transcript;
  return err;
}

const IDLE_PROGRESS: ProcessProgress = {
  active: false,
  percent: 0,
  stageLabel: "",
  startedAt: 0,
};

function mapHttpStatusToMessage(status: number, fallbackText?: string): string {
  switch (status) {
    case 400:
      return fallbackText || "Permintaan atau konfigurasi API tidak valid (400).";
    case 401:
    case 403:
      return fallbackText || "Akses API ditolak (403). Periksa kunci API pada Secrets.";
    case 404:
      return fallbackText || "Endpoint atau model AI tidak ditemukan (404).";
    case 429:
      return (
        fallbackText ||
        "Batas kuota atau laju permintaan AI tercapai (429). Tunggu sebentar lalu coba lagi."
      );
    case 500:
      return (
        fallbackText ||
        "Terjadi kesalahan internal pada server AI (500). Silakan coba lagi."
      );
    case 502:
      return (
        fallbackText ||
        "Gangguan jaringan gateway menuju layanan AI (502). Silakan coba lagi."
      );
    case 503:
      return (
        fallbackText ||
        "Layanan AI sedang sibuk atau tidak tersedia sementara (503 UNAVAILABLE). Silakan klik Coba Lagi."
      );
    case 504:
      return (
        fallbackText ||
        "Waktu tunggu server AI habis (504 Gateway Timeout). Silakan coba lagi."
      );
    default:
      return fallbackText || `Permintaan gagal diproses (HTTP ${status}).`;
  }
}

async function fetchNdjsonWithProgress<T extends Record<string, unknown>>(
  url: string,
  body: Record<string, unknown>,
  onProgress: (patch: {
    percent: number;
    stageLabel: string;
    detailLabel?: string;
    estimatedTotalSeconds?: number;
    retryAttempt?: number;
    maxRetries?: number;
  }) => void
): Promise<T> {
  let resp: Response;
  try {
    resp = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...body, streamProgress: true }),
    });
  } catch {
    throw new Error(
      "Koneksi ke server studio terputus. Periksa jaringan lalu klik Coba Lagi."
    );
  }

  const contentType = resp.headers.get("content-type") || "";

  if (!resp.ok) {
    if (contentType.includes("application/json")) {
      const errJson = (await resp.json().catch(() => ({}))) as {
        error?: string;
        diagnostics?: FailureDiagnostic;
        transcript?: string;
      };
      throw createDiagnosticError(
        mapHttpStatusToMessage(resp.status, errJson.error),
        errJson.diagnostics,
        errJson.transcript
      );
    }
    const rawText = await resp.text().catch(() => "");
    const safeSnippet =
      rawText && !rawText.trim().startsWith("<")
        ? rawText.trim().slice(0, 220)
        : undefined;
    throw new Error(mapHttpStatusToMessage(resp.status, safeSnippet));
  }

  if (!resp.body) {
    if (contentType.includes("application/json")) {
      const fallback = (await resp.json()) as T;
      return fallback;
    }
    throw new Error("Server tidak mengembalikan aliran data yang valid.");
  }

  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let finalPayload: T | null = null;

  const processLine = (line: string) => {
    let msg: {
      type?: string;
      percent?: number;
      stageLabel?: string;
      detailLabel?: string;
      estimatedTotalSeconds?: number;
      retryAttempt?: number;
      maxRetries?: number;
      error?: string;
      diagnostics?: FailureDiagnostic;
      transcript?: string;
    } & T;

    try {
      msg = JSON.parse(line);
    } catch {
      throw new Error(
        "Respons dari server terpotong atau tidak valid. Silakan klik Coba Lagi."
      );
    }

    if (msg.type === "progress") {
      onProgress({
        percent: msg.percent ?? 0,
        stageLabel: msg.stageLabel ?? "Memproses...",
        detailLabel: msg.detailLabel,
        estimatedTotalSeconds: msg.estimatedTotalSeconds,
        retryAttempt: msg.retryAttempt,
        maxRetries: msg.maxRetries,
      });
    } else if (msg.type === "error") {
      throw createDiagnosticError(
        msg.error || "Terjadi kesalahan saat memproses permintaan AI.",
        msg.diagnostics,
        msg.transcript
      );
    } else if (msg.type === "done") {
      finalPayload = msg;
    }
  };

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    let newlineIdx = buffer.indexOf("\n");
    while (newlineIdx !== -1) {
      const line = buffer.slice(0, newlineIdx).trim();
      buffer = buffer.slice(newlineIdx + 1);
      if (line) {
        processLine(line);
      }
      newlineIdx = buffer.indexOf("\n");
    }
  }

  if (buffer.trim()) {
    processLine(buffer.trim());
  }

  if (!finalPayload) {
    throw new Error(
      "Aliran data selesai sebelum hasil video terbentuk. Silakan klik Coba Lagi."
    );
  }
  return finalPayload;
}

function base64WavToObjectUrl(base64: string): string {
  const binary = atob(base64);
  if (binary.length < 44) {
    throw new Error("Berkas audio hasil sintesis tidak valid atau terlalu pendek.");
  }
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  const blob = new Blob([bytes], { type: "audio/wav" });
  return URL.createObjectURL(blob);
}

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>("studio");
  const [blueprint, setBlueprint] = useState<VideoBlueprint>(() =>
    runBlueprintQualityControl(DEFAULT_BLUEPRINT)
  );
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);

  const [workflowState, setWorkflowState] =
    useState<GenerationWorkflowState>("idle");
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [genProgress, setGenProgress] = useState<ProcessProgress>(IDLE_PROGRESS);
  const [isRegeneratingVoice, setIsRegeneratingVoice] = useState<boolean>(false);
  const [isAIRevising, setIsAIRevising] = useState<boolean>(false);
  const [aiRevisionHistory, setAiRevisionHistory] = useState<Array<{ instruction: string; blueprint: VideoBlueprint }>>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [failureDiagnostic, setFailureDiagnostic] =
    useState<FailureDiagnostic | null>(null);
  const [modelReports, setModelReports] = useState<ModelUsageReport[]>([]);
  const [lastFailedAction, setLastFailedAction] = useState<FailedAction | null>(
    null
  );
  const [exportRequestCounter, setExportRequestCounter] = useState<number>(0);

  // Keep the revision stack scoped to the active video project.
  useEffect(() => {
    setAiRevisionHistory([]);
  }, [blueprint.id]);

  // Synchronous request lock to prevent duplicate concurrent submissions
  const inFlightRef = useRef<boolean>(false);

  const replaceAudioUrl = useCallback((nextUrl: string | null) => {
    setAudioUrl((prev) => {
      if (prev && prev.startsWith("blob:")) {
        URL.revokeObjectURL(prev);
      }
      return nextUrl;
    });
  }, []);

  useEffect(() => {
    return () => {
      if (audioUrl && audioUrl.startsWith("blob:")) {
        URL.revokeObjectURL(audioUrl);
      }
    };
  }, [audioUrl]);

  const handleSelectStyle = (style: VideoStyleId) => {
    setBlueprint((prev) => ({ ...prev, style }));
  };

  const handleSelectAspectRatio = (aspectRatio: AspectRatio) => {
    setBlueprint((prev) => ({ ...prev, aspectRatio }));
  };

  const handleGenerateFromText = async (params: TextGenerateParams) => {
    if (inFlightRef.current || isGenerating || isRegeneratingVoice) {
      return;
    }
    inFlightRef.current = true;
    setErrorMsg(null);
    setFailureDiagnostic(null);
    setModelReports([]);
    setLastFailedAction(null);
    setWorkflowState("loading");
    setIsPlaying(false);
    setIsGenerating(true);

    const startedAt = Date.now();
    setGenProgress({
      active: true,
      percent: 5,
      stageLabel: "Mengirim naskah ke studio AI...",
      startedAt,
      estimatedTotalSeconds:
        params.durationPreset === "short"
          ? 7
          : params.durationPreset === "long"
          ? 13
          : 9,
    });

    try {
      const shouldGenerateAudio = params.audioMode === "ai-narration";
      const data = await fetchNdjsonWithProgress<{
        blueprint?: VideoBlueprint;
        audioBase64?: string;
        ttsSkipped?: boolean;
        modelReports?: ModelUsageReport[];
        ttsFailed?: boolean;
        ttsError?: string;
        diagnostics?: FailureDiagnostic;
      }>(
        "/api/generate-from-text",
        {
          ...params,
          audioMode: params.audioMode,
          generateAudio: shouldGenerateAudio,
          languagePreference: params.languagePreference || "auto",
        },
        (patch) =>
          setGenProgress((prev) => ({
            ...prev,
            active: true,
            percent: patch.percent,
            stageLabel: patch.stageLabel,
            detailLabel: patch.detailLabel,
            estimatedTotalSeconds: patch.estimatedTotalSeconds,
            retryAttempt: patch.retryAttempt,
            maxRetries: patch.maxRetries,
          }))
      );

      const nextBlueprint = data.blueprint;
      if (
        !nextBlueprint ||
        !Array.isArray(nextBlueprint.scenes) ||
        nextBlueprint.scenes.length === 0
      ) {
        throw new Error(
          "Storyboard video kosong atau tidak valid. Proses pembuatan video gagal."
        );
      }

      if (!shouldGenerateAudio || data.ttsSkipped) {
        replaceAudioUrl(null);
        setBlueprint({ ...nextBlueprint, audioMode: "no-audio" });
        setModelReports(data.modelReports ?? []);
        setCurrentTime(0);
        setGenProgress({
          active: false,
          percent: 100,
          stageLabel: "Video tanpa audio siap diputar!",
          startedAt,
        });
        setWorkflowState("completed");
        setIsPlaying(true);
        return;
      }

      if (data.ttsFailed) {
        // Preserve visual storyboard & timeline so user can preview or export without narration,
        // and Coba Lagi only retries TTS (/api/regenerate-voice).
        replaceAudioUrl(null);
        setBlueprint(nextBlueprint);
        setModelReports(data.modelReports ?? []);
        setCurrentTime(0);
        setGenProgress(IDLE_PROGRESS);
        setWorkflowState("failed");
        setIsPlaying(false);
        setLastFailedAction({ type: "voice" });
        setFailureDiagnostic(data.diagnostics ?? null);
        setErrorMsg(
          data.ttsError ||
            "Sintesis suara gagal, namun preview visual berhasil dibuat dan siap diekspor tanpa narasi."
        );
        return;
      }

      if (!data.audioBase64) {
        throw new Error(
          "Audio narator tidak diterima dari server. Proses pembuatan video belum lengkap."
        );
      }

      const nextAudioUrl = base64WavToObjectUrl(data.audioBase64);

      replaceAudioUrl(nextAudioUrl);
      setBlueprint({ ...nextBlueprint, audioMode: "ai-narration" });
      setModelReports(data.modelReports ?? []);
      setCurrentTime(0);
      setGenProgress({
        active: false,
        percent: 100,
        stageLabel: "Video siap diputar!",
        startedAt,
      });
      setWorkflowState("completed");
      setIsPlaying(true);
    } catch (err) {
      const diagErr = err as DiagnosticError;
      setWorkflowState("failed");
      setIsPlaying(false);
      setLastFailedAction({ type: "text", params });
      setGenProgress(IDLE_PROGRESS);
      setFailureDiagnostic(diagErr?.diagnostics ?? null);
      setErrorMsg(
        err instanceof Error ? err.message : "Terjadi kendala saat membuat video."
      );
    } finally {
      inFlightRef.current = false;
      setIsGenerating(false);
    }
  };

  const handleGenerateFromAudio = async (params: AudioGenerateParams) => {
    if (inFlightRef.current || isGenerating || isRegeneratingVoice) {
      return;
    }
    inFlightRef.current = true;
    setErrorMsg(null);
    setFailureDiagnostic(null);
    setModelReports([]);
    setLastFailedAction(null);
    setWorkflowState("loading");
    setIsPlaying(false);
    setIsGenerating(true);

    const startedAt = Date.now();
    setGenProgress({
      active: true,
      percent: 8,
      stageLabel: params.cachedTranscript
        ? "Menyusun adegan dari transkrip tersimpan..."
        : "Mengunggah audio & memulai transkripsi...",
      startedAt,
      estimatedTotalSeconds: 8,
    });

    try {
      const data = await fetchNdjsonWithProgress<{
        blueprint?: VideoBlueprint;
        modelReports?: ModelUsageReport[];
      }>(
        "/api/generate-from-audio",
        {
          audioBase64: params.audioBase64,
          mimeType: params.mimeType,
          durationSeconds: params.durationSeconds,
          style: params.style,
          aspectRatio: params.aspectRatio,
          visualHint: params.visualHint,
          brandHandle: params.brandHandle,
          languagePreference: params.languagePreference || "auto",
          cachedTranscript: params.cachedTranscript,
        },
        (patch) =>
          setGenProgress((prev) => ({
            ...prev,
            active: true,
            percent: patch.percent,
            stageLabel: patch.stageLabel,
            detailLabel: patch.detailLabel,
            estimatedTotalSeconds: patch.estimatedTotalSeconds,
            retryAttempt: patch.retryAttempt,
            maxRetries: patch.maxRetries,
          }))
      );

      const nextBlueprint = data.blueprint;
      if (
        !nextBlueprint ||
        !Array.isArray(nextBlueprint.scenes) ||
        nextBlueprint.scenes.length === 0
      ) {
        throw new Error(
          "Gagal memetakan adegan video dari audio Anda. Pastikan audio terdengar jelas."
        );
      }

      const clonedAudioResp = await fetch(params.audioUrl);
      if (!clonedAudioResp.ok) {
        throw new Error("Berkas audio lokal tidak dapat dibaca ulang.");
      }
      const clonedBlob = await clonedAudioResp.blob();
      const persistentUrl = URL.createObjectURL(clonedBlob);

      replaceAudioUrl(persistentUrl);
      setBlueprint(nextBlueprint);
      setModelReports(data.modelReports ?? []);
      setCurrentTime(0);
      setGenProgress({
        active: false,
        percent: 100,
        stageLabel: "Video dari audio siap diputar!",
        startedAt,
      });
      setWorkflowState("completed");
      setIsPlaying(true);
    } catch (err) {
      const diagErr = err as DiagnosticError;
      setWorkflowState("failed");
      setIsPlaying(false);
      setLastFailedAction({
        type: "audio",
        params: diagErr?.transcript
          ? { ...params, cachedTranscript: diagErr.transcript }
          : params,
      });
      setGenProgress(IDLE_PROGRESS);
      setFailureDiagnostic(diagErr?.diagnostics ?? null);
      setErrorMsg(
        err instanceof Error ? err.message : "Gagal memproses audio menjadi video."
      );
    } finally {
      inFlightRef.current = false;
      setIsGenerating(false);
    }
  };

  const handleUpdateScene = (sceneId: string, patch: Partial<VideoScene>) => {
    setBlueprint((prev) =>
      runBlueprintQualityControl({
        ...prev,
        scenes: prev.scenes.map((s) => (s.id === sceneId ? { ...s, ...patch } : s)),
      })
    );
  };

  const handleChangeLanguagePreference = (
    languagePreference: LanguagePreference
  ) => {
    setBlueprint((prev) =>
      runBlueprintQualityControl({
        ...prev,
        languagePreference,
      })
    );
  };

  const handleRegenerateVoice = async () => {
    if (inFlightRef.current || isGenerating || isRegeneratingVoice) {
      return;
    }
    inFlightRef.current = true;
    setErrorMsg(null);
    setFailureDiagnostic(null);
    setModelReports([]);
    setLastFailedAction(null);
    setWorkflowState("loading");
    setIsPlaying(false);
    setIsRegeneratingVoice(true);

    const startedAt = Date.now();
    setGenProgress({
      active: true,
      percent: 8,
      stageLabel: "Menyiapkan sinkronisasi suara...",
      startedAt,
      estimatedTotalSeconds: Math.max(3, blueprint.scenes.length * 2),
    });

    try {
      const data = await fetchNdjsonWithProgress<{
        audioBase64?: string;
        durations?: number[];
        modelReports?: ModelUsageReport[];
      }>(
        "/api/regenerate-voice",
        {
          narrations: blueprint.scenes.map((s) => s.narration),
          voiceName: blueprint.voiceName || "Kore",
          style: blueprint.style,
          languagePreference: blueprint.languagePreference || "auto",
        },
        (patch) =>
          setGenProgress((prev) => ({
            ...prev,
            active: true,
            percent: patch.percent,
            stageLabel: patch.stageLabel,
            detailLabel: patch.detailLabel,
            estimatedTotalSeconds: patch.estimatedTotalSeconds,
            retryAttempt: patch.retryAttempt,
            maxRetries: patch.maxRetries,
          }))
      );

      if (!data.audioBase64) {
        throw new Error("Audio narator gagal disintesis ulang.");
      }

      const nextAudioUrl = base64WavToObjectUrl(data.audioBase64);
      const durations: number[] = data.durations || [];
      let cursor = 0;
      const updatedScenes = blueprint.scenes.map((scene, idx) => {
        const dur = Number((durations[idx] ?? scene.durationSeconds).toFixed(2));
        const startTime = Number(cursor.toFixed(2));
        cursor += dur;
        return {
          ...scene,
          durationSeconds: dur,
          startTime,
          endTime: Number(cursor.toFixed(2)),
        };
      });

      replaceAudioUrl(nextAudioUrl);
      setBlueprint((prev) =>
        runBlueprintQualityControl({
          ...prev,
          audioMode: "ai-narration",
          totalDuration: Number(cursor.toFixed(2)),
          scenes: updatedScenes,
        })
      );
      setModelReports(data.modelReports ?? []);
      setCurrentTime(0);
      setGenProgress({
        active: false,
        percent: 100,
        stageLabel: "Suara & adegan berhasil disinkronkan!",
        startedAt,
      });
      setWorkflowState("completed");
    } catch (err) {
      const diagErr = err as DiagnosticError;
      setWorkflowState("failed");
      setIsPlaying(false);
      setLastFailedAction({ type: "voice" });
      setGenProgress(IDLE_PROGRESS);
      setFailureDiagnostic(diagErr?.diagnostics ?? null);
      setErrorMsg(
        err instanceof Error ? err.message : "Gagal menyinkronkan suara."
      );
    } finally {
      inFlightRef.current = false;
      setIsRegeneratingVoice(false);
    }
  };

  const handleRetryLastRequest = () => {
    if (!lastFailedAction || inFlightRef.current) return;
    if (lastFailedAction.type === "text") {
      void handleGenerateFromText(lastFailedAction.params);
    } else if (lastFailedAction.type === "audio") {
      void handleGenerateFromAudio(lastFailedAction.params);
    } else {
      void handleRegenerateVoice();
    }
  };

  const handleExportWithoutAudio = () => {
    if (isBusy) return;
    setActiveTab("studio");
    setExportRequestCounter((c) => c + 1);
  };

  const handleChangeProjectAudioMode = (
    nextMode: "ai-narration" | "no-audio"
  ) => {
    if (isBusy) return;
    // Update only the project audio mode without regenerating the storyboard
    setBlueprint((prev) => ({
      ...prev,
      audioMode: nextMode,
    }));
    if (nextMode === "no-audio") {
      replaceAudioUrl(null);
      if (failureDiagnostic?.failedStage === "tts") {
        setErrorMsg(null);
        setFailureDiagnostic(null);
        setLastFailedAction(null);
        setWorkflowState("completed");
      }
    }
  };

  const handleAIRevision = async (instruction: string) => {
    if (inFlightRef.current || isBusy || isAIRevising) return;
    inFlightRef.current = true;
    setIsAIRevising(true);
    setErrorMsg(null);
    setFailureDiagnostic(null);
    setIsPlaying(false);
    setGenProgress({ active: true, percent: 12, stageLabel: "Sutradara AI sedang merevisi storyboard...", startedAt: Date.now() });
    try {
      const response = await fetch("/api/ai-director/revise", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ instruction, blueprint, revisionContext: aiRevisionHistory.slice(-5).map((item) => item.instruction) }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || `Revisi AI gagal (HTTP ${response.status}).`);
      if (!data.blueprint || !Array.isArray(data.blueprint.scenes) || data.blueprint.scenes.length === 0) {
        throw new Error("Sutradara AI tidak mengembalikan storyboard yang valid.");
      }
      setAiRevisionHistory((previous) => [...previous, { instruction, blueprint }].slice(-10));
      setBlueprint(runBlueprintQualityControl(data.blueprint as VideoBlueprint));
      setModelReports(data.modelReports ?? []);
      setCurrentTime(0);
      setGenProgress({ active: false, percent: 100, stageLabel: "Revisi Sutradara AI selesai!", startedAt: Date.now() });
      setWorkflowState("completed");
      setIsPlaying(true);
    } catch (err) {
      setGenProgress(IDLE_PROGRESS);
      setWorkflowState("failed");
      const message = err instanceof Error ? err.message : "Revisi AI gagal dijalankan.";
      setErrorMsg(message);
      throw new Error(message);
    } finally {
      inFlightRef.current = false;
      setIsAIRevising(false);
    }
  };

  const handleUndoAIRevision = () => {
    if (isBusy || aiRevisionHistory.length === 0) return;
    const previous = aiRevisionHistory[aiRevisionHistory.length - 1];
    setBlueprint(previous.blueprint);
    setAiRevisionHistory((items) => items.slice(0, -1));
    setCurrentTime(0);
    setIsPlaying(false);
    setWorkflowState("completed");
    setErrorMsg(null);
  };

  const isBusy = isGenerating || isRegeneratingVoice || isAIRevising;

  return (
    <div className="min-h-screen bg-[#F7F7F5] text-slate-900 flex flex-col">
      {/* Three-Zone Top Bar Contract */}
      <header className="bg-white border-b border-slate-200 px-6 py-3.5 sticky top-0 z-30">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-8">
          <a
            href="#studio"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab("studio");
            }}
            className="text-lg font-extrabold tracking-tight text-slate-900 whitespace-nowrap shrink-0 font-display"
          >
            Izzy Studio
          </a>

          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            {(
              [
                { id: "studio", label: "Studio" },
                { id: "models", label: "Model Video" },
                { id: "reference", label: "Komponen" },
                { id: "guide", label: "Panduan" },
              ] as const
            ).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`py-1 border-b-2 transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === item.id
                    ? "border-blue-700 text-slate-900 font-semibold"
                    : "border-transparent hover:text-slate-900"
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex items-center shrink-0">
            <button
              type="button"
              disabled={isBusy}
              onClick={() => {
                setActiveTab("studio");
                setExportRequestCounter((c) => c + 1);
              }}
              className="px-4 py-2 rounded-lg bg-blue-700 hover:bg-blue-800 disabled:bg-blue-400 text-white text-xs font-semibold transition-colors whitespace-nowrap shrink-0"
            >
              Ekspor Video
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Tab Strip */}
      <div className="md:hidden bg-white border-b border-slate-200 px-4 py-2 flex items-center gap-4 overflow-x-auto">
        {(
          [
            { id: "studio", label: "Studio" },
            { id: "models", label: "Model Video" },
            { id: "reference", label: "Komponen" },
            { id: "guide", label: "Panduan" },
          ] as const
        ).map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setActiveTab(item.id)}
            className={`text-xs font-semibold py-1 whitespace-nowrap shrink-0 ${
              activeTab === item.id
                ? "text-blue-700 border-b-2 border-blue-700"
                : "text-slate-600"
            }`}
          >
            {item.label}
          </button>
        ))}
      </div>

      {/* Main Content */}
      <main className="flex-1 w-full">
        {activeTab === "studio" ? (
          <div className="max-w-[1440px] mx-auto px-4 sm:px-6 py-5 grid grid-cols-1 lg:grid-cols-[360px_minmax(0,1fr)_340px] gap-5 items-start">
            <InputDirectorPanel
              activeStyle={blueprint.style}
              onSelectStyle={handleSelectStyle}
              activeAspectRatio={blueprint.aspectRatio}
              onSelectAspectRatio={handleSelectAspectRatio}
              isGenerating={isBusy}
              workflowState={workflowState}
              genProgress={genProgress}
              errorMsg={errorMsg}
              failureDiagnostic={failureDiagnostic}
              retryLabel={
                lastFailedAction?.type === "voice"
                  ? "Coba Lagi Suara"
                  : lastFailedAction?.type === "audio" &&
                    lastFailedAction.params.cachedTranscript
                  ? "Coba Lagi Adegan"
                  : "Coba Lagi"
              }
              onExportWithoutAudio={
                !audioUrl && blueprint.scenes.length > 0
                  ? handleExportWithoutAudio
                  : undefined
              }
              modelReports={modelReports}
              canRetry={Boolean(lastFailedAction)}
              onRetry={handleRetryLastRequest}
              onGenerateFromText={handleGenerateFromText}
              onGenerateFromAudio={handleGenerateFromAudio}
            />

            <div className="min-w-0 space-y-4">
            <VideoPreviewStage
              blueprint={blueprint}
              audioUrl={audioUrl}
              currentTime={currentTime}
              isPlaying={isPlaying}
              workflowState={workflowState}
              genProgress={genProgress}
              errorMsg={errorMsg}
              failureDiagnostic={failureDiagnostic}
              retryLabel={
                lastFailedAction?.type === "voice"
                  ? "Coba Lagi Suara"
                  : lastFailedAction?.type === "audio" &&
                    lastFailedAction.params.cachedTranscript
                  ? "Coba Lagi Adegan"
                  : "Coba Lagi"
              }
              onExportWithoutAudio={
                !audioUrl && blueprint.scenes.length > 0
                  ? handleExportWithoutAudio
                  : undefined
              }
              canRetry={Boolean(lastFailedAction)}
              onRetry={handleRetryLastRequest}
              onTimeUpdate={setCurrentTime}
              onPlayStateChange={setIsPlaying}
              exportRequestCounter={exportRequestCounter}
            />
            <AIDirectorPanel
              isBusy={isBusy}
              onRevise={handleAIRevision}
              canUndo={aiRevisionHistory.length > 0}
              revisionCount={aiRevisionHistory.length}
              onUndo={handleUndoAIRevision}
            />
            </div>

            <SceneInspectorPanel
              blueprint={blueprint}
              currentTime={currentTime}
              isBusy={isBusy}
              isRegeneratingVoice={isRegeneratingVoice}
              voiceProgressPercent={genProgress.percent}
              onSeekToScene={(t) => {
                setIsPlaying(false);
                setCurrentTime(t);
              }}
              onUpdateScene={handleUpdateScene}
              onUpdateSubjectNameplate={(nameplate) =>
                setBlueprint((prev) => ({
                  ...prev,
                  subjectNameplate: nameplate,
                }))
              }
              onChangeAudioMode={handleChangeProjectAudioMode}
              onChangeLanguagePreference={handleChangeLanguagePreference}
              onRegenerateVoice={handleRegenerateVoice}
            />
          </div>
        ) : (
          <ReferenceAndModelsView
            mode={activeTab}
            activeStyle={blueprint.style}
            onSelectStyleAndOpenStudio={(style) => {
              handleSelectStyle(style);
              setActiveTab("studio");
            }}
            onBackToStudio={() => setActiveTab("studio")}
          />
        )}
      </main>
    </div>
  );
}
