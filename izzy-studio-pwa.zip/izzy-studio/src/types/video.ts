export type VideoStyleId =
  | 'editorial-desk'
  | 'tech-blueprint'
  | 'kinetic-cards'
  | 'newsroom-brief'
  | 'audio-pulse'
  | 'creator-showcase';

export type AspectRatio = '9:16' | '16:9' | '1:1';

export type SceneArchetype =
  | 'desk_intro'
  | 'metric_counter'
  | 'network_graph'
  | 'document_audit'
  | 'server_radar'
  | 'news_map_card'
  | 'balance_verdict'
  | 'kinetic_statement';

export type VoiceName = 'Kore' | 'Puck' | 'Charon' | 'Fenrir' | 'Zephyr';

export interface SceneMetric {
  prefix: string;
  targetValue: number;
  decimals: number;
  suffix: string;
  unitLabel: string;
  sourceLabel: string;
}

export interface TableRowEntry {
  taskLabel: string;
  aiAction: string;
  evidenceText: string;
  status: 'pending' | 'warning' | 'verified';
}

export interface NewsCardData {
  tag: string;
  headline: string;
  regionName: string;
  subDetail?: string;
}

export type SceneTransition =
  | 'fade'
  | 'slide'
  | 'zoom'
  | 'whip'
  | 'morph'
  | 'depth'
  | 'none';

export type VideoAudioMode = 'ai-narration' | 'no-audio' | 'uploaded-audio';

export type SupportedLanguage = 'id-ID' | 'en-US' | 'mixed';

export type LanguagePreference = 'auto' | 'id-ID' | 'en-US';

export type VisualAssetKey =
  | 'projectile_bullet'
  | 'human_silhouette'
  | 'human_anatomy'
  | 'heart_organ'
  | 'brain_organ'
  | 'vehicle_car'
  | 'solar_planet'
  | 'earthquake_seismic'
  | 'tech_circuit'
  | 'ocean_marine'
  | 'energy_solar'
  | 'money_economy'
  | 'editorial_desk'
  | 'server_cyber'
  | 'data_network'
  | 'law_balance'
  | 'news_globe'
  | 'concept_diagram';

export type VisualCameraMovement =
  | 'static'
  | 'zoom_in'
  | 'zoom_out'
  | 'dolly_in'
  | 'orbit'
  | 'tilt_focus'
  | 'pan_left'
  | 'pan_right'
  | 'track_object';

export type VisualAnimationType =
  | 'trajectory'
  | 'pulse'
  | 'scan_highlight'
  | 'orbit'
  | 'shake_wave'
  | 'flow_stream'
  | 'scale_compare'
  | 'float_drift';

export type AnimationIntensity = 'subtle' | 'balanced' | 'cinematic';

export type MotionTimingCurve =
  | 'ease_in_out'
  | 'spring'
  | 'linear_flow'
  | 'dramatic_ramp';

export type EnvironmentalEffectType =
  | 'ambient_dust'
  | 'blood_flow'
  | 'starfield_drift'
  | 'seismic_tremor'
  | 'data_streams'
  | 'ocean_bubbles'
  | 'energy_sparks'
  | 'shockwave_rings';

export type NarrationAnimationTrigger =
  | 'enter'
  | 'accelerate'
  | 'highlight'
  | 'pulse'
  | 'orbit'
  | 'resolve';

export interface NarrationSegment {
  text: string;
  language: 'id-ID' | 'en-US';
  startTime: number;
  endTime: number;
  visualEvent: string;
  cameraEvent: VisualCameraMovement;
  animationTrigger: NarrationAnimationTrigger;
  intensityBoost?: number;
}

export interface SceneVisualSpec {
  assetKey: VisualAssetKey;
  subject: string;
  action: string;
  environment: string;
  objects: string[];
  visualDescription: string;
  cameraMovement: VisualCameraMovement;
  animationType: VisualAnimationType;
  focusRegion?: string;
  objectMovement?: string;
  secondaryAnimation?: string;
  environmentalEffect?: EnvironmentalEffectType;
  animationIntensity?: AnimationIntensity;
  motionTiming?: MotionTimingCurve;
  narrationSyncCue?: string;
}

export interface VideoScene {
  id: string;
  archetype: SceneArchetype;
  transition?: SceneTransition;
  language?: SupportedLanguage;
  topTitle: string;
  topHighlightWord: string;
  topSubLabel: string;
  narration: string;
  narrationSegments?: NarrationSegment[];
  durationSeconds: number;
  startTime: number;
  endTime: number;
  visualMetric?: SceneMetric;
  tableRow?: TableRowEntry;
  newsCard?: NewsCardData;
  bullets?: string[];
  calloutBadge?: string;
  sceneVisualSpec?: SceneVisualSpec;
}

export interface VideoBlueprint {
  id: string;
  title: string;
  subjectNameplate: string;
  brandHandle: string;
  tableColumns: [string, string, string];
  style: VideoStyleId;
  aspectRatio: AspectRatio;
  totalDuration: number;
  sourceMode: 'text' | 'audio';
  audioMode?: VideoAudioMode;
  languagePreference?: LanguagePreference;
  detectedLanguage?: SupportedLanguage;
  voiceName?: VoiceName;
  transcript?: string;
  scenes: VideoScene[];
}

export interface VideoStyleMeta {
  id: VideoStyleId;
  name: string;
  tagline: string;
  palettePreview: [string, string, string];
  bestFor: string;
}

export interface VoiceOption {
  id: VoiceName;
  label: string;
  tone: string;
}

export type GenerationWorkflowState =
  | 'idle'
  | 'loading'
  | 'completed'
  | 'failed';

export interface ModelUsageReport {
  task: 'storyboard' | 'transcription' | 'tts';
  primaryModel: string;
  usedModel: string;
  fallbackUsed: boolean;
  fallbackReason?: string;
}

export interface FailureDiagnostic {
  endpoint: string;
  failedStage: 'storyboard' | 'tts' | 'transcription' | 'validation' | 'server';
  model: string;
  httpStatus: number | null;
  causeType: 'rate_limit' | 'quota_exhausted' | 'server_error' | 'network' | 'validation';
  retryAfterSeconds?: number;
  quotaMetric?: string;
  detail?: string;
}

export interface ProcessProgress {
  active: boolean;
  percent: number;
  stageLabel: string;
  detailLabel?: string;
  startedAt: number;
  estimatedTotalSeconds?: number;
  retryAttempt?: number;
  maxRetries?: number;
}
