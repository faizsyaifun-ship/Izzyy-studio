import type {
  AnimationIntensity,
  EnvironmentalEffectType,
  LanguagePreference,
  MotionTimingCurve,
  SceneArchetype,
  SceneTransition,
  VideoBlueprint,
  VideoStyleMeta,
  VisualAnimationType,
  VisualAssetKey,
  VisualCameraMovement,
  VoiceOption,
} from '../types/video';

export const VIDEO_STYLES: VideoStyleMeta[] = [
  {
    id: 'editorial-desk',
    name: 'Editorial Desk & Matrix',
    tagline: 'Ilustrasi meja 2.5D, tabel bukti progresif, grafik jaringan, & subtitle sorot.',
    palettePreview: ['#F5F0E6', '#1E293B', '#D97706'],
    bestFor: 'Video edukasi kebijakan, investigasi data, dan explainer vertikal',
  },
  {
    id: 'tech-blueprint',
    name: 'Tech Blueprint & Node',
    tagline: 'Kanvas arsitektur gelap presisi dengan jaringan simpul dan metrik teknis.',
    palettePreview: ['#0F172A', '#1E293B', '#3B82F6'],
    bestFor: 'Penjelasan sistem AI, keamanan siber, dan alur teknologi',
  },
  {
    id: 'kinetic-cards',
    name: 'Kinetic Editorial Cards',
    tagline: 'Tipografi kontras tinggi, kartu statistik cepat, dan penekanan kata kunci.',
    palettePreview: ['#FAFAFA', '#111827', '#1D4ED8'],
    bestFor: 'Ringkasan berita bisnis, fakta cepat, dan konten media sosial',
  },
  {
    id: 'newsroom-brief',
    name: 'Newsroom Broadcast',
    tagline: 'Bingkai siaran berita formal lengkap dengan kartu wilayah dan ticker bawah.',
    palettePreview: ['#F8FAFC', '#0F172A', '#DC2626'],
    bestFor: 'Laporan peristiwa terkini, geopolitik, dan analisis ekonomi',
  },
  {
    id: 'creator-showcase',
    name: 'Creator Portfolio Motion',
    tagline: 'UI mengambang, panel ungu, social icons, teks kinetic blur-reveal, dan logo outro.',
    palettePreview: ['#F4F5FA', '#111116', '#7C3AED'],
    bestFor: 'Showreel kreator, portfolio, promosi jasa, profil brand, dan intro channel',
  },
  {
    id: 'audio-pulse',
    name: 'Sonic Pulse Visualizer',
    tagline: 'Spektrum gelombang audio reaktif berpadu dengan tipografi narasi dinamis.',
    palettePreview: ['#09090B', '#18181B', '#10B981'],
    bestFor: 'Klip podcast, voice note naratif, dan monolog berirama',
  },
];

export const ARCHETYPE_LABELS: Record<SceneArchetype, string> = {
  desk_intro: 'Meja & Monitor Pembuka',
  metric_counter: 'Penghitung Angka & Perangkat',
  network_graph: 'Grafik Jaringan Simpul',
  document_audit: 'Audit Dokumen & Angka',
  server_radar: 'Server & Radar Keamanan',
  news_map_card: 'Kartu Berita & Peta',
  balance_verdict: 'Timbangan & Ringkasan',
  kinetic_statement: 'Pernyataan Kinetik',
};

export const VISUAL_ASSET_LABELS: Record<VisualAssetKey, string> = {
  projectile_bullet: 'Proyektil & Peluru (Fisika/Balistik)',
  human_silhouette: 'Siluet Tubuh Manusia',
  human_anatomy: 'Anatomi Tubuh & Area Fokus',
  heart_organ: 'Organ Jantung & Sirkulasi',
  brain_organ: 'Otak & Jaringan Saraf',
  vehicle_car: 'Mobil & Transportasi',
  solar_planet: 'Planet & Tata Surya',
  earthquake_seismic: 'Gempa Bumi & Getaran Tanah',
  tech_circuit: 'Perangkat & Sirkuit Teknologi',
  ocean_marine: 'Laut, Ombak & Biota Bawah Air',
  energy_solar: 'Energi Surya & Kelistrikan',
  money_economy: 'Ekonomi, Keuangan & Transaksi',
  server_cyber: 'Server & Keamanan Siber',
  data_network: 'Jaringan Data & Simpul',
  news_globe: 'Peta Lokasi & Berita Global',
  law_balance: 'Timbangan Hukum & Evaluasi',
  editorial_desk: 'Meja Kebijakan & Dokumen',
  concept_diagram: 'Diagram Konsep Adaptif',
};

export const CAMERA_MOVEMENT_LABELS: Record<VisualCameraMovement, string> = {
  static: 'Diam (Statis)',
  zoom_in: 'Zoom In (Mendekat)',
  zoom_out: 'Zoom Out (Menjauh)',
  dolly_in: 'Dolly Push-In (3D Depth)',
  orbit: 'Orbit Camera (Melingkar)',
  tilt_focus: 'Tilt & Focus Shift',
  pan_left: 'Pan Kiri',
  pan_right: 'Pan Kanan',
  track_object: 'Tracking Objek',
};

export const ANIMATION_TYPE_LABELS: Record<VisualAnimationType, string> = {
  trajectory: 'Lintasan Gerak',
  pulse: 'Denyut / Sorot Energi',
  scan_highlight: 'Pemindaian & Penanda Area',
  orbit: 'Orbit & Rotasi',
  shake_wave: 'Getaran & Gelombang',
  flow_stream: 'Aliran Partikel / Data',
  scale_compare: 'Perbandingan Skala',
  float_drift: 'Melayang Halus',
};

export const TRANSITION_LABELS: Record<SceneTransition, string> = {
  fade: 'Fade Halus',
  slide: 'Slide Parallax',
  zoom: 'Seamless Zoom',
  whip: 'Camera Whip Pan',
  morph: 'Spring Morph',
  depth: 'Depth Dolly',
  none: 'Cut (Tanpa Transisi)',
};

export const ENVIRONMENTAL_EFFECT_LABELS: Record<EnvironmentalEffectType, string> = {
  ambient_dust: 'Partikel Cahaya Halus',
  blood_flow: 'Aliran Sirkulasi / Partikel Darah',
  starfield_drift: 'Debu Kosmik & Bintang Parallax',
  seismic_tremor: 'Partikel Getaran & Gelombang',
  data_streams: 'Aliran Data & Sinyal Digital',
  ocean_bubbles: 'Gelembung & Arus Bawah Air',
  energy_sparks: 'Percikan Foton & Energi',
  shockwave_rings: 'Cincin Gelombang Kejut',
};

export const ANIMATION_INTENSITY_LABELS: Record<AnimationIntensity, string> = {
  subtle: 'Halus (Subtle)',
  balanced: 'Seimbang (Balanced)',
  cinematic: 'Sinematik (Cinematic)',
};

export const MOTION_TIMING_LABELS: Record<MotionTimingCurve, string> = {
  ease_in_out: 'Smooth Ease In-Out',
  spring: 'Spring Physics',
  linear_flow: 'Aliran Kontinu',
  dramatic_ramp: 'Dramatic Ramp',
};

export const LANGUAGE_PREFERENCE_OPTIONS: {
  id: LanguagePreference;
  label: string;
  description: string;
}[] = [
  { id: 'auto', label: 'Auto Detect', description: 'Deteksi ID / EN otomatis' },
  { id: 'id-ID', label: 'Indonesian', description: 'Bahasa Indonesia' },
  { id: 'en-US', label: 'English', description: 'English (US)' },
];

export const VOICE_OPTIONS: VoiceOption[] = [
  { id: 'Kore', label: 'Kore', tone: 'Jelas, lugas, cocok untuk narasi berita & edukasi' },
  { id: 'Puck', label: 'Puck', tone: 'Ekspresif dan energik untuk konten cepat' },
  { id: 'Charon', label: 'Charon', tone: 'Berat dan berwibawa untuk analisis mendalam' },
  { id: 'Fenrir', label: 'Fenrir', tone: 'Tegas, ritmis, cocok untuk investigasi data' },
  { id: 'Zephyr', label: 'Zephyr', tone: 'Tenang, halus, nyaman untuk penjelas panjang' },
];

export const TOPIC_PRESETS = [
  {
    id: 'ai-wapres',
    label: 'Andaikan AI Jadi Wapres',
    prompt:
      'Buat video explainer bergaya investigasi tentang skenario andaikan kursi Wakil Presiden diisi oleh AI. Bahas 3 tugas utama: memberantas judi online (data PPATK Rp359,8 triliun dan 200 juta transaksi), mengawasi uang negara meniru robot Alice di Brasil (BRL 9,7 miliar tender ditunda), dan menjaga data negara 24 jam belajar dari kasus ransomware PDN. Tutup dengan fakta bahwa Albania sudah mengangkat menteri AI bernama Diella dan pertanyaan siapa yang tanggung jawab jika AI salah.',
  },
  {
    id: 'energi-bersih',
    label: 'Transisi Energi Surya Indonesia',
    prompt:
      'Jelaskan potensi energi surya Indonesia yang mencapai lebih dari 3.200 GW namun baru termanfaatkan di bawah 1%. Bandingkan biaya panel surya yang turun 82% dalam satu dekade dengan ketergantungan batu bara, lalu soroti dampak penciptaan 1,2 juta lapangan kerja hijau pada 2030.',
  },
  {
    id: 'umkm-qris',
    label: 'Ledakan Ekonomi QRIS & UMKM',
    prompt:
      'Buat penjelasan cepat tentang bagaimana 32 juta merchant UMKM di Indonesia terhubung lewat QRIS. Tampilkan pertumbuhan transaksi digital lintas negara ASEAN, efisiensi waktu pencatatan kas hingga 60%, dan tantangan literasi keamanan siber bagi pedagang kecil.',
  },
  {
    id: 'krisis-air',
    label: 'Krisis Air Bersih Perkotaan',
    prompt:
      'Sajikan analisis visual tentang ancaman penurunan muka tanah dan krisis air bersih di kota besar. Paparkan angka kebocoran pipa distribusi sekitar 35%, kebutuhan investasi daur ulang air limbah industri, dan contoh sukses Singapura lewat sistem NEWater.',
  },
];

export const DEFAULT_BLUEPRINT: VideoBlueprint = {
  id: 'preset-ai-wapres',
  title: 'AI Jadi Wapres: Tugas Pertama?',
  subjectNameplate: 'WAKIL PRESIDEN',
  brandHandle: '@IZZY.STUDIO',
  tableColumns: ['Bidang', 'Tugas AI', 'Bukti Data'],
  style: 'editorial-desk',
  aspectRatio: '9:16',
  totalDuration: 36,
  sourceMode: 'text',
  audioMode: 'ai-narration',
  languagePreference: 'auto',
  detectedLanguage: 'id-ID',
  voiceName: 'Kore',
  scenes: [
    {
      id: 'scene-1',
      archetype: 'desk_intro',
      topTitle: 'AI jadi wapres: tugas pertama?',
      topHighlightWord: 'tugas pertama?',
      topSubLabel: 'SIMULASI KEBIJAKAN PUBLIK',
      narration:
        'Andaikan kursi wakil presiden diisi oleh AI. Kira-kira apa tugas pertamanya? Fokus pertama adalah memberantas judi online.',
      durationSeconds: 5.2,
      startTime: 0,
      endTime: 5.2,
      calloutBadge: 'kursi kosong',
    },
    {
      id: 'scene-2',
      archetype: 'metric_counter',
      topTitle: 'Fokus 1: Judol',
      topHighlightWord: 'Judol',
      topSubLabel: 'LAPORAN PPATK 2024',
      narration:
        'PPATK mencatat perputaran dananya mencapai tiga ratus lima puluh sembilan koma delapan triliun rupiah dalam setahun.',
      durationSeconds: 5.0,
      startTime: 5.2,
      endTime: 10.2,
      visualMetric: {
        prefix: 'Rp ',
        targetValue: 359.8,
        decimals: 1,
        suffix: ' T',
        unitLabel: 'perputaran 2024 · PPATK',
        sourceLabel: 'PPATK 2024: Rp359,8 triliun',
      },
      tableRow: {
        taskLabel: 'Judi online',
        aiAction: 'lacak aliran dana',
        evidenceText: 'Rp359,8 T (PPATK)',
        status: 'verified',
      },
    },
    {
      id: 'scene-3',
      archetype: 'network_graph',
      topTitle: 'Cari polanya otomatis',
      topHighlightWord: 'polanya',
      topSubLabel: 'DETEKSI JARINGAN TRANSAKSI',
      narration:
        'Ada lebih dari dua ratus juta transaksi mencurigakan. Mustahil dicek manual oleh manusia, tapi pas untuk AI mencari polanya.',
      durationSeconds: 5.2,
      startTime: 10.2,
      endTime: 15.4,
      visualMetric: {
        prefix: '',
        targetValue: 200.0,
        decimals: 1,
        suffix: ' Juta',
        unitLabel: 'transaksi terhubung · 2024',
        sourceLabel: '200,0 juta transaksi',
      },
      calloutBadge: 'klaster rekening',
    },
    {
      id: 'scene-4',
      archetype: 'document_audit',
      topTitle: 'Tugas 2: Uang negara',
      topHighlightWord: 'uang negara',
      topSubLabel: 'BRASIL · ROBOT ALICE',
      narration:
        'Tugas kedua menjaga uang negara. Brasil punya robot AI bernama Alice yang memeriksa tender pemerintah setiap hari. Hasilnya sembilan koma tujuh miliar real berhasil ditunda.',
      durationSeconds: 6.2,
      startTime: 15.4,
      endTime: 21.6,
      visualMetric: {
        prefix: 'BRL ',
        targetValue: 9.7,
        decimals: 1,
        suffix: ' M',
        unitLabel: 'tender ditunda atau dibatalkan',
        sourceLabel: 'Klaim Lembaga · OECD',
      },
      tableRow: {
        taskLabel: 'Uang negara',
        aiAction: 'audit tender harian',
        evidenceText: 'BRL 9,7 M ditunda',
        status: 'verified',
      },
    },
    {
      id: 'scene-5',
      archetype: 'server_radar',
      topTitle: 'Tugas 3: Data negara',
      topHighlightWord: 'data negara',
      topSubLabel: 'KEAMANAN SIBER 24 JAM',
      narration:
        'Tugas ketiga melindungi data negara. Pusat Data Nasional pernah lumpuh akibat ransomware. AI dapat berjaga dua puluh empat jam mendeteksi serangan lebih awal.',
      durationSeconds: 5.8,
      startTime: 21.6,
      endTime: 27.4,
      tableRow: {
        taskLabel: 'Data negara',
        aiAction: 'jaga sistem 24 jam',
        evidenceText: 'PDN 2024 ransomware',
        status: 'warning',
      },
      calloutBadge: 'proteksi aktif',
    },
    {
      id: 'scene-6',
      archetype: 'news_map_card',
      topTitle: 'Twist: sudah ada!',
      topHighlightWord: 'sudah ada!',
      topSubLabel: 'ALBANIA · 11 SEP 2025',
      narration:
        'Menariknya, Albania sudah mengangkat menteri AI bernama Diella untuk mengawasi pengadaan barang publik secara transparan.',
      durationSeconds: 4.4,
      startTime: 27.4,
      endTime: 31.8,
      newsCard: {
        tag: 'BERITA · ALBANIA',
        headline: 'Menteri AI: Diella',
        regionName: 'Albania',
        subDetail: 'mengawasi pengadaan publik',
      },
    },
    {
      id: 'scene-7',
      archetype: 'balance_verdict',
      topTitle: 'Siapa tanggung jawab?',
      topHighlightWord: 'tanggung jawab?',
      topSubLabel: 'TULIS PENDAPATMU',
      narration:
        'Namun jika algoritma AI membuat keputusan yang salah, siapa yang bertanggung jawab? Pilih prioritas pertamamu sekarang.',
      durationSeconds: 4.2,
      startTime: 31.8,
      endTime: 36.0,
      calloutBadge: 'siapa tanggung jawab?',
    },
  ],
};
