import type {
  EnvironmentalEffectType,
  LanguagePreference,
  NarrationAnimationTrigger,
  NarrationSegment,
  SceneTransition,
  SceneVisualSpec,
  SupportedLanguage,
  VideoBlueprint,
  VideoScene,
  VisualAssetKey,
  VisualCameraMovement,
} from "../types/video.ts";

const INDONESIAN_MARKERS = new Set([
  "yang",
  "dan",
  "di",
  "ke",
  "dari",
  "untuk",
  "dengan",
  "pada",
  "adalah",
  "ini",
  "itu",
  "atau",
  "jika",
  "karena",
  "akan",
  "dapat",
  "bisa",
  "dalam",
  "sebagai",
  "tidak",
  "belum",
  "sudah",
  "telah",
  "lebih",
  "sangat",
  "secara",
  "bagaimana",
  "mengapa",
  "ketika",
  "saat",
  "jantung",
  "tubuh",
  "peluru",
  "gempa",
  "laut",
  "otak",
  "mobil",
  "teknologi",
  "energi",
  "adegan",
  "manusia",
  "jaringan",
  "darah",
  "bumi",
  "cepat",
  "berdetak",
  "mulai",
  "dampak",
]);

const ENGLISH_MARKERS = new Set([
  "the",
  "and",
  "of",
  "to",
  "in",
  "is",
  "are",
  "was",
  "were",
  "for",
  "with",
  "on",
  "at",
  "by",
  "from",
  "as",
  "that",
  "this",
  "these",
  "those",
  "it",
  "its",
  "or",
  "if",
  "because",
  "will",
  "can",
  "could",
  "when",
  "while",
  "how",
  "why",
  "what",
  "begins",
  "faster",
  "heart",
  "human",
  "body",
  "bullet",
  "planet",
  "earthquake",
  "ocean",
  "brain",
  "energy",
  "technology",
  "blood",
  "system",
  "into",
  "through",
  "across",
]);

export function scoreLanguageTokens(text: string): { idScore: number; enScore: number } {
  const words = text
    .toLowerCase()
    .replace(/[^a-z\u00c0-\u024f\s'-]/g, " ")
    .split(/\s+/)
    .filter(Boolean);

  let idScore = 0;
  let enScore = 0;

  for (const w of words) {
    if (INDONESIAN_MARKERS.has(w)) idScore += 2;
    if (ENGLISH_MARKERS.has(w)) enScore += 2;

    // Morphological signals
    if (/^(me|ber|ter|pe|ke)[a-z]{3,}$/.test(w) || /(nya|kan|lah)$/.test(w)) {
      idScore += 0.7;
    }
    if (/(ing|tion|sion|ment|ness|ed|ly)$/.test(w) && !INDONESIAN_MARKERS.has(w)) {
      enScore += 0.7;
    }
  }

  return { idScore, enScore };
}

export function detectSentenceLanguage(
  sentence: string,
  fallbackLang: "id-ID" | "en-US" = "id-ID"
): "id-ID" | "en-US" {
  const { idScore, enScore } = scoreLanguageTokens(sentence);
  if (enScore > idScore + 0.5) return "en-US";
  if (idScore > enScore + 0.5) return "id-ID";
  return fallbackLang;
}

export function detectTextLanguage(
  text: string,
  preference: LanguagePreference = "auto"
): SupportedLanguage {
  if (preference === "id-ID") return "id-ID";
  if (preference === "en-US") return "en-US";

  const sentences = splitIntoSentences(text);
  if (sentences.length > 1) {
    let idSentences = 0;
    let enSentences = 0;
    for (const s of sentences) {
      const { idScore, enScore } = scoreLanguageTokens(s);
      if (enScore > idScore + 0.8) enSentences += 1;
      else if (idScore > enScore + 0.8) idSentences += 1;
    }
    if (idSentences > 0 && enSentences > 0) {
      return "mixed";
    }
  }

  const { idScore, enScore } = scoreLanguageTokens(text);
  if (idScore > 2 && enScore > 2 && Math.abs(idScore - enScore) <= Math.min(idScore, enScore) * 0.65) {
    return "mixed";
  }
  return enScore > idScore ? "en-US" : "id-ID";
}

export function splitIntoSentences(text: string): string[] {
  const cleaned = text.trim();
  if (!cleaned) return [];
  const raw = cleaned
    .split(/(?<=[.!?])\s+|\n+/)
    .map((s) => s.trim())
    .filter(Boolean);
  return raw.length > 0 ? raw : [cleaned];
}

export function defaultEnvironmentalEffectForAsset(
  assetKey: VisualAssetKey
): EnvironmentalEffectType {
  switch (assetKey) {
    case "heart_organ":
    case "human_anatomy":
      return "blood_flow";
    case "solar_planet":
      return "starfield_drift";
    case "earthquake_seismic":
      return "seismic_tremor";
    case "tech_circuit":
    case "server_cyber":
    case "data_network":
    case "brain_organ":
      return "data_streams";
    case "ocean_marine":
      return "ocean_bubbles";
    case "energy_solar":
    case "money_economy":
      return "energy_sparks";
    case "projectile_bullet":
    case "vehicle_car":
      return "shockwave_rings";
    default:
      return "ambient_dust";
  }
}

export function buildNarrationSegments(
  narration: string,
  sceneDuration: number,
  spec: Pick<
    SceneVisualSpec,
    "assetKey" | "cameraMovement" | "animationType" | "subject" | "action" | "focusRegion"
  >,
  preference: LanguagePreference = "auto"
): NarrationSegment[] {
  const sentences = splitIntoSentences(narration);
  const safeDuration = Math.max(1.2, sceneDuration || 4.5);
  if (sentences.length === 0) {
    const lang = preference === "en-US" ? "en-US" : "id-ID";
    return [
      {
        text: "",
        language: lang,
        startTime: 0,
        endTime: Number(safeDuration.toFixed(2)),
        visualEvent: spec.action || spec.subject,
        cameraEvent: spec.cameraMovement,
        animationTrigger: "enter",
        intensityBoost: 1,
      },
    ];
  }

  const totalWords = sentences.reduce(
    (sum, s) => sum + Math.max(1, s.split(/\s+/).length),
    0
  );
  const fallbackLang: "id-ID" | "en-US" =
    preference === "en-US"
      ? "en-US"
      : preference === "id-ID"
      ? "id-ID"
      : detectTextLanguage(narration, "auto") === "en-US"
      ? "en-US"
      : "id-ID";

  let cursor = 0;
  return sentences.map((sentence, idx) => {
    const wordCount = Math.max(1, sentence.split(/\s+/).length);
    const share = (wordCount / Math.max(1, totalWords)) * safeDuration;
    const startTime = Number(cursor.toFixed(2));
    const endTime =
      idx === sentences.length - 1
        ? Number(safeDuration.toFixed(2))
        : Number(Math.min(safeDuration, cursor + share).toFixed(2));
    cursor = endTime;

    const lang =
      preference === "auto"
        ? detectSentenceLanguage(sentence, fallbackLang)
        : preference;
    const lower = sentence.toLowerCase();

    let animationTrigger: NarrationAnimationTrigger =
      idx === 0 ? "enter" : idx === sentences.length - 1 ? "resolve" : "highlight";
    let cameraEvent: VisualCameraMovement = spec.cameraMovement;
    let intensityBoost = 1;
    let visualEvent = spec.action || spec.subject;

    if (
      /\b(faster|accelerate|speed|rapid|surge|spike|lebih cepat|melesat|lonjakan|meningkat|memicu|drastis|kencang|detak|beating)\b/i.test(
        lower
      )
    ) {
      animationTrigger = "accelerate";
      cameraEvent = spec.cameraMovement === "static" ? "dolly_in" : spec.cameraMovement;
      intensityBoost = 1.45;
      visualEvent =
        lang === "en-US"
          ? `Accelerate ${spec.subject} motion & pulse`
          : `Percepatan gerak & intensitas ${spec.subject}`;
    } else if (
      /\b(orbit|rotate|spin|revolve|circle|mengorbit|berputar|mengelilingi|rotasi)\b/i.test(
        lower
      )
    ) {
      animationTrigger = "orbit";
      cameraEvent = "orbit";
      intensityBoost = 1.25;
      visualEvent =
        lang === "en-US"
          ? `Orbital rotation around ${spec.focusRegion || spec.subject}`
          : `Gerak orbit mengitari ${spec.focusRegion || spec.subject}`;
    } else if (
      /\b(focus|inside|organ|detail|zoom|penetrate|heart|brain|chip|fokus|dalam|organ|menembus|pusat|inti|rincian)\b/i.test(
        lower
      )
    ) {
      animationTrigger = "highlight";
      cameraEvent = "dolly_in";
      intensityBoost = 1.3;
      visualEvent =
        lang === "en-US"
          ? `Close-in focus on ${spec.focusRegion || spec.subject}`
          : `Sorot dekat pada ${spec.focusRegion || spec.subject}`;
    } else if (
      /\b(pulse|beat|wave|shake|flow|aliran|gelombang|bergetar|denyut|sinyal|arus)\b/i.test(
        lower
      )
    ) {
      animationTrigger = "pulse";
      cameraEvent = spec.cameraMovement === "static" ? "tilt_focus" : spec.cameraMovement;
      intensityBoost = 1.3;
    }

    return {
      text: sentence,
      language: lang,
      startTime,
      endTime,
      visualEvent,
      cameraEvent,
      animationTrigger,
      intensityBoost,
    };
  });
}

const DEFAULT_CINEMATIC_TRANSITIONS: SceneTransition[] = [
  "morph",
  "depth",
  "slide",
  "zoom",
  "whip",
  "fade",
];

export function runBlueprintQualityControl(blueprint: VideoBlueprint): VideoBlueprint {
  const pref: LanguagePreference = blueprint.languagePreference || "auto";
  let hasId = false;
  let hasEn = false;

  const normalizedScenes: VideoScene[] = (blueprint.scenes || []).map((scene, idx) => {
    const fallbackSpec: SceneVisualSpec = scene.sceneVisualSpec || {
      assetKey: "concept_diagram",
      subject: scene.topTitle || blueprint.title,
      action: "Memetakan konsep visual dinamis",
      environment: "Panggung explainer sinematik",
      objects: [scene.topSubLabel || "Elemen Utama", "Objek Pendukung", "Penanda Fokus"],
      visualDescription: `Visual dinamis untuk ${scene.topTitle}`,
      cameraMovement: "dolly_in",
      animationType: "scan_highlight",
      focusRegion: scene.topHighlightWord || scene.topTitle,
    };

    const envEffect =
      fallbackSpec.environmentalEffect ||
      defaultEnvironmentalEffectForAsset(fallbackSpec.assetKey);

    const enhancedSpec: SceneVisualSpec = {
      ...fallbackSpec,
      objects:
        Array.isArray(fallbackSpec.objects) && fallbackSpec.objects.length >= 2
          ? fallbackSpec.objects
          : [
              fallbackSpec.subject,
              fallbackSpec.focusRegion || "Lapisan Pendukung",
              "Partikel Atmosfer",
            ],
      objectMovement:
        fallbackSpec.objectMovement || fallbackSpec.action || "Gerak kontinu berirama",
      secondaryAnimation:
        fallbackSpec.secondaryAnimation ||
        "Partikel atmosfer, bayangan dinamis, dan elemen pendukung bergerak paralel",
      environmentalEffect: envEffect,
      animationIntensity: fallbackSpec.animationIntensity || "cinematic",
      motionTiming: fallbackSpec.motionTiming || "spring",
      narrationSyncCue:
        fallbackSpec.narrationSyncCue || "Sinkron bertahap mengikuti penekanan tiap kalimat",
    };

    const segments = buildNarrationSegments(
      scene.narration || "",
      scene.durationSeconds,
      enhancedSpec,
      pref
    );

    const sceneLang: SupportedLanguage =
      pref !== "auto"
        ? pref
        : segments.some((s) => s.language === "id-ID") &&
          segments.some((s) => s.language === "en-US")
        ? "mixed"
        : segments[0]?.language || detectTextLanguage(scene.narration || "", "auto");

    if (sceneLang === "id-ID") hasId = true;
    else if (sceneLang === "en-US") hasEn = true;
    else {
      hasId = true;
      hasEn = true;
    }

    const transition: SceneTransition =
      scene.transition && scene.transition !== "none"
        ? scene.transition
        : idx === 0
        ? "depth"
        : DEFAULT_CINEMATIC_TRANSITIONS[idx % DEFAULT_CINEMATIC_TRANSITIONS.length];

    return {
      ...scene,
      language: sceneLang,
      transition,
      sceneVisualSpec: enhancedSpec,
      narrationSegments: segments,
    };
  });

  const detectedLanguage: SupportedLanguage =
    pref !== "auto"
      ? pref
      : hasId && hasEn
      ? "mixed"
      : hasEn
      ? "en-US"
      : "id-ID";

  return {
    ...blueprint,
    languagePreference: pref,
    detectedLanguage,
    scenes: normalizedScenes,
  };
}
