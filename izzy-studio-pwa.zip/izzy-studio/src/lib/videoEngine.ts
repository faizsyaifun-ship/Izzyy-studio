import type {
  AspectRatio,
  NarrationSegment,
  VideoBlueprint,
  VideoScene,
  VideoStyleId,
} from "../types/video";
import { buildNarrationSegments } from "./languageSync";
import {
  applyCameraTransform,
  drawSemanticVisualScene,
  resolveSceneVisualSpec,
} from "./visualAssets";

export interface RenderDimensions {
  width: number;
  height: number;
}

export function getCanvasDimensions(aspectRatio: AspectRatio): RenderDimensions {
  switch (aspectRatio) {
    case "16:9":
      return { width: 1920, height: 1080 };
    case "1:1":
      return { width: 1080, height: 1080 };
    case "9:16":
    default:
      return { width: 1080, height: 1920 };
  }
}

interface StyleTheme {
  isDark: boolean;
  bg: string;
  bgSecondary: string;
  gridColor: string;
  ink: string;
  inkMuted: string;
  accent: string;
  accentText: string;
  accentSoft: string;
  success: string;
  warning: string;
  danger: string;
  cardBg: string;
  cardBorder: string;
  deskTop: string;
  deskFront: string;
  deskDrawer: string;
  rugColor: string;
  subtitleBg: string;
  subtitleText: string;
  subtitleActive: string;
}

function getTheme(style: VideoStyleId): StyleTheme {
  switch (style) {
    case "tech-blueprint":
      return {
        isDark: true,
        bg: "#0B1120",
        bgSecondary: "#111A2E",
        gridColor: "rgba(59, 130, 246, 0.12)",
        ink: "#F8FAFC",
        inkMuted: "#94A3B8",
        accent: "#3B82F6",
        accentText: "#FFFFFF",
        accentSoft: "rgba(59, 130, 246, 0.2)",
        success: "#10B981",
        warning: "#F59E0B",
        danger: "#EF4444",
        cardBg: "#152036",
        cardBorder: "rgba(148, 163, 184, 0.25)",
        deskTop: "#334155",
        deskFront: "#1E293B",
        deskDrawer: "#273549",
        rugColor: "rgba(59, 130, 246, 0.12)",
        subtitleBg: "rgba(15, 23, 42, 0.92)",
        subtitleText: "#E2E8F0",
        subtitleActive: "#60A5FA",
      };
    case "kinetic-cards":
      return {
        isDark: false,
        bg: "#FAFAFA",
        bgSecondary: "#F1F5F9",
        gridColor: "rgba(15, 23, 42, 0.04)",
        ink: "#0F172A",
        inkMuted: "#475569",
        accent: "#1D4ED8",
        accentText: "#FFFFFF",
        accentSoft: "rgba(29, 78, 216, 0.12)",
        success: "#16A34A",
        warning: "#D97706",
        danger: "#DC2626",
        cardBg: "#FFFFFF",
        cardBorder: "rgba(15, 23, 42, 0.12)",
        deskTop: "#E2E8F0",
        deskFront: "#CBD5E1",
        deskDrawer: "#94A3B8",
        rugColor: "rgba(29, 78, 216, 0.08)",
        subtitleBg: "rgba(15, 23, 42, 0.92)",
        subtitleText: "#F8FAFC",
        subtitleActive: "#FBBF24",
      };
    case "newsroom-brief":
      return {
        isDark: false,
        bg: "#F1F5F9",
        bgSecondary: "#E2E8F0",
        gridColor: "rgba(15, 23, 42, 0.05)",
        ink: "#0F172A",
        inkMuted: "#475569",
        accent: "#DC2626",
        accentText: "#FFFFFF",
        accentSoft: "rgba(220, 38, 38, 0.14)",
        success: "#15803D",
        warning: "#D97706",
        danger: "#B91C1C",
        cardBg: "#FFFFFF",
        cardBorder: "rgba(15, 23, 42, 0.14)",
        deskTop: "#B08968",
        deskFront: "#8B684C",
        deskDrawer: "#9C7759",
        rugColor: "rgba(15, 23, 42, 0.08)",
        subtitleBg: "rgba(15, 23, 42, 0.94)",
        subtitleText: "#FFFFFF",
        subtitleActive: "#F87171",
      };
    case "audio-pulse":
      return {
        isDark: true,
        bg: "#09090B",
        bgSecondary: "#18181B",
        gridColor: "rgba(16, 185, 129, 0.08)",
        ink: "#FAFAFA",
        inkMuted: "#A1A1AA",
        accent: "#10B981",
        accentText: "#052E16",
        accentSoft: "rgba(16, 185, 129, 0.2)",
        success: "#34D399",
        warning: "#FBBF24",
        danger: "#F87171",
        cardBg: "#18181B",
        cardBorder: "rgba(255, 255, 255, 0.14)",
        deskTop: "#27272A",
        deskFront: "#18181B",
        deskDrawer: "#3F3F46",
        rugColor: "rgba(16, 185, 129, 0.1)",
        subtitleBg: "rgba(24, 24, 27, 0.94)",
        subtitleText: "#F4F4F5",
        subtitleActive: "#34D399",
      };
    case "creator-showcase":
      return {
        isDark: false,
        bg: "#F4F5FA",
        bgSecondary: "#E8EAF3",
        gridColor: "rgba(15, 15, 25, 0.025)",
        ink: "#171720",
        inkMuted: "#777887",
        accent: "#7C3AED",
        accentText: "#FFFFFF",
        accentSoft: "rgba(124, 58, 237, 0.14)",
        success: "#22C55E",
        warning: "#F59E0B",
        danger: "#EF4444",
        cardBg: "#FFFFFF",
        cardBorder: "rgba(30, 30, 50, 0.10)",
        deskTop: "#DDD9E8",
        deskFront: "#C8C2D8",
        deskDrawer: "#B8B1CC",
        rugColor: "rgba(124, 58, 237, 0.08)",
        subtitleBg: "rgba(18, 18, 24, 0.90)",
        subtitleText: "#FFFFFF",
        subtitleActive: "#C4A7FF",
      };
    case "editorial-desk":
    default:
      return {
        isDark: false,
        bg: "#F4EFE6",
        bgSecondary: "#EAE2D3",
        gridColor: "rgba(30, 41, 59, 0.04)",
        ink: "#1E293B",
        inkMuted: "#64748B",
        accent: "#F59E0B",
        accentText: "#111827",
        accentSoft: "rgba(245, 158, 11, 0.22)",
        success: "#16A34A",
        warning: "#D97706",
        danger: "#DC2626",
        cardBg: "#FFFFFF",
        cardBorder: "rgba(30, 41, 59, 0.15)",
        deskTop: "#D2A273",
        deskFront: "#B58457",
        deskDrawer: "#C49365",
        rugColor: "rgba(148, 163, 184, 0.35)",
        subtitleBg: "rgba(24, 24, 27, 0.88)",
        subtitleText: "#FFFFFF",
        subtitleActive: "#FBBF24",
      };
  }
}

function easeOutCubic(x: number): number {
  const c = Math.max(0, Math.min(1, x));
  return 1 - Math.pow(1 - c, 3);
}

function easeOutBack(x: number): number {
  const c = Math.max(0, Math.min(1, x));
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(c - 1, 3) + c1 * Math.pow(c - 1, 2);
}

function roundRectPath(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

function drawGridBackground(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  theme: StyleTheme,
  style: VideoStyleId,
  time: number
) {
  ctx.fillStyle = theme.bg;
  ctx.fillRect(0, 0, w, h);

  // Subtle ambient radial wash
  const grad = ctx.createRadialGradient(
    w * 0.5,
    h * 0.45,
    w * 0.05,
    w * 0.5,
    h * 0.5,
    Math.max(w, h) * 0.75
  );
  grad.addColorStop(0, theme.isDark ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.45)");
  grad.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Editorial floor/wall split for editorial-desk & newsroom-brief
  if (style === "editorial-desk" || style === "newsroom-brief") {
    ctx.fillStyle = theme.bgSecondary;
    ctx.fillRect(0, h * 0.58, w, h * 0.42);
  }

  // Subtle technical grid
  const step = style === "tech-blueprint" ? 64 : 84;
  ctx.strokeStyle = theme.gridColor;
  ctx.lineWidth = 1;
  ctx.beginPath();
  for (let x = 0; x < w; x += step) {
    ctx.moveTo(x, 0);
    ctx.lineTo(x, h);
  }
  for (let y = 0; y < h; y += step) {
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
  }
  ctx.stroke();

  if (style === "tech-blueprint") {
    // Subtle moving scanline
    const scanY = ((time * 90) % (h + 200)) - 100;
    const scanGrad = ctx.createLinearGradient(0, scanY - 60, 0, scanY + 60);
    scanGrad.addColorStop(0, "rgba(59,130,246,0)");
    scanGrad.addColorStop(0.5, "rgba(59,130,246,0.08)");
    scanGrad.addColorStop(1, "rgba(59,130,246,0)");
    ctx.fillStyle = scanGrad;
    ctx.fillRect(0, scanY - 60, w, 120);
  }
}

function drawTopHeadline(
  ctx: CanvasRenderingContext2D,
  scene: VideoScene,
  theme: StyleTheme,
  w: number,
  h: number,
  sceneElapsed: number,
  isWide: boolean
) {
  const padX = isWide ? w * 0.06 : w * 0.075;
  const topY = isWide ? h * 0.08 : h * 0.065;
  const scale = isWide ? 0.85 : 1;
  const anim = easeOutCubic(sceneElapsed / 0.45);

  ctx.save();
  ctx.globalAlpha = anim;
  ctx.translate(0, (1 - anim) * 18);

  // Title with optional highlighted word
  const titleFontSize = Math.round((isWide ? 48 : 54) * scale);
  ctx.font = `800 ${titleFontSize}px "Plus Jakarta Sans", sans-serif`;
  ctx.textBaseline = "middle";
  ctx.textAlign = "left";

  const fullTitle = scene.topTitle || "";
  const hl = (scene.topHighlightWord || "").trim();
  const hlIndex = hl
    ? fullTitle.toLowerCase().indexOf(hl.toLowerCase())
    : -1;

  let curX = padX;
  let curY = topY + titleFontSize * 0.55;
  const maxWidth = w - padX * 2;

  if (hlIndex >= 0) {
    const before = fullTitle.slice(0, hlIndex);
    const match = fullTitle.slice(hlIndex, hlIndex + hl.length);
    const after = fullTitle.slice(hlIndex + hl.length);

    if (before) {
      ctx.fillStyle = theme.ink;
      ctx.fillText(before, curX, curY);
      curX += ctx.measureText(before).width;
    }

    const matchW = ctx.measureText(match).width;
    const boxPadX = 16;
    const boxH = titleFontSize * 1.18;

    if (curX + matchW + boxPadX * 2 > padX + maxWidth) {
      curX = padX;
      curY += titleFontSize * 1.32;
    }

    const popScale = easeOutBack(Math.min(1, sceneElapsed / 0.5));
    ctx.save();
    ctx.translate(curX + (matchW + boxPadX * 2) / 2, curY);
    ctx.scale(popScale, popScale);
    ctx.fillStyle = theme.accent;
    roundRectPath(
      ctx,
      -(matchW + boxPadX * 2) / 2,
      -boxH / 2,
      matchW + boxPadX * 2,
      boxH,
      14
    );
    ctx.fill();
    ctx.restore();

    ctx.fillStyle = theme.accentText;
    ctx.fillText(match, curX + boxPadX, curY + 2);
    curX += matchW + boxPadX * 2 + 8;

    if (after) {
      ctx.fillStyle = theme.ink;
      ctx.fillText(after, curX, curY);
    }
  } else {
    ctx.fillStyle = theme.ink;
    ctx.fillText(fullTitle, curX, curY, maxWidth);
  }

  // Sub-label underneath headline
  if (scene.topSubLabel) {
    ctx.font = `700 ${Math.round(24 * scale)}px "JetBrains Mono", monospace`;
    ctx.fillStyle = theme.inkMuted;
    ctx.fillText(scene.topSubLabel.toUpperCase(), padX, curY + titleFontSize * 0.92);
  }

  ctx.restore();
  return curY + titleFontSize * 1.45;
}

function drawComparisonTable(
  ctx: CanvasRenderingContext2D,
  blueprint: VideoBlueprint,
  sceneIndex: number,
  sceneElapsed: number,
  theme: StyleTheme,
  x: number,
  y: number,
  tableW: number
): number {
  const rows: {
    taskLabel: string;
    aiAction: string;
    evidenceText: string;
    status: string;
    isNewest: boolean;
  }[] = [];

  for (let i = 0; i <= sceneIndex; i++) {
    const tr = blueprint.scenes[i]?.tableRow;
    if (tr) {
      rows.push({
        ...tr,
        isNewest: i === sceneIndex,
      });
    }
  }

  if (rows.length === 0) return y;

  const headerH = 52;
  const rowH = 62;
  const totalH = headerH + rows.length * rowH + 14;

  ctx.save();
  // Card container
  ctx.fillStyle = theme.cardBg;
  ctx.strokeStyle = theme.cardBorder;
  ctx.lineWidth = 2;
  roundRectPath(ctx, x, y, tableW, totalH, 18);
  ctx.fill();
  ctx.stroke();

  const col1X = x + 26;
  const col2X = x + tableW * 0.34;
  const col3X = x + tableW * 0.66;

  // Header row
  ctx.font = `700 22px "Plus Jakarta Sans", sans-serif`;
  ctx.fillStyle = theme.inkMuted;
  ctx.textBaseline = "middle";
  ctx.textAlign = "left";
  const [c1, c2, c3] = blueprint.tableColumns;
  ctx.fillText(c1, col1X, y + headerH / 2);
  ctx.fillText(c2, col2X, y + headerH / 2);
  ctx.fillText(c3, col3X, y + headerH / 2);

  // Divider
  ctx.strokeStyle = theme.cardBorder;
  ctx.beginPath();
  ctx.moveTo(x + 16, y + headerH);
  ctx.lineTo(x + tableW - 16, y + headerH);
  ctx.stroke();

  // Rows
  rows.forEach((row, idx) => {
    const ry = y + headerH + idx * rowH;
    const rowAnim = row.isNewest ? easeOutCubic(sceneElapsed / 0.5) : 1;

    ctx.save();
    ctx.globalAlpha = rowAnim;

    if (idx > 0) {
      ctx.strokeStyle = theme.cardBorder;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(x + 20, ry);
      ctx.lineTo(x + tableW - 20, ry);
      ctx.stroke();
    }

    ctx.font = `600 23px "DM Sans", sans-serif`;
    ctx.fillStyle = theme.ink;
    ctx.fillText(row.taskLabel, col1X, ry + rowH / 2, tableW * 0.28);

    // Highlighted cell for action
    const actionW = Math.min(tableW * 0.29, ctx.measureText(row.aiAction).width + 24);
    ctx.fillStyle = theme.accentSoft;
    roundRectPath(ctx, col2X - 8, ry + 11, actionW, rowH - 22, 10);
    ctx.fill();

    ctx.fillStyle = theme.ink;
    ctx.font = `700 21px "DM Sans", sans-serif`;
    ctx.fillText(row.aiAction, col2X + 4, ry + rowH / 2, tableW * 0.27);

    // Evidence badge
    const evColor =
      row.status === "warning"
        ? theme.warning
        : row.status === "pending"
        ? theme.inkMuted
        : theme.success;

    const evW = Math.min(tableW * 0.31, ctx.measureText(row.evidenceText).width + 26);
    ctx.fillStyle = evColor;
    roundRectPath(ctx, col3X - 6, ry + 11, evW, rowH - 22, 10);
    ctx.fill();

    ctx.fillStyle = "#FFFFFF";
    ctx.font = `700 20px "JetBrains Mono", monospace`;
    ctx.fillText(row.evidenceText, col3X + 7, ry + rowH / 2, tableW * 0.28);

    ctx.restore();
  });

  ctx.restore();
  return y + totalH + 24;
}

function drawExecutiveDesk(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  scale: number,
  theme: StyleTheme,
  nameplate: string,
  time: number,
  sceneElapsed: number,
  options: { showChair?: boolean; showScales?: boolean; showQuestion?: boolean; showDocs?: boolean }
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);

  // Floor rug
  ctx.fillStyle = theme.rugColor;
  roundRectPath(ctx, -430, 120, 860, 220, 12);
  ctx.fill();

  // Window in background right
  ctx.fillStyle = theme.isDark ? "#1E293B" : "#E0F2FE";
  ctx.strokeStyle = theme.isDark ? "#475569" : "#CBD5E1";
  ctx.lineWidth = 8;
  roundRectPath(ctx, 210, -290, 210, 250, 6);
  ctx.fill();
  ctx.stroke();

  // Window grid
  ctx.beginPath();
  ctx.moveTo(315, -290);
  ctx.lineTo(315, -40);
  ctx.moveTo(210, -165);
  ctx.lineTo(420, -165);
  ctx.stroke();

  // Office Chair behind desk
  if (options.showChair !== false) {
    const chairSlide = easeOutCubic(Math.min(1, sceneElapsed / 0.6));
    ctx.save();
    ctx.translate(0, (1 - chairSlide) * 16);

    // Chair wheels & stem
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 10;
    ctx.beginPath();
    ctx.moveTo(0, 130);
    ctx.lineTo(0, 210);
    ctx.moveTo(-75, 225);
    ctx.lineTo(75, 225);
    ctx.stroke();

    // Chair backrest
    ctx.fillStyle = "#1E293B";
    roundRectPath(ctx, -95, -190, 190, 220, 24);
    ctx.fill();
    ctx.strokeStyle = "#334155";
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.restore();
  }

  // Desk top
  ctx.fillStyle = theme.deskTop;
  roundRectPath(ctx, -400, -10, 800, 48, 8);
  ctx.fill();

  // Desk front body
  ctx.fillStyle = theme.deskFront;
  roundRectPath(ctx, -380, 38, 760, 175, 4);
  ctx.fill();

  // Desk drawers right side
  ctx.fillStyle = theme.deskDrawer;
  roundRectPath(ctx, 210, 52, 150, 64, 4);
  ctx.fill();
  roundRectPath(ctx, 210, 128, 150, 64, 4);
  ctx.fill();
  ctx.fillStyle = "#1E293B";
  ctx.fillRect(272, 78, 26, 8);
  ctx.fillRect(272, 154, 26, 8);

  // Monitor stand + screen
  ctx.fillStyle = "#334155";
  ctx.fillRect(-195, -52, 24, 42);
  ctx.fillRect(-230, -16, 94, 10);

  ctx.fillStyle = "#0F172A";
  ctx.strokeStyle = "#475569";
  ctx.lineWidth = 6;
  roundRectPath(ctx, -310, -210, 255, 165, 12);
  ctx.fill();
  ctx.stroke();

  // Monitor animated chart bars + radar dial
  const barCount = 10;
  for (let i = 0; i < barCount; i++) {
    const barH = 18 + Math.abs(Math.sin(time * 2.5 + i * 0.7)) * 42;
    ctx.fillStyle = i % 3 === 0 ? theme.accent : "#60A5FA";
    roundRectPath(ctx, -288 + i * 21, -68 - barH, 13, barH, 3);
    ctx.fill();
  }
  // Mini radar dial on monitor
  ctx.strokeStyle = "#38BDF8";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.arc(-255, -165, 22, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(-255, -165);
  ctx.lineTo(
    -255 + Math.cos(time * 2.2) * 18,
    -165 + Math.sin(time * 2.2) * 18
  );
  ctx.stroke();

  // Nameplate in center of desk
  ctx.fillStyle = "#0F172A";
  roundRectPath(ctx, -110, -44, 220, 42, 6);
  ctx.fill();
  ctx.strokeStyle = "#94A3B8";
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = "#F8FAFC";
  ctx.font = `800 18px "Plus Jakarta Sans", sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(nameplate, 0, -23, 200);

  // Miniature flag right of desk
  ctx.strokeStyle = "#475569";
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.moveTo(310, -10);
  ctx.lineTo(310, -155);
  ctx.stroke();
  ctx.fillStyle = "#DC2626";
  ctx.fillRect(312, -152, 64, 22);
  ctx.fillStyle = "#FFFFFF";
  ctx.fillRect(312, -130, 64, 22);

  // Optional audit documents floating onto desk
  if (options.showDocs) {
    const docsProgress = easeOutBack(Math.min(1, sceneElapsed / 0.8));
    for (let d = 0; d < 3; d++) {
      const dx = -90 + d * 82;
      const dy = -130 - d * 12 + (1 - docsProgress) * -90;
      ctx.save();
      ctx.translate(dx, dy);
      ctx.rotate((d - 1) * 0.08);
      ctx.fillStyle = "#FFFFFF";
      ctx.strokeStyle = "#CBD5E1";
      ctx.lineWidth = 2;
      roundRectPath(ctx, -38, -50, 76, 100, 6);
      ctx.fill();
      ctx.stroke();

      // Lines & checkmark
      ctx.fillStyle = "#94A3B8";
      ctx.fillRect(-24, -30, 48, 6);
      ctx.fillRect(-24, -14, 38, 6);
      ctx.fillRect(-24, 2, 44, 6);

      ctx.fillStyle = theme.success;
      ctx.beginPath();
      ctx.arc(0, 28, 12, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  // Optional golden balance scale
  if (options.showScales) {
    const tilt = Math.sin(time * 2.2) * 0.14;
    ctx.save();
    ctx.translate(210, -10);

    // Base & pole
    ctx.fillStyle = "#D97706";
    roundRectPath(ctx, -45, -16, 90, 16, 4);
    ctx.fill();
    ctx.fillRect(-6, -160, 12, 148);

    // Beam
    ctx.save();
    ctx.translate(0, -150);
    ctx.rotate(tilt);
    ctx.fillStyle = "#F59E0B";
    roundRectPath(ctx, -95, -5, 190, 10, 5);
    ctx.fill();

    // Left & right pans
    [-82, 82].forEach((px) => {
      ctx.strokeStyle = "#B45309";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(px, 4);
      ctx.lineTo(px - 22, 65);
      ctx.moveTo(px, 4);
      ctx.lineTo(px + 22, 65);
      ctx.stroke();

      ctx.fillStyle = "#FBBF24";
      ctx.beginPath();
      ctx.arc(px, 65, 28, 0, Math.PI);
      ctx.fill();
    });
    ctx.restore();
    ctx.restore();
  }

  // Optional pulsing question mark above monitor
  if (options.showQuestion) {
    const bob = Math.sin(time * 4) * 8;
    ctx.fillStyle = theme.accent;
    ctx.font = `800 84px "Plus Jakarta Sans", sans-serif`;
    ctx.textAlign = "center";
    ctx.fillText("?", -185, -245 + bob);
  }

  ctx.restore();
}

function drawMetricCounterScene(
  ctx: CanvasRenderingContext2D,
  scene: VideoScene,
  theme: StyleTheme,
  cx: number,
  cy: number,
  scale: number,
  time: number,
  sceneElapsed: number
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);

  const metric = scene.visualMetric || {
    prefix: "Rp ",
    targetValue: 359.8,
    decimals: 1,
    suffix: " T",
    unitLabel: "nilai terukur",
    sourceLabel: "Data Terverifikasi",
  };

  // Stylized smartphone / device on left
  const phonePop = easeOutBack(Math.min(1, sceneElapsed / 0.55));
  ctx.save();
  ctx.translate(-165, 0);
  ctx.scale(phonePop, phonePop);

  ctx.fillStyle = "#1E293B";
  roundRectPath(ctx, -110, -175, 220, 350, 28);
  ctx.fill();
  ctx.fillStyle = "#F8FAFC";
  roundRectPath(ctx, -94, -155, 188, 310, 18);
  ctx.fill();

  // 3x3 app icon grid
  const iconColors = [
    "#EF4444",
    "#F59E0B",
    "#10B981",
    "#3B82F6",
    "#6366F1",
    "#EC4899",
    "#14B8A6",
    "#F97316",
    "#8B5CF6",
  ];
  for (let r = 0; r < 3; r++) {
    for (let c = 0; c < 3; c++) {
      const idx = r * 3 + c;
      const pulse = 1 + Math.sin(time * 4 + idx) * 0.05;
      ctx.save();
      ctx.translate(-52 + c * 52, -92 + r * 58);
      ctx.scale(pulse, pulse);
      ctx.fillStyle = iconColors[idx];
      roundRectPath(ctx, -18, -18, 36, 36, 9);
      ctx.fill();
      ctx.restore();
    }
  }
  ctx.restore();

  // Animated particle/coin stream flowing from phone to counter card
  for (let i = 0; i < 8; i++) {
    const t = ((time * 1.4 + i * 0.125) % 1);
    const px = -55 + t * 145;
    const py = -40 + Math.sin(t * Math.PI) * -55 + (i % 2) * 14;
    ctx.fillStyle = theme.accent;
    ctx.beginPath();
    ctx.arc(px, py, 9, 0, Math.PI * 2);
    ctx.fill();
  }

  // Counter card on right
  const countProgress = easeOutCubic(Math.min(1, sceneElapsed / 2.2));
  const currentVal = metric.targetValue * countProgress;
  const formattedVal = currentVal.toLocaleString("id-ID", {
    minimumFractionDigits: metric.decimals,
    maximumFractionDigits: metric.decimals,
  });

  ctx.fillStyle = theme.cardBg;
  ctx.strokeStyle = theme.cardBorder;
  ctx.lineWidth = 3;
  roundRectPath(ctx, 45, -85, 330, 195, 20);
  ctx.fill();
  ctx.stroke();

  ctx.textAlign = "left";
  ctx.fillStyle = theme.inkMuted;
  ctx.font = `600 21px "DM Sans", sans-serif`;
  ctx.fillText(metric.unitLabel, 75, -42, 270);

  ctx.fillStyle = theme.danger;
  ctx.font = `700 52px "JetBrains Mono", monospace`;
  ctx.fillText(`${metric.prefix}${formattedVal}${metric.suffix}`, 75, 22, 280);

  // Source caption pill below
  ctx.fillStyle = theme.inkMuted;
  ctx.font = `600 19px "JetBrains Mono", monospace`;
  ctx.fillText(metric.sourceLabel, 75, 76, 270);

  ctx.restore();
}

function drawNetworkGraphScene(
  ctx: CanvasRenderingContext2D,
  scene: VideoScene,
  theme: StyleTheme,
  cx: number,
  cy: number,
  scale: number,
  time: number,
  sceneElapsed: number
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);

  const expand = easeOutCubic(Math.min(1, sceneElapsed / 1.1));
  const nodeCount = 24;
  const nodes: { x: number; y: number; r: number }[] = [];

  for (let i = 0; i < nodeCount; i++) {
    const angle = (i / nodeCount) * Math.PI * 2 + (i % 2) * 0.15;
    const dist = (130 + (i % 3) * 75) * expand;
    const wobble = Math.sin(time * 2 + i) * 6;
    nodes.push({
      x: Math.cos(angle) * (dist + wobble),
      y: Math.sin(angle) * (dist * 0.62 + wobble * 0.5),
      r: 10 + (i % 3) * 4,
    });
  }

  // Edges
  nodes.forEach((n, idx) => {
    ctx.strokeStyle =
      idx % 3 === 0 ? theme.danger : theme.isDark ? "#60A5FA" : "#1E293B";
    ctx.lineWidth = idx % 3 === 0 ? 3.5 : 2;
    ctx.globalAlpha = 0.65 * expand;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(n.x, n.y);
    ctx.stroke();

    // Cross-link neighbors
    const next = nodes[(idx + 1) % nodes.length];
    ctx.globalAlpha = 0.25 * expand;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(n.x, n.y);
    ctx.lineTo(next.x, next.y);
    ctx.stroke();
  });

  ctx.globalAlpha = 1;
  // Satellite nodes
  nodes.forEach((n, idx) => {
    ctx.fillStyle = idx % 4 === 0 ? theme.accent : "#3B82F6";
    ctx.beginPath();
    ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = theme.bg;
    ctx.lineWidth = 2;
    ctx.stroke();
  });

  // Central hub pulse
  const pulseR = 44 + ((time * 45) % 45);
  ctx.strokeStyle = theme.danger;
  ctx.globalAlpha = Math.max(0, 1 - (pulseR - 44) / 45);
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.arc(0, 0, pulseR, 0, Math.PI * 2);
  ctx.stroke();

  ctx.globalAlpha = 1;
  ctx.fillStyle = theme.danger;
  ctx.beginPath();
  ctx.arc(0, 0, 42, 0, Math.PI * 2);
  ctx.fill();

  // Metric overlay badge
  if (scene.visualMetric || scene.calloutBadge) {
    const label = scene.visualMetric
      ? scene.visualMetric.sourceLabel
      : scene.calloutBadge || "";
    ctx.fillStyle = theme.cardBg;
    ctx.strokeStyle = theme.cardBorder;
    ctx.lineWidth = 2;
    roundRectPath(ctx, -200, 185, 400, 56, 14);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = theme.ink;
    ctx.font = `700 23px "JetBrains Mono", monospace`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(label, 0, 213, 370);
  }

  ctx.restore();
}

function drawServerRadarScene(
  ctx: CanvasRenderingContext2D,
  scene: VideoScene,
  theme: StyleTheme,
  cx: number,
  cy: number,
  scale: number,
  time: number,
  sceneElapsed: number
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);

  // Sweeping radar cone behind server
  const sweepAngle = time * 1.9;
  ctx.save();
  ctx.translate(-120, 0);
  const coneGrad = ctx.createRadialGradient(0, 0, 10, 0, 0, 270);
  coneGrad.addColorStop(0, "rgba(59, 130, 246, 0.35)");
  coneGrad.addColorStop(1, "rgba(59, 130, 246, 0.0)");
  ctx.fillStyle = coneGrad;
  ctx.beginPath();
  ctx.moveTo(0, 0);
  ctx.arc(0, 0, 270, sweepAngle - 0.45, sweepAngle + 0.45);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // Main server rack
  const pop = easeOutCubic(Math.min(1, sceneElapsed / 0.5));
  ctx.save();
  ctx.translate(-150, (1 - pop) * 30);
  ctx.fillStyle = "#1E293B";
  roundRectPath(ctx, -105, -200, 210, 400, 16);
  ctx.fill();

  for (let slot = 0; slot < 7; slot++) {
    const sy = -170 + slot * 50;
    ctx.fillStyle = "#0F172A";
    roundRectPath(ctx, -84, sy, 168, 36, 6);
    ctx.fill();

    // Blinking server LEDs
    const active = Math.sin(time * 5 + slot * 1.3) > 0;
    ctx.fillStyle = active ? theme.success : theme.warning;
    ctx.beginPath();
    ctx.arc(-62, sy + 18, 5, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#334155";
    ctx.fillRect(-40, sy + 14, 105, 8);
  }
  ctx.restore();

  // 4 satellite client terminals on right
  const monitors = [
    { x: 110, y: -110 },
    { x: 245, y: -110 },
    { x: 110, y: 45 },
    { x: 245, y: 45 },
  ];
  monitors.forEach((m, idx) => {
    const isProtected = sceneElapsed > 1.6 + idx * 0.25;
    ctx.fillStyle = "#0F172A";
    ctx.strokeStyle = isProtected ? theme.success : theme.danger;
    ctx.lineWidth = 4;
    roundRectPath(ctx, m.x - 54, m.y - 44, 108, 84, 10);
    ctx.fill();
    ctx.stroke();

    // Stand
    ctx.fillStyle = "#475569";
    ctx.fillRect(m.x - 8, m.y + 40, 16, 16);
    ctx.fillRect(m.x - 24, m.y + 54, 48, 6);

    // Status glyph inside monitor
    ctx.fillStyle = isProtected ? theme.success : theme.danger;
    ctx.beginPath();
    ctx.arc(m.x, m.y - 2, 18, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#FFFFFF";
    ctx.font = `800 20px "Plus Jakarta Sans", sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(isProtected ? "✓" : "!", m.x, m.y - 1);
  });

  // Status badge
  if (scene.calloutBadge) {
    ctx.fillStyle = theme.cardBg;
    ctx.strokeStyle = theme.cardBorder;
    ctx.lineWidth = 2;
    roundRectPath(ctx, 35, 145, 280, 48, 12);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = theme.ink;
    ctx.font = `700 21px "JetBrains Mono", monospace`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(scene.calloutBadge.toUpperCase(), 175, 169);
  }

  ctx.restore();
}

function drawNewsMapScene(
  ctx: CanvasRenderingContext2D,
  scene: VideoScene,
  theme: StyleTheme,
  cx: number,
  cy: number,
  scale: number,
  time: number,
  sceneElapsed: number
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);

  const news = scene.newsCard || {
    tag: "BERITA · GLOBAL",
    headline: scene.topTitle,
    regionName: "Lokasi Utama",
    subDetail: scene.topSubLabel,
  };

  const slide = easeOutCubic(Math.min(1, sceneElapsed / 0.55));

  // Left news broadcast card
  ctx.save();
  ctx.translate(-165, (1 - slide) * 24);
  ctx.fillStyle = "#0F172A";
  ctx.strokeStyle = "#475569";
  ctx.lineWidth = 5;
  roundRectPath(ctx, -185, -140, 350, 260, 14);
  ctx.fill();
  ctx.stroke();

  // Breaking red banner
  ctx.fillStyle = theme.danger;
  roundRectPath(ctx, -162, -118, 304, 42, 6);
  ctx.fill();

  ctx.fillStyle = "#FFFFFF";
  ctx.font = `800 20px "JetBrains Mono", monospace`;
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText(news.tag.toUpperCase(), -146, -97, 272);

  // Headline
  ctx.fillStyle = "#F8FAFC";
  ctx.font = `800 32px "Plus Jakarta Sans", sans-serif`;
  ctx.fillText(news.headline, -160, -24, 290);

  if (news.subDetail) {
    ctx.fillStyle = "#94A3B8";
    ctx.font = `500 20px "DM Sans", sans-serif`;
    ctx.fillText(news.subDetail, -160, 28, 290);
  }

  // Concentric broadcast rings
  for (let r = 1; r <= 3; r++) {
    ctx.strokeStyle = "rgba(59, 130, 246, 0.45)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(90, 52, r * 16 + Math.sin(time * 3) * 3, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();

  // Right regional map card
  ctx.save();
  ctx.translate(185, (1 - slide) * -18);
  ctx.fillStyle = theme.cardBg;
  ctx.strokeStyle = theme.cardBorder;
  ctx.lineWidth = 3;
  roundRectPath(ctx, -150, -140, 300, 260, 14);
  ctx.fill();
  ctx.stroke();

  // Stylized landmass silhouette
  ctx.fillStyle = theme.isDark ? "#334155" : "#E2E8F0";
  ctx.beginPath();
  ctx.moveTo(-105, -80);
  ctx.lineTo(15, -105);
  ctx.lineTo(95, -45);
  ctx.lineTo(110, 50);
  ctx.lineTo(25, 95);
  ctx.lineTo(-90, 65);
  ctx.closePath();
  ctx.fill();

  // Highlighted country/region pin
  ctx.fillStyle = theme.danger;
  ctx.beginPath();
  ctx.arc(10, -5, 22, 0, Math.PI * 2);
  ctx.fill();

  const pingR = 22 + ((time * 32) % 34);
  ctx.strokeStyle = theme.danger;
  ctx.globalAlpha = Math.max(0, 1 - (pingR - 22) / 34);
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(10, -5, pingR, 0, Math.PI * 2);
  ctx.stroke();

  ctx.globalAlpha = 1;
  ctx.fillStyle = "#FFFFFF";
  ctx.strokeStyle = theme.cardBorder;
  ctx.lineWidth = 1.5;
  roundRectPath(ctx, -85, 36, 190, 40, 10);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = "#0F172A";
  ctx.font = `700 20px "Plus Jakarta Sans", sans-serif`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(news.regionName, 10, 56, 170);
  ctx.restore();

  ctx.restore();
}

function drawKineticStatementScene(
  ctx: CanvasRenderingContext2D,
  scene: VideoScene,
  theme: StyleTheme,
  cx: number,
  cy: number,
  scale: number,
  time: number,
  sceneElapsed: number,
  audioBins?: Uint8Array
) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);

  const cardPop = easeOutCubic(Math.min(1, sceneElapsed / 0.5));
  ctx.globalAlpha = cardPop;

  // Main kinetic showcase panel
  ctx.fillStyle = theme.cardBg;
  ctx.strokeStyle = theme.cardBorder;
  ctx.lineWidth = 2.5;
  roundRectPath(ctx, -360, -170, 720, 340, 22);
  ctx.fill();
  ctx.stroke();

  // Top accent rule
  ctx.fillStyle = theme.accent;
  roundRectPath(ctx, -320, -135, 110, 8, 4);
  ctx.fill();

  // Optional metric or headline inside card
  if (scene.visualMetric) {
    const p = easeOutCubic(Math.min(1, sceneElapsed / 1.8));
    const val = (scene.visualMetric.targetValue * p).toLocaleString("id-ID", {
      minimumFractionDigits: scene.visualMetric.decimals,
      maximumFractionDigits: scene.visualMetric.decimals,
    });
    ctx.fillStyle = theme.accent;
    ctx.font = `700 66px "JetBrains Mono", monospace`;
    ctx.textAlign = "left";
    ctx.fillText(
      `${scene.visualMetric.prefix}${val}${scene.visualMetric.suffix}`,
      -320,
      -52,
      640
    );
    ctx.fillStyle = theme.inkMuted;
    ctx.font = `600 24px "DM Sans", sans-serif`;
    ctx.fillText(scene.visualMetric.unitLabel, -320, 4, 640);
  } else {
    ctx.fillStyle = theme.ink;
    ctx.font = `800 42px "Plus Jakarta Sans", sans-serif`;
    ctx.textAlign = "left";
    ctx.fillText(scene.topTitle, -320, -64, 640);
  }

  // Bullets or animated audio bars
  const bullets = scene.bullets && scene.bullets.length > 0 ? scene.bullets : [];
  if (bullets.length > 0) {
    bullets.slice(0, 3).forEach((b, idx) => {
      const bAnim = easeOutCubic(Math.min(1, Math.max(0, (sceneElapsed - idx * 0.25) / 0.4)));
      ctx.save();
      ctx.globalAlpha = bAnim;
      const by = 48 + idx * 42;
      ctx.fillStyle = theme.accent;
      ctx.beginPath();
      ctx.arc(-310, by, 6, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = theme.ink;
      ctx.font = `600 24px "DM Sans", sans-serif`;
      ctx.fillText(b, -288, by + 2, 590);
      ctx.restore();
    });
  } else {
    // Clean spectrum bars inside card
    const bars = 28;
    for (let i = 0; i < bars; i++) {
      const bin = audioBins ? audioBins[i % audioBins.length] / 255 : 0;
      const amp = audioBins
        ? 14 + bin * 78
        : 18 + Math.abs(Math.sin(time * 4.5 + i * 0.45)) * 56;
      ctx.fillStyle = i % 4 === 0 ? theme.accent : theme.inkMuted;
      roundRectPath(ctx, -320 + i * 23, 128 - amp, 14, amp, 4);
      ctx.fill();
    }
  }

  ctx.restore();
}

function drawAudioPulseOverlay(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  theme: StyleTheme,
  time: number,
  audioBins?: Uint8Array
) {
  const barCount = 48;
  const barW = (w * 0.84) / barCount;
  const startX = w * 0.08;
  const baseY = h * 0.72;

  ctx.save();
  for (let i = 0; i < barCount; i++) {
    const val = audioBins ? audioBins[i % audioBins.length] / 255 : 0;
    const barH = audioBins
      ? 12 + val * 120
      : 16 + Math.abs(Math.sin(time * 5 + i * 0.35)) * 68;
    ctx.fillStyle = theme.accent;
    ctx.globalAlpha = 0.28 + (i % 3) * 0.14;
    roundRectPath(
      ctx,
      startX + i * barW,
      baseY - barH / 2,
      Math.max(4, barW * 0.62),
      barH,
      4
    );
    ctx.fill();
  }
  ctx.restore();
}

function drawSubtitles(
  ctx: CanvasRenderingContext2D,
  scene: VideoScene,
  theme: StyleTheme,
  w: number,
  h: number,
  sceneProgress: number,
  isWide: boolean
) {
  const words = (scene.narration || "").trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return;

  const activeWordIdx = Math.min(
    words.length - 1,
    Math.floor(sceneProgress * words.length)
  );

  // Group into chunks of ~6 words so captions stay crisp & readable
  const chunkSize = isWide ? 10 : 6;
  const chunkIndex = Math.floor(activeWordIdx / chunkSize);
  const chunkStart = chunkIndex * chunkSize;
  const chunkWords = words.slice(chunkStart, chunkStart + chunkSize);

  const fontSize = isWide ? 36 : 42;
  ctx.save();
  ctx.font = `700 ${fontSize}px "Plus Jakarta Sans", sans-serif`;

  // Measure lines (max 2 lines)
  const maxBoxW = w * 0.86;
  const spaceW = ctx.measureText(" ").width;
  const lines: { word: string; isActive: boolean; width: number }[][] = [[]];
  let currentLineW = 0;

  chunkWords.forEach((word, offset) => {
    const wordW = ctx.measureText(word).width;
    const isActive = chunkStart + offset === activeWordIdx;
    if (currentLineW + wordW > maxBoxW - 64 && lines[lines.length - 1].length > 0) {
      lines.push([]);
      currentLineW = 0;
    }
    lines[lines.length - 1].push({ word, isActive, width: wordW });
    currentLineW += wordW + spaceW;
  });

  const lineH = fontSize * 1.38;
  const padX = 36;
  const padY = 22;
  const boxH = lines.length * lineH + padY * 2;
  const widestLine = Math.max(
    ...lines.map((line) =>
      line.reduce((sum, item, i) => sum + item.width + (i > 0 ? spaceW : 0), 0)
    )
  );
  const boxW = Math.min(maxBoxW, widestLine + padX * 2);
  const boxX = (w - boxW) / 2;
  const boxY = h - (isWide ? 90 : 190) - boxH;

  // Rounded dark plate behind subtitle
  ctx.fillStyle = theme.subtitleBg;
  roundRectPath(ctx, boxX, boxY, boxW, boxH, 20);
  ctx.fill();

  ctx.textBaseline = "middle";
  ctx.textAlign = "left";

  lines.forEach((line, lIdx) => {
    const lineW = line.reduce(
      (sum, item, i) => sum + item.width + (i > 0 ? spaceW : 0),
      0
    );
    let wx = (w - lineW) / 2;
    const wy = boxY + padY + lineH * lIdx + lineH / 2;

    line.forEach((item) => {
      ctx.fillStyle = item.isActive ? theme.subtitleActive : theme.subtitleText;
      ctx.fillText(item.word, wx, wy);
      wx += item.width + spaceW;
    });
  });

  ctx.restore();
}

function drawCreatorShowcaseFrame(
  ctx: CanvasRenderingContext2D,
  blueprint: VideoBlueprint,
  scene: VideoScene,
  sceneIndex: number,
  sceneElapsed: number,
  sceneDuration: number,
  currentTime: number,
  w: number,
  h: number
) {
  const p = Math.min(1, sceneElapsed / Math.max(0.4, sceneDuration));
  const ease = 1 - Math.pow(1 - p, 3);
  const isOutro = blueprint.scenes.length > 1 && sceneIndex === blueprint.scenes.length - 1;
  const dark = sceneIndex === 0 || isOutro;
  const bg = dark ? "#09090D" : (sceneIndex % 2 ? "#F1F3FA" : "#FFFFFF");
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, w, h);
  const scale = w / 1080;
  ctx.save();
  ctx.scale(scale, scale);
  const H = h / scale;
  const t = currentTime * 1.15;
  const accent = "#7627E8";
  const white = "#FFFFFF";
  const ink = dark ? white : "#171720";
  const alpha = Math.min(1, p * 2.8);
  ctx.globalAlpha = alpha;

  // soft ambient color pools
  const glow = ctx.createRadialGradient(540, H * 0.48, 20, 540, H * 0.48, 520);
  glow.addColorStop(0, dark ? "rgba(81,35,180,.25)" : "rgba(124,58,237,.10)");
  glow.addColorStop(1, "rgba(124,58,237,0)");
  ctx.fillStyle = glow; ctx.fillRect(0, 0, 1080, H);

  // Social handle / micro brand at top
  ctx.fillStyle = ink; ctx.font = "700 18px Arial"; ctx.textAlign = "center";
  ctx.fillText("◎", 540, 78);
  ctx.font = "600 12px Arial"; ctx.fillStyle = dark ? "#B8B8C4" : "#777887";
  ctx.fillText((blueprint.brandHandle || "@CREATOR.STUDIO").toUpperCase(), 540, 101);

  if (isOutro) {
    const logoScale = 0.82 + 0.18 * ease;
    ctx.translate(540, H * 0.47); ctx.scale(logoScale, logoScale); ctx.translate(-540, -H * 0.47);
    ctx.font = "900 76px Arial"; ctx.textAlign = "center";
    ctx.shadowColor = accent; ctx.shadowBlur = 28;
    ctx.fillStyle = "#24212D"; ctx.fillText(blueprint.title || "CREATIVE STUDIO", 540, H * 0.49);
    ctx.shadowBlur = 0;
    ctx.fillStyle = accent; ctx.fillText(blueprint.title || "CREATIVE STUDIO", 536, H * 0.49);
    ctx.font = "600 18px Arial"; ctx.fillStyle = "#E7E2F2";
    ctx.fillText("LET'S CREATE SOMETHING GREAT", 540, H * 0.49 + 52);
    ctx.restore(); return;
  }

  // Main typography with soft blur-like shadow and sharp reveal
  const headline = scene.topTitle || blueprint.title || "MAKE YOUR IDEAS MOVE";
  ctx.textAlign = "center";
  ctx.font = "900 58px Arial";
  ctx.shadowColor = dark ? "rgba(255,255,255,.24)" : "rgba(25,20,40,.18)";
  ctx.shadowBlur = 12 * (1 - ease);
  ctx.fillStyle = ink;
  ctx.fillText(headline.toUpperCase(), 540, H * 0.29, 900);
  ctx.shadowBlur = 0;
  if (scene.topSubLabel) {
    ctx.font = "600 16px Arial"; ctx.fillStyle = dark ? "#B8B5C4" : "#858493";
    ctx.fillText(scene.topSubLabel.toUpperCase(), 540, H * 0.29 + 38);
  }

  // Floating search/browser pill
  const floatY = Math.sin(t * 1.4) * 10;
  ctx.save(); ctx.translate(540, H * 0.43 + floatY);
  ctx.shadowColor = "rgba(20,15,35,.18)"; ctx.shadowBlur = 28; ctx.shadowOffsetY = 12;
  ctx.fillStyle = white; roundRectPath(ctx, -210, -42, 420, 84, 42); ctx.fill();
  ctx.shadowColor = "transparent";
  ctx.fillStyle = "#A0A0AA"; ctx.font = "500 24px Arial"; ctx.textAlign = "center";
  ctx.fillText("search...", 0, 8);
  ctx.fillStyle = "#282833"; ctx.font = "700 25px Arial"; ctx.fillText("⌕", -160, 8);
  ctx.fillText("↻", 164, 8); ctx.restore();

  // Purple vertical project panel, sliding from below
  const panelY = H * 0.59 + (1 - ease) * 100;
  ctx.save(); ctx.translate(540, panelY);
  ctx.shadowColor = "rgba(74,24,150,.26)"; ctx.shadowBlur = 32; ctx.shadowOffsetY = 18;
  const grad = ctx.createLinearGradient(-125, 0, 125, 0);
  grad.addColorStop(0, "#6814D8"); grad.addColorStop(.5, "#8B2CF5"); grad.addColorStop(1, "#5B17C8");
  ctx.fillStyle = grad; roundRectPath(ctx, -125, -160, 250, 320, 24); ctx.fill();
  ctx.shadowBlur = 0; ctx.fillStyle = "rgba(255,255,255,.12)"; ctx.fillRect(-2, -160, 4, 320);
  ctx.fillStyle = white; roundRectPath(ctx, -94, -22, 188, 74, 14); ctx.fill();
  ctx.fillStyle = "#19151F"; ctx.font = "900 30px Arial"; ctx.textAlign = "center";
  ctx.fillText((blueprint.subjectNameplate || "CREATOR").slice(0, 16), 0, 23);
  ctx.fillStyle = white; ctx.font = "800 30px Arial"; ctx.fillText("PROJECT", 0, 102);
  ctx.restore();

  // Floating profile card and category chips
  const cardX = 790 + Math.sin(t) * 12, cardY = H * .58 - 12;
  ctx.save(); ctx.translate(cardX, cardY); ctx.rotate(.025 * Math.sin(t));
  ctx.shadowColor = "rgba(20,15,35,.16)"; ctx.shadowBlur = 24; ctx.shadowOffsetY = 10;
  ctx.fillStyle = white; roundRectPath(ctx, -130, -100, 260, 200, 22); ctx.fill();
  ctx.shadowBlur = 0; ctx.fillStyle = "#E9E5F0"; ctx.beginPath(); ctx.arc(0, -40, 38, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = accent; ctx.font = "700 30px Arial"; ctx.textAlign = "center"; ctx.fillText("✦", 0, -29);
  ctx.fillStyle = "#24232B"; ctx.font = "800 20px Arial"; ctx.fillText("CREATOR", 0, 24);
  ctx.fillStyle = "#858493"; ctx.font = "500 13px Arial"; ctx.fillText("I make ideas move", 0, 48);
  ctx.restore();

  // CTA pill
  const ctaY = H * .82 + Math.sin(t * 1.6) * 4;
  ctx.save(); ctx.shadowColor = "rgba(0,110,230,.28)"; ctx.shadowBlur = 18;
  ctx.fillStyle = "#168FE8"; roundRectPath(ctx, 360, ctaY - 25, 360, 52, 26); ctx.fill();
  ctx.shadowBlur = 0; ctx.fillStyle = white; ctx.font = "600 20px Arial"; ctx.textAlign = "center";
  ctx.fillText("LET'S WORK TOGETHER", 540, ctaY + 7); ctx.restore();

  ctx.restore();
}

export function renderVideoFrame(
  ctx: CanvasRenderingContext2D,
  blueprint: VideoBlueprint,
  currentTime: number,
  audioBins?: Uint8Array
) {
  const { width: w, height: h } = getCanvasDimensions(blueprint.aspectRatio);
  const isWide = blueprint.aspectRatio === "16:9";
  const theme = getTheme(blueprint.style);

  // Locate active scene
  let sceneIndex = blueprint.scenes.findIndex(
    (s) => currentTime >= s.startTime && currentTime < s.endTime
  );
  if (sceneIndex === -1) {
    sceneIndex = Math.max(0, blueprint.scenes.length - 1);
  }
  const scene = blueprint.scenes[sceneIndex];
  if (!scene) return;

  const sceneElapsed = Math.max(0, currentTime - scene.startTime);
  const sceneDuration = Math.max(0.5, scene.durationSeconds);
  const sceneProgress = Math.min(1, sceneElapsed / sceneDuration);

  if (blueprint.style === "creator-showcase") {
    drawCreatorShowcaseFrame(ctx, blueprint, scene, sceneIndex, sceneElapsed, sceneDuration, currentTime, w, h);
    const showcaseTheme = getTheme(blueprint.style);
    drawSubtitles(ctx, scene, showcaseTheme, w, h, sceneProgress, blueprint.aspectRatio === "16:9");
    return;
  }

  // 1. Background & Subtle Grid
  drawGridBackground(ctx, w, h, theme, blueprint.style, currentTime);

  // Apply per-scene entrance transition (Fade, Slide, Zoom, Whip, Morph, Depth, or Cut)
  const transition = scene.transition || "fade";
  const transT = easeOutCubic(Math.min(1, sceneElapsed / 0.52));
  const springTrans =
    transT === 0 || transT === 1
      ? transT
      : 1 - Math.pow(2, -8 * transT) * Math.cos(transT * Math.PI * 3);
  ctx.save();
  if (transition === "fade") {
    ctx.globalAlpha = transT;
  } else if (transition === "slide") {
    ctx.globalAlpha = Math.min(1, transT * 1.25);
    ctx.translate((1 - transT) * w * 0.14, 0);
  } else if (transition === "zoom") {
    const zoomScale = 0.86 + 0.14 * transT;
    ctx.globalAlpha = Math.min(1, transT * 1.2);
    ctx.translate(w / 2, h / 2);
    ctx.scale(zoomScale, zoomScale);
    ctx.translate(-w / 2, -h / 2);
  } else if (transition === "whip") {
    const whipOffset = (1 - transT) * w * 0.34;
    const stretchX = 1 + (1 - transT) * 0.14;
    ctx.globalAlpha = Math.min(1, 0.25 + transT * 0.85);
    ctx.translate(w / 2 + whipOffset, h / 2);
    ctx.scale(stretchX, 1 / Math.sqrt(stretchX));
    ctx.translate(-w / 2, -h / 2);
  } else if (transition === "morph") {
    const morphScale = 0.9 + 0.1 * springTrans;
    ctx.globalAlpha = Math.min(1, transT * 1.3);
    ctx.translate(w / 2, h / 2);
    ctx.scale(morphScale, morphScale);
    ctx.translate(-w / 2, -h / 2);
  } else if (transition === "depth") {
    const depthScale = 1.18 - 0.18 * transT;
    ctx.globalAlpha = Math.min(1, transT * 1.35);
    ctx.translate(w / 2, h / 2);
    ctx.scale(depthScale, depthScale);
    ctx.translate(-w / 2, -h / 2);
  }

  // 2. Top Headline & Callout
  const afterHeaderY = drawTopHeadline(
    ctx,
    scene,
    theme,
    w,
    h,
    sceneElapsed,
    isWide
  );

  // 3. Progressive Comparison Table (shown when rows exist)
  const padX = isWide ? w * 0.06 : w * 0.075;
  const tableW = isWide ? w * 0.44 : w - padX * 2;
  const afterTableY = drawComparisonTable(
    ctx,
    blueprint,
    sceneIndex,
    sceneElapsed,
    theme,
    padX,
    afterHeaderY + 12,
    tableW
  );

  // 4. Center Stage Illustration
  const stageTop = isWide ? afterHeaderY + 20 : Math.max(afterTableY, h * 0.35);
  const stageBottom = h - (isWide ? 190 : 290);
  const stageCenterY = (stageTop + stageBottom) / 2;
  const stageCenterX =
    isWide && afterTableY > afterHeaderY + 15 ? w * 0.72 : w * 0.5;

  const baseScale = isWide
    ? afterTableY > afterHeaderY + 15
      ? 0.85
      : 1.05
    : blueprint.aspectRatio === "1:1"
    ? 0.82
    : 1.04;

  // Semantic Visual Resolution + Sentence-Level Narration Synchronization
  const visualSpec = resolveSceneVisualSpec(scene, blueprint.title);
  const segments: NarrationSegment[] =
    scene.narrationSegments && scene.narrationSegments.length > 0
      ? scene.narrationSegments
      : buildNarrationSegments(
          scene.narration,
          sceneDuration,
          visualSpec,
          blueprint.languagePreference || "auto"
        );
  const activeSegment =
    segments.find(
      (seg) => sceneElapsed >= seg.startTime && sceneElapsed <= seg.endTime
    ) || segments[segments.length - 1];

  const renderSpecializedWithCamera = (drawFn: () => void) => {
    ctx.save();
    applyCameraTransform(
      ctx,
      activeSegment?.cameraEvent || visualSpec.cameraMovement,
      stageCenterX,
      stageCenterY,
      sceneProgress,
      currentTime,
      {
        timing: visualSpec.motionTiming || "spring",
        intensity: visualSpec.animationIntensity || "cinematic",
        activeSegment,
      }
    );
    drawFn();
    ctx.restore();
  };

  if (visualSpec.assetKey === "server_cyber") {
    renderSpecializedWithCamera(() =>
      drawServerRadarScene(
        ctx,
        scene,
        theme,
        stageCenterX,
        stageCenterY,
        baseScale,
        currentTime,
        sceneElapsed
      )
    );
  } else if (visualSpec.assetKey === "data_network") {
    renderSpecializedWithCamera(() =>
      drawNetworkGraphScene(
        ctx,
        scene,
        theme,
        stageCenterX,
        stageCenterY,
        baseScale,
        currentTime,
        sceneElapsed
      )
    );
  } else if (visualSpec.assetKey === "news_globe") {
    renderSpecializedWithCamera(() =>
      drawNewsMapScene(
        ctx,
        scene,
        theme,
        stageCenterX,
        stageCenterY,
        baseScale,
        currentTime,
        sceneElapsed
      )
    );
  } else if (visualSpec.assetKey === "law_balance") {
    renderSpecializedWithCamera(() =>
      drawExecutiveDesk(
        ctx,
        stageCenterX,
        stageCenterY + 34,
        baseScale,
        theme,
        blueprint.subjectNameplate,
        currentTime,
        sceneElapsed,
        { showChair: true, showScales: true, showQuestion: true }
      )
    );
  } else if (visualSpec.assetKey === "editorial_desk") {
    if (blueprint.style === "kinetic-cards" && scene.archetype === "desk_intro") {
      renderSpecializedWithCamera(() =>
        drawKineticStatementScene(
          ctx,
          scene,
          theme,
          stageCenterX,
          stageCenterY,
          baseScale,
          currentTime,
          sceneElapsed,
          audioBins
        )
      );
    } else {
      renderSpecializedWithCamera(() =>
        drawExecutiveDesk(
          ctx,
          stageCenterX,
          stageCenterY + (scene.archetype === "document_audit" ? 38 : 28),
          baseScale,
          theme,
          blueprint.subjectNameplate,
          currentTime,
          sceneElapsed,
          scene.archetype === "document_audit"
            ? { showChair: false, showDocs: true }
            : { showChair: true }
        )
      );
    }
  } else if (
    visualSpec.assetKey === "money_economy" &&
    scene.archetype === "metric_counter" &&
    scene.visualMetric
  ) {
    renderSpecializedWithCamera(() =>
      drawMetricCounterScene(
        ctx,
        scene,
        theme,
        stageCenterX,
        stageCenterY,
        baseScale,
        currentTime,
        sceneElapsed
      )
    );
  } else {
    drawSemanticVisualScene(
      ctx,
      visualSpec,
      scene,
      theme,
      blueprint.style,
      stageCenterX,
      stageCenterY,
      baseScale,
      currentTime,
      sceneElapsed,
      sceneDuration,
      activeSegment
    );

    if (scene.visualMetric) {
      const m = scene.visualMetric;
      const metricText = `${m.prefix}${m.targetValue.toFixed(m.decimals)}${m.suffix}`;
      ctx.save();
      const pillW = Math.min(340, Math.max(190, metricText.length * 18 + 64));
      const pillX = stageCenterX + 185 * baseScale - pillW / 2;
      const pillY = stageCenterY - 210 * baseScale;
      ctx.fillStyle = theme.cardBg;
      ctx.strokeStyle = theme.accent;
      ctx.lineWidth = 2;
      roundRectPath(ctx, pillX, pillY, pillW, 56, 12);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = theme.accent;
      ctx.font = `800 22px "JetBrains Mono", monospace`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(metricText, pillX + pillW / 2, pillY + 21, pillW - 20);

      ctx.fillStyle = theme.inkMuted;
      ctx.font = `600 12px "DM Sans", sans-serif`;
      ctx.fillText(m.unitLabel, pillX + pillW / 2, pillY + 42, pillW - 20);
      ctx.restore();
    }
  }

  // Optional sonic waveform overlay when Audio Pulse style is active
  if (blueprint.style === "audio-pulse") {
    drawAudioPulseOverlay(ctx, w, h, theme, currentTime, audioBins);
  }

  ctx.restore();

  // 5. Brand Handle tag
  if (blueprint.brandHandle) {
    ctx.save();
    ctx.fillStyle = theme.inkMuted;
    ctx.globalAlpha = 0.65;
    ctx.font = `600 20px "JetBrains Mono", monospace`;
    ctx.textAlign = "right";
    ctx.fillText(blueprint.brandHandle, w - padX, h - (isWide ? 34 : 44));
    ctx.restore();
  }

  // 6. Synchronized Karaoke Subtitles
  drawSubtitles(ctx, scene, theme, w, h, sceneProgress, isWide);
}
