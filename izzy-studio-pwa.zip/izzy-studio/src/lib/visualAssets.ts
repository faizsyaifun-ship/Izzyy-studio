import type {
  AnimationIntensity,
  EnvironmentalEffectType,
  MotionTimingCurve,
  NarrationSegment,
  SceneVisualSpec,
  VideoScene,
  VideoStyleId,
  VisualAnimationType,
  VisualAssetKey,
  VisualCameraMovement,
} from "../types/video";
import { defaultEnvironmentalEffectForAsset } from "./languageSync";

export interface VisualThemePalette {
  isDark: boolean;
  bg: string;
  bgSecondary: string;
  gridColor: string;
  ink: string;
  inkMuted: string;
  accent: string;
  accentText: string;
  accentSoft: string;
  success: string;
  warning: string;
  danger: string;
  cardBg: string;
  cardBorder: string;
}

function easeOutCubic(x: number): number {
  const c = Math.max(0, Math.min(1, x));
  return 1 - Math.pow(1 - c, 3);
}

function easeOutBack(x: number): number {
  const c = Math.max(0, Math.min(1, x));
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(c - 1, 3) + c1 * Math.pow(c - 1, 2);
}

function roundRect(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.arcTo(x + w, y, x + w, y + h, radius);
  ctx.arcTo(x + w, y + h, x, y + h, radius);
  ctx.arcTo(x, y + h, x, y, radius);
  ctx.arcTo(x, y, x + w, y, radius);
  ctx.closePath();
}

// Replaced by bilingual semantic inference below

function easeInOutCubic(x: number): number {
  const c = Math.max(0, Math.min(1, x));
  return c < 0.5 ? 4 * c * c * c : 1 - Math.pow(-2 * c + 2, 3) / 2;
}

function springEase(x: number): number {
  const c = Math.max(0, Math.min(1, x));
  if (c === 0 || c === 1) return c;
  return 1 - Math.pow(2, -9 * c) * Math.cos(c * Math.PI * 3.5);
}

function resolveMotionCurve(
  progress: number,
  curve: MotionTimingCurve = "ease_in_out"
): number {
  const p = Math.max(0, Math.min(1, progress));
  switch (curve) {
    case "spring":
      return springEase(p);
    case "linear_flow":
      return p;
    case "dramatic_ramp":
      return p * p * (3 - 2 * p) * 0.65 + easeOutCubic(p) * 0.35;
    case "ease_in_out":
    default:
      return easeInOutCubic(p);
  }
}

export function inferVisualSpecFromSceneText(
  scene: Pick<
    VideoScene,
    | "topTitle"
    | "topHighlightWord"
    | "topSubLabel"
    | "narration"
    | "archetype"
    | "bullets"
    | "calloutBadge"
  >,
  blueprintTitle = ""
): SceneVisualSpec {
  const text = `${scene.topTitle || ""} ${scene.topSubLabel || ""} ${
    scene.narration || ""
  }`.toLowerCase();
  const fullContext = `${text} ${blueprintTitle.toLowerCase()}`;

  // Bullet / projectile / ballistics (Indonesian + English)
  if (
    /\b(peluru|proyektil|bullet|projectile|firearm|gunshot|senjata|tembak|balistik|ballistic|kaliber|caliber|velocity|muzzle|impact)\b/i.test(
      text
    ) &&
    !/\b(tubuh|body|organ|jaringan|tissue|paru|lung|jantung|heart|dada|chest|otot|tulang|bone|korban|victim|penetrasi|penetrat)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "projectile_bullet",
      subject: "Ballistic Projectile",
      action: "Melaju berkecepatan tinggi dengan gelombang kejut",
      environment: "Lintasan uji balistik & vektor energi kinetik",
      objects: ["Proyektil aerodinamis", "Gelombang kejut Mach", "Vektor kecepatan"],
      visualDescription:
        "3D-shaded projectile accelerating through air with Mach shockwave cones and kinetic energy trails.",
      cameraMovement: "track_object",
      animationType: "trajectory",
      focusRegion: "Ujung Proyektil / Projectile Tip",
      objectMovement: "High-speed horizontal acceleration with spin & motion trail",
      secondaryAnimation: "Expanding shockwaves and compressed air vortex particles",
      environmentalEffect: "shockwave_rings",
      animationIntensity: "cinematic",
      motionTiming: "dramatic_ramp",
      narrationSyncCue: "Accelerate projectile and shockwaves on kinetic emphasis",
    };
  }

  // Heart & blood circulation (Indonesian + English)
  if (
    /\b(jantung|heart|cardiac|heartbeat|beating|detak|pulse|kardiovaskular|cardiovascular|pembuluh darah|artery|arterial|vein|blood flow|nadi|bpm)\b/i.test(
      text
    )
  ) {
    const isAccelerating = /\b(faster|accelerate|speed|rapid|lebih cepat|kencang|meningkat)\b/i.test(
      text
    );
    return {
      assetKey: "heart_organ",
      subject: "Organ Jantung / 3D Heart",
      action: isAccelerating
        ? "Berdetak semakin cepat dengan aliran darah deras"
        : "Memompa aliran darah & memantau ritme detak",
      environment: "Tampilan anatomi kardiovaskular edukatif",
      objects: ["Ruang jantung 3D", "Pembuluh aorta & arteri", "Gelombang EKG"],
      visualDescription:
        "3D pulsing heart with flowing vascular blood corpuscles, synchronized ECG trace, and rhythmic light halo.",
      cameraMovement: "dolly_in",
      animationType: "pulse",
      focusRegion: "Katup & Ruang Jantung",
      objectMovement: isAccelerating
        ? "Progressive heartbeat acceleration with volumetric chamber squeeze"
        : "Rhythmic dual-phase cardiac pulse",
      secondaryAnimation: "Arterial blood particles streaming through vessels + live ECG",
      environmentalEffect: "blood_flow",
      animationIntensity: "cinematic",
      motionTiming: "spring",
      narrationSyncCue: "Sync pulse rate and push-in lighting with beat intensity",
    };
  }

  // Brain & nervous system (Indonesian + English)
  if (
    /\b(otak|brain|saraf|nerve|neural|neuron|synapse|kognitif|cognitive|memori|memory|kesadaran|consciousness|kepala|mental)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "brain_organ",
      subject: "Otak & Sistem Saraf",
      action: "Mengirimkan impuls sinaptik aktif antar hemisfer",
      environment: "Skema neurologis edukatif",
      objects: ["Hemisfer otak", "Simpul saraf", "Sinyal sinaps bercahaya"],
      visualDescription:
        "Animated brain hemispheres with cascading synaptic impulses and glowing neural connections.",
      cameraMovement: "dolly_in",
      animationType: "scan_highlight",
      focusRegion: "Korteks & Sinaps",
      objectMovement: "Gentle floating cortex with propagating neural pulses",
      secondaryAnimation: "Cascading synaptic sparks and signal arcs",
      environmentalEffect: "data_streams",
      animationIntensity: "cinematic",
      motionTiming: "ease_in_out",
      narrationSyncCue: "Illuminate active neural nodes sequentially with narration",
    };
  }

  // Anatomy / organs / tissue penetration / medical trauma (Indonesian + English)
  if (
    /\b(anatomi|anatomy|organ|paru|lung|dada|chest|perut|abdomen|tulang|bone|rusuk|rib|jaringan|tissue|pembuluh|internal|penetrasi|penetrat|kavitasi|cavitation|trauma|wound)\b/i.test(
      text
    ) ||
    (/\b(dampak|akibat|impact|effect|energi kinetik|kinetic|gelombang tekan|shockwave)\b/i.test(
      text
    ) &&
      /\b(peluru|bullet|tubuh|body|manusia|human)\b/i.test(fullContext))
  ) {
    return {
      assetKey: "human_anatomy",
      subject: "Anatomi Tubuh Manusia",
      action: "Menyorot zona organ terdampak secara edukatif",
      environment: "Diagram pemindaian medis edukatif",
      objects: ["Rangka dada & rusuk", "Paru-paru & jantung", "Garis pemindaian fokus"],
      visualDescription:
        "Educational anatomical cross-section with scanning highlight beam and pulsing organ focus marker.",
      cameraMovement: "dolly_in",
      animationType: "scan_highlight",
      focusRegion: /\b(jantung|heart)\b/i.test(text)
        ? "Area Jantung"
        : /\b(paru|lung|dada|chest)\b/i.test(text)
        ? "Rongga Dada"
        : "Zona Organ Terdampak",
      objectMovement: "Layered torso breathing motion with laser depth scan",
      secondaryAnimation: "Pulsing organ callout rings and circulating blood motes",
      environmentalEffect: "blood_flow",
      animationIntensity: "cinematic",
      motionTiming: "ease_in_out",
      narrationSyncCue: "Sweep scan line toward focus region as explanation deepens",
    };
  }

  // Human silhouette (Indonesian + English)
  if (
    /\b(tubuh|body|manusia|human|fisik|physical|postur|posture|seseorang|person|korban|victim|pasien|patient)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "human_silhouette",
      subject: "Siluet Tubuh Manusia",
      action: "Menunjukkan orientasi tubuh dan titik masuk energi",
      environment: "Ruang pemetaan proporsi tubuh",
      objects: ["Siluet tubuh 2.5D", "Garis sumbu", "Cincin target fokus"],
      visualDescription:
        "Human figure silhouette with orbital target rings and directional kinetic vector.",
      cameraMovement: "tilt_focus",
      animationType: "scan_highlight",
      focusRegion: "Area Tubuh Utama",
      objectMovement: "Subtle breathing stance with concentric target tracking",
      secondaryAnimation: "Directional trajectory vector and expanding target halo",
      environmentalEffect: "ambient_dust",
      animationIntensity: "balanced",
      motionTiming: "spring",
      narrationSyncCue: "Lock focus ring onto body zone as narration introduces subject",
    };
  }

  // Bullet fallback
  if (/\b(peluru|proyektil|bullet|projectile)\b/i.test(text)) {
    return {
      assetKey: "projectile_bullet",
      subject: "Proyektil Peluru",
      action: "Menunjukkan lintasan dan energi tumbukan",
      environment: "Ruang simulasi lintasan fisik",
      objects: ["Proyektil", "Garis lintasan", "Gelombang energi"],
      visualDescription: "Animated projectile moving with force vectors and shockwaves.",
      cameraMovement: "track_object",
      animationType: "trajectory",
      focusRegion: "Lintasan Proyektil",
      objectMovement: "Translational velocity sweep with trailing pressure cone",
      secondaryAnimation: "Vortex dust particles and impact barrier glow",
      environmentalEffect: "shockwave_rings",
      animationIntensity: "cinematic",
      motionTiming: "dramatic_ramp",
    };
  }

  // Planet / Solar system / Space (Indonesian + English)
  if (
    /\b(planet|tata surya|solar system|matahari|sun|bumi|earth|mars|jupiter|saturnus|saturn|orbit|antariksa|space|galaksi|galaxy|bulan|moon|bintang|star|astronomi|astronomy|cosmos)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "solar_planet",
      subject: "Planet & Tata Surya",
      action: "Mengorbit bintang pusat di jalur elips",
      environment: "Ruang angkasa dengan bintang parallax & jalur orbit",
      objects: ["Bintang pusat bercahaya", "Planet bercincin & bulan", "Lintasan orbit"],
      visualDescription:
        "Multi-layer solar system with glowing central star, orbiting planets, moons, and parallax starfield.",
      cameraMovement: "orbit",
      animationType: "orbit",
      focusRegion: "Jalur Orbit Planet",
      objectMovement: "Continuous Keplerian orbital motion with satellite moons",
      secondaryAnimation: "Twinkling 3-depth parallax stars and solar corona flare",
      environmentalEffect: "starfield_drift",
      animationIntensity: "cinematic",
      motionTiming: "linear_flow",
      narrationSyncCue: "Orbit camera smoothly around planetary plane",
    };
  }

  // Earthquake / seismic (Indonesian + English)
  if (
    /\b(gempa|earthquake|seismik|seismic|tektonik|tectonic|lempeng|plate|getaran|vibration|tremor|magnitudo|magnitude|reruntuhan|bangunan|building|tsunami|patahan|fault)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "earthquake_seismic",
      subject: "Bangunan & Gelombang Seismik",
      action: "Menerima gelombang seismik dari patahan bawah tanah",
      environment: "Penampang lapisan tanah & gedung bertingkat",
      objects: ["Gedung bertingkat", "Gelombang seismik", "Garis patahan aktif"],
      visualDescription:
        "Cross-section tectonic fault radiating seismic waves beneath swaying buildings and rising dust.",
      cameraMovement: "tilt_focus",
      animationType: "shake_wave",
      focusRegion: "Episentrum & Patahan",
      objectMovement: "Harmonic structural sway + ground fault shear tremor",
      secondaryAnimation: "Radiating concentric seismic rings and rising dust motes",
      environmentalEffect: "seismic_tremor",
      animationIntensity: "cinematic",
      motionTiming: "spring",
      narrationSyncCue: "Intensify wave frequency during peak seismic impact",
    };
  }

  // Car / vehicle / transport (Indonesian + English)
  if (
    /\b(mobil|car|vehicle|kendaraan|otomotif|automotive|transportasi|transport|jalan raya|highway|mesin|engine|ev|kecepatan|speed|traffic|lalu lintas)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "vehicle_car",
      subject: "Kendaraan & Aerodinamika",
      action: "Melaju di lintasan dengan aliran udara dinamis",
      environment: "Jalan raya berkecepatan tinggi",
      objects: ["Mobil 2.5D", "Roda berputar", "Garis aliran aerodinamis"],
      visualDescription:
        "2.5D vehicle cruising over scrolling lane markers with spinning wheels and aerodynamic airflow streaks.",
      cameraMovement: "track_object",
      animationType: "trajectory",
      focusRegion: "Bodi & Penggerak",
      objectMovement: "Dynamic suspension bounce with spinning wheels and lane parallax",
      secondaryAnimation: "Sweeping aerodynamic wind ribbons and motion blur trails",
      environmentalEffect: "shockwave_rings",
      animationIntensity: "cinematic",
      motionTiming: "linear_flow",
    };
  }

  // Ocean / sea / marine life (Indonesian + English)
  if (
    /\b(laut|sea|ocean|samudra|ombak|wave|gelombang laut|bawah laut|underwater|ikan|fish|terumbu karang|coral|ekosistem laut|marine|maritim)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "ocean_marine",
      subject: "Laut & Kehidupan Bawah Air",
      action: "Ombak bergulung dan biota berenang mengikuti arus",
      environment: "Permukaan ombak & perairan bawah laut",
      objects: ["Ombak laut", "Ikan berenang", "Terumbu karang & cahaya"],
      visualDescription:
        "Layered ocean surface waves with underwater sunbeams, drifting bubbles, and swimming fish.",
      cameraMovement: "pan_right",
      animationType: "float_drift",
      focusRegion: "Ekosistem Laut",
      objectMovement: "Sinusoidal wave swells and multi-depth fish glide",
      secondaryAnimation: "Buoyant rising bubbles and swaying underwater light shafts",
      environmentalEffect: "ocean_bubbles",
      animationIntensity: "balanced",
      motionTiming: "linear_flow",
    };
  }

  // Solar energy / renewable power (Indonesian + English)
  if (
    /\b(energi surya|solar energy|solar panel|panel surya|listrik|electricity|tenaga surya|baterai|battery|renewable|hijau|green|emisi|emission|power|gw)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "energy_solar",
      subject: "Panel Surya & Aliran Energi",
      action: "Menangkap sinar matahari dan mengalirkan daya ke penyimpanan",
      environment: "Lanskap pembangkit energi bersih",
      objects: ["Matahari bersinar", "Panel fotovoltaik", "Unit baterai aktif"],
      visualDescription:
        "Solar array absorbing photon streams into an animated charging power cell.",
      cameraMovement: "dolly_in",
      animationType: "flow_stream",
      focusRegion: "Sel Fotovoltaik",
      objectMovement: "Charging power level climb + glowing solar cell shimmer",
      secondaryAnimation: "Photon streams and rising electric sparks",
      environmentalEffect: "energy_sparks",
      animationIntensity: "cinematic",
      motionTiming: "ease_in_out",
    };
  }

  // Technology / hardware / AI chip / digital system (Indonesian + English)
  if (
    /\b(teknologi|technology|komputer|computer|chip|semiconductor|mikroprosesor|processor|cpu|gpu|sirkuit|circuit|robot|perangkat|device|gadget|ai|artificial intelligence|algoritma|algorithm|sensor|digital)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "tech_circuit",
      subject: "Prosesor & Sirkuit Teknologi",
      action: "Memproses sinyal digital melalui jalur sirkuit aktif",
      environment: "Papan sirkuit & modul prosesor modern",
      objects: ["Prosesor inti 3D", "Jalur sirkuit", "Paket data bercahaya"],
      visualDescription:
        "Multi-layer processor chip with glowing circuit traces, flying data packets, and active core illumination.",
      cameraMovement: "dolly_in",
      animationType: "flow_stream",
      focusRegion: "Prosesor Inti",
      objectMovement: "Floating multi-tier core pulsing with clock cycles",
      secondaryAnimation: "High-speed data packets streaming across peripheral traces",
      environmentalEffect: "data_streams",
      animationIntensity: "cinematic",
      motionTiming: "linear_flow",
    };
  }

  // Cyber / server (Indonesian + English)
  if (
    /\b(server|data center|pusat data|ransomware|pdn|keamanan siber|cybersecurity|firewall|cloud|security)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "server_cyber",
      subject: "Rak Server & Radar Siber",
      action: "Memindai ancaman jaringan secara kontinu",
      environment: "Pusat data dengan radar pemantauan",
      objects: ["Rak server", "Radar pemindai", "Terminal klien"],
      visualDescription: "Data center server rack with sweeping security radar and protected terminals.",
      cameraMovement: "dolly_in",
      animationType: "scan_highlight",
      focusRegion: "Pemindaian Keamanan",
      objectMovement: "Continuous 360-degree radar sweep and terminal status transitions",
      secondaryAnimation: "Blinking LED telemetry and falling digital matrix streams",
      environmentalEffect: "data_streams",
      animationIntensity: "balanced",
      motionTiming: "linear_flow",
    };
  }

  // Network / cluster / graph (Indonesian + English)
  if (
    scene.archetype === "network_graph" ||
    /\b(jaringan|network|klaster|cluster|simpul|node|koneksi|connection|relasi|graph)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "data_network",
      subject: "Jaringan & Klaster Data",
      action: "Menghubungkan simpul dan mendeteksi pola otomatis",
      environment: "Grafik simpul jaringan terhubung",
      objects: ["Simpul pusat", "Jalur koneksi", "Klaster aktif"],
      visualDescription:
        "Animated network topology with pulsing central hub and orbiting interconnected nodes.",
      cameraMovement: "orbit",
      animationType: "flow_stream",
      focusRegion: "Pola Koneksi Data",
      objectMovement: "Orbital node breathing and signal propagation",
      secondaryAnimation: "Floating data stream particles across node links",
      environmentalEffect: "data_streams",
      animationIntensity: "cinematic",
      motionTiming: "spring",
    };
  }

  // Economy / money / QRIS / transactions (Indonesian + English)
  if (
    /\b(rupiah|uang|money|currency|anggaran|budget|tender|ekonomi|economy|financial|transaksi|transaction|qris|umkm|rp|miliar|billion|triliun|trillion|market|pasar)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "money_economy",
      subject: "Aliran Ekonomi & Nilai Transaksi",
      action: "Menggambarkan perputaran nilai dan efisiensi finansial",
      environment: "Diagram arus keuangan & metrik ekonomi",
      objects: ["Grafik batang bertumbuh", "Aliran koin 3D", "Indikator pertumbuhan"],
      visualDescription:
        "Growing economic bar graph paired with hovering coins and glowing value particles.",
      cameraMovement: "zoom_in",
      animationType: "scale_compare",
      focusRegion: "Volume Nilai",
      objectMovement: "Spring-animated bar growth with hovering currency discs",
      secondaryAnimation: "Upward spark particles and pulsing growth trendline",
      environmentalEffect: "energy_sparks",
      animationIntensity: "balanced",
      motionTiming: "spring",
    };
  }

  // News / Country / Map (Indonesian + English)
  if (
    /\b(negara|country|nation|dunia|world|global|wilayah|region|kota|city|indonesia|singapura|singapore|brasil|brazil|albania|berita|news)\b/i.test(
      text
    )
  ) {
    return {
      assetKey: "news_globe",
      subject: "Peta Wilayah & Sorotan Kasus",
      action: "Menandai lokasi studi kasus dan informasi utama",
      environment: "Peta geografis regional & kartu informasi",
      objects: ["Pin lokasi berdenyut", "Siluet wilayah", "Kartu berita"],
      visualDescription:
        "Regional broadcast map with pulsing location beacon and animated headline card.",
      cameraMovement: "pan_right",
      animationType: "pulse",
      focusRegion: "Lokasi Studi Kasus",
      objectMovement: "Beacon ripple waves with subtle card parallax",
      secondaryAnimation: "Broadcast signal rings and ambient light dust",
      environmentalEffect: "ambient_dust",
      animationIntensity: "balanced",
      motionTiming: "ease_in_out",
    };
  }

  // Policy / Office / Governance ONLY when genuinely related (Indonesian + English)
  if (
    /\b(kantor|office|meja|desk|kursi|rapat|meeting|birokrasi|bureaucracy|wakil presiden|vice president|menteri|minister|kabinet|cabinet|regulasi|regulation|undang|law)\b/i.test(
      text
    ) ||
    scene.archetype === "desk_intro" ||
    scene.archetype === "document_audit" ||
    scene.archetype === "balance_verdict"
  ) {
    if (scene.archetype === "balance_verdict" || /\b(law|hukum|balance|adil|tanggung jawab)\b/i.test(text)) {
      return {
        assetKey: "law_balance",
        subject: "Timbangan Evaluasi & Keputusan",
        action: "Menimbang dampak positif dan risiko kebijakan",
        environment: "Skema perbandingan keputusan",
        objects: ["Timbangan seimbang", "Penanda keputusan"],
        visualDescription: "Animated balance scale weighing outcomes and policy trade-offs.",
        cameraMovement: "tilt_focus",
        animationType: "scale_compare",
        focusRegion: "Keseimbangan Keputusan",
        objectMovement: "Smooth oscillating balance beam",
        secondaryAnimation: "Ambient studio particles and monitor telemetry",
        environmentalEffect: "ambient_dust",
        animationIntensity: "balanced",
        motionTiming: "ease_in_out",
      };
    }
    if (
      /\b(wapres|wakil presiden|vice president|pemerintah|government|tender|dokumen|kebijakan|policy|kantor|office)\b/i.test(
        fullContext
      )
    ) {
      return {
        assetKey: "editorial_desk",
        subject: "Meja Kebijakan & Dokumen",
        action: "Menyajikan dokumen dan indikator pengawasan",
        environment: "Ruang kerja editorial & analisis kebijakan",
        objects: ["Meja kerja 2.5D", "Monitor data", "Dokumen audit"],
        visualDescription: "Editorial policy desk with live monitor analytics and floating documents.",
        cameraMovement: "dolly_in",
        animationType: "float_drift",
        objectMovement: "Floating audit papers and live monitor chart",
        secondaryAnimation: "Ambient room light motes and rotating radar dial",
        environmentalEffect: "ambient_dust",
        animationIntensity: "balanced",
        motionTiming: "ease_in_out",
      };
    }
  }

  // Adaptive non-desk concept diagram universal fallback!
  const fallbackObjects =
    scene.bullets && scene.bullets.length > 0
      ? scene.bullets.slice(0, 3)
      : [
          scene.topSubLabel || "Core Concept",
          scene.calloutBadge || "Key Mechanism",
          "Impact & Outcome",
        ];

  return {
    assetKey: "concept_diagram",
    subject: scene.topTitle || blueprintTitle || "Core Concept",
    action: "Memetakan hubungan dinamis antar-unsur",
    environment: "Panggung diagram explainer 2.5D",
    objects: fallbackObjects,
    visualDescription: `Multi-layer dynamic concept hub illustrating "${scene.topTitle}" with orbiting factor nodes.`,
    cameraMovement: "dolly_in",
    animationType: "scan_highlight",
    focusRegion: scene.topHighlightWord || "Inti Pembahasan",
    objectMovement: "Floating central hub with gentle node oscillation",
    secondaryAnimation: "Signal pulses traveling along vectors + orbital ring sweep",
    environmentalEffect: "ambient_dust",
    animationIntensity: "cinematic",
    motionTiming: "spring",
  };
}

export function resolveSceneVisualSpec(
  scene: VideoScene,
  blueprintTitle = ""
): SceneVisualSpec {
  if (scene.sceneVisualSpec && scene.sceneVisualSpec.assetKey) {
    const base = scene.sceneVisualSpec;
    return {
      ...base,
      environmentalEffect:
        base.environmentalEffect || defaultEnvironmentalEffectForAsset(base.assetKey),
      animationIntensity: base.animationIntensity || "cinematic",
      motionTiming: base.motionTiming || "spring",
    };
  }
  return inferVisualSpecFromSceneText(scene, blueprintTitle);
}

export function applyCameraTransform(
  ctx: CanvasRenderingContext2D,
  camera: VisualCameraMovement,
  cx: number,
  cy: number,
  sceneProgress: number,
  time: number,
  options?: {
    timing?: MotionTimingCurve;
    intensity?: AnimationIntensity;
    activeSegment?: NarrationSegment;
  }
) {
  let zoom = 1;
  let tx = 0;
  let ty = 0;
  let rot = 0;

  const p = resolveMotionCurve(sceneProgress, options?.timing || "ease_in_out");
  const baseMult =
    options?.intensity === "subtle"
      ? 0.65
      : options?.intensity === "cinematic"
      ? 1.25
      : 1.0;
  const segBoost = options?.activeSegment?.intensityBoost ?? 1;
  const m = baseMult * Math.min(1.45, Math.max(0.7, segBoost));

  switch (camera) {
    case "zoom_in":
      zoom = 0.94 + p * 0.16 * m;
      break;
    case "zoom_out":
      zoom = 1.15 - p * 0.15 * m;
      break;
    case "dolly_in":
      zoom = 0.92 + p * 0.19 * m;
      ty = (1 - p) * 18 * m;
      tx = Math.sin(time * 0.8) * 5 * m;
      break;
    case "orbit":
      tx = Math.cos(time * 0.95) * 26 * m;
      ty = Math.sin(time * 0.95) * 14 * m;
      rot = Math.sin(time * 0.75) * 0.022 * m;
      zoom = 1.03 + Math.sin(time * 0.5) * 0.03 * m;
      break;
    case "tilt_focus":
      rot = (-0.025 + p * 0.05) * m;
      zoom = 1.01 + Math.sin(p * Math.PI) * 0.06 * m;
      ty = Math.cos(time * 1.4) * 5 * m;
      break;
    case "pan_left":
      tx = (32 - p * 64) * m;
      break;
    case "pan_right":
      tx = (-32 + p * 64) * m;
      break;
    case "track_object":
      tx = (-24 + p * 48) * m;
      ty = Math.sin(time * 2.1) * 5 * m;
      zoom = 1.04;
      break;
    case "static":
    default:
      // Gentle living breathing idle drift so even "static" feels cinematic
      ty = Math.sin(time * 1.2) * 3;
      zoom = 1 + Math.sin(time * 0.8) * 0.008;
      break;
  }

  ctx.translate(cx + tx, cy + ty);
  if (rot !== 0) ctx.rotate(rot);
  ctx.scale(zoom, zoom);
  ctx.translate(-cx, -cy);
}

function drawFocusTag(
  ctx: CanvasRenderingContext2D,
  theme: VisualThemePalette,
  label: string,
  x: number,
  y: number
) {
  if (!label) return;
  ctx.save();
  ctx.font = `700 18px "JetBrains Mono", monospace`;
  const w = Math.min(340, ctx.measureText(label.toUpperCase()).width + 28);
  ctx.fillStyle = theme.cardBg;
  ctx.strokeStyle = theme.accent;
  ctx.lineWidth = 2;
  roundRect(ctx, x - w / 2, y - 18, w, 36, 10);
  ctx.fill();
  ctx.stroke();

  ctx.fillStyle = theme.ink;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(label.toUpperCase(), x, y, w - 16);
  ctx.restore();
}

function drawSemanticEnvironmentBackdrop(
  ctx: CanvasRenderingContext2D,
  assetKey: VisualAssetKey,
  theme: VisualThemePalette,
  cx: number,
  cy: number,
  time: number
) {
  ctx.save();
  ctx.translate(cx, cy);

  // Subtle topic-matched framing stage card/halo (keeps 5 styles' exact palette)
  if (assetKey === "solar_planet") {
    // Cosmic starfield backdrop
    ctx.fillStyle = theme.isDark ? "rgba(15, 23, 42, 0.72)" : "rgba(15, 23, 42, 0.9)";
    roundRect(ctx, -370, -245, 740, 490, 26);
    ctx.fill();
    for (let i = 0; i < 28; i++) {
      const sx = Math.sin(i * 17.3) * 335;
      const sy = Math.cos(i * 23.7) * 210;
      const twinkle = 0.35 + 0.5 * Math.abs(Math.sin(time * 2 + i));
      ctx.fillStyle = `rgba(248, 250, 252, ${twinkle.toFixed(2)})`;
      ctx.beginPath();
      ctx.arc(sx, sy, (i % 3) + 1.2, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (assetKey === "ocean_marine") {
    const oceanGrad = ctx.createLinearGradient(0, -235, 0, 240);
    oceanGrad.addColorStop(0, theme.isDark ? "rgba(14, 116, 144, 0.35)" : "rgba(186, 230, 253, 0.65)");
    oceanGrad.addColorStop(1, theme.isDark ? "rgba(8, 47, 73, 0.85)" : "rgba(14, 116, 144, 0.35)");
    ctx.fillStyle = oceanGrad;
    roundRect(ctx, -370, -235, 740, 470, 26);
    ctx.fill();
  } else {
    // Clean educational explainer frame
    ctx.fillStyle = theme.isDark ? "rgba(255,255,255,0.03)" : "rgba(255,255,255,0.68)";
    ctx.strokeStyle = theme.cardBorder;
    ctx.lineWidth = 2;
    roundRect(ctx, -370, -235, 740, 470, 26);
    ctx.fill();
    ctx.stroke();
  }

  ctx.restore();
}

function drawAtmosphericParticleLayer(
  ctx: CanvasRenderingContext2D,
  effect: EnvironmentalEffectType,
  theme: VisualThemePalette,
  time: number,
  layer: "back" | "front",
  intensityMult: number
) {
  const count = layer === "back" ? 14 : 10;
  const speed = (layer === "back" ? 0.7 : 1.25) * intensityMult;

  ctx.save();
  for (let i = 0; i < count; i++) {
    const seedA = Math.sin(i * 19.7 + (layer === "front" ? 4.1 : 1.2));
    const seedB = Math.cos(i * 31.3 + (layer === "front" ? 7.4 : 2.3));
    const pxBase = seedA * 335;
    const pyBase = seedB * 205;

    let x = pxBase;
    let y = pyBase;
    let r = layer === "back" ? 2.4 : 3.8;
    let alpha = layer === "back" ? 0.28 : 0.45;
    let color = theme.accent;

    switch (effect) {
      case "blood_flow": {
        const flow = ((time * 0.45 * speed + i / count) % 1);
        x = -320 + flow * 640;
        y = Math.sin(flow * Math.PI * 3 + i) * 115 + seedB * 65;
        r = layer === "back" ? 3.2 : 5.2;
        color = i % 3 === 0 ? "#EF4444" : theme.accent;
        alpha = 0.42;
        break;
      }
      case "starfield_drift": {
        x = ((pxBase - time * 18 * speed + 350) % 700) - 350;
        y = pyBase;
        r = layer === "back" ? 1.5 : 2.8;
        color = "#F8FAFC";
        alpha = 0.3 + 0.45 * Math.abs(Math.sin(time * 2.4 + i));
        break;
      }
      case "seismic_tremor": {
        x = pxBase + Math.sin(time * 14 + i) * 5 * intensityMult;
        y = 140 - (((time * 48 * speed + i * 32) % 280));
        color = i % 2 === 0 ? theme.warning : theme.danger;
        alpha = 0.38;
        break;
      }
      case "data_streams": {
        x = -300 + ((i * 58 + (layer === "front" ? 25 : 0)) % 600);
        y = (((time * 110 * speed + i * 47) % 420) - 210);
        color = i % 3 === 0 ? theme.success : theme.accent;
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.32;
        roundRect(ctx, x - 2, y - 10, 4, 20, 2);
        ctx.fill();
        continue;
      }
      case "ocean_bubbles": {
        x = pxBase + Math.sin(time * 2.2 + i) * 14;
        y = 195 - (((time * 52 * speed + i * 41) % 360));
        r = 3 + (i % 4) * 1.6;
        ctx.strokeStyle = "rgba(224, 242, 254, 0.55)";
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, Math.PI * 2);
        ctx.stroke();
        continue;
      }
      case "energy_sparks": {
        x = pxBase + Math.cos(time * 3 + i) * 18;
        y = 185 - (((time * 75 * speed + i * 39) % 370));
        color = i % 2 === 0 ? "#FBBF24" : theme.success;
        alpha = 0.52;
        break;
      }
      case "shockwave_rings": {
        const streakT = ((time * 1.3 * speed + i * 0.14) % 1);
        x = 320 - streakT * 640;
        y = pyBase * 0.72;
        ctx.strokeStyle = theme.accent;
        ctx.globalAlpha = 0.25;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + 34 * intensityMult, y);
        ctx.stroke();
        continue;
      }
      case "ambient_dust":
      default: {
        x = pxBase + Math.sin(time * 0.7 + i) * 16;
        y = pyBase + Math.cos(time * 0.6 + i * 1.3) * 14;
        alpha = 0.22 + 0.15 * Math.sin(time * 1.8 + i);
        break;
      }
    }

    ctx.fillStyle = color;
    ctx.globalAlpha = Math.max(0.08, Math.min(0.85, alpha));
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawDynamicLightingHalo(
  ctx: CanvasRenderingContext2D,
  theme: VisualThemePalette,
  time: number,
  pulseFactor: number
) {
  ctx.save();
  const radius = 240 + Math.sin(time * 2.5) * 20 + pulseFactor * 35;
  const lightGrad = ctx.createRadialGradient(0, -10, 12, 0, -10, radius);
  lightGrad.addColorStop(
    0,
    theme.isDark ? "rgba(255,255,255,0.12)" : "rgba(255,255,255,0.5)"
  );
  lightGrad.addColorStop(0.55, theme.accentSoft);
  lightGrad.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = lightGrad;
  ctx.beginPath();
  ctx.arc(0, -10, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawSubjectDropShadow(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  rx: number,
  scaleMod = 1
) {
  ctx.save();
  ctx.fillStyle = "rgba(15, 23, 42, 0.18)";
  ctx.beginPath();
  ctx.ellipse(x, y, rx * scaleMod, rx * 0.22 * scaleMod, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export function drawSemanticVisualScene(
  ctx: CanvasRenderingContext2D,
  spec: SceneVisualSpec,
  scene: VideoScene,
  theme: VisualThemePalette,
  _style: VideoStyleId,
  cx: number,
  cy: number,
  scale: number,
  time: number,
  sceneElapsed: number,
  sceneDuration: number,
  activeSegment?: NarrationSegment
) {
  const sceneProgress = Math.min(1, sceneElapsed / Math.max(0.5, sceneDuration));
  const intensityMult =
    (spec.animationIntensity === "subtle"
      ? 0.72
      : spec.animationIntensity === "cinematic"
      ? 1.28
      : 1.0) * (activeSegment?.intensityBoost ?? 1.0);
  const envEffect: EnvironmentalEffectType =
    spec.environmentalEffect || defaultEnvironmentalEffectForAsset(spec.assetKey);
  const activeCam = activeSegment?.cameraEvent || spec.cameraMovement;
  const activeTrigger = activeSegment?.animationTrigger || "enter";

  ctx.save();
  ctx.translate(cx, cy);
  ctx.scale(scale, scale);

  // Layer 1: Background parallax backdrop + Dynamic Lighting Halo
  const parallaxOffset =
    activeCam === "pan_left"
      ? -12 + sceneProgress * 24
      : activeCam === "pan_right"
      ? 12 - sceneProgress * 24
      : 0;
  drawSemanticEnvironmentBackdrop(ctx, spec.assetKey, theme, parallaxOffset * 0.4, 0, time);

  const pulseBeat =
    activeTrigger === "accelerate" || activeTrigger === "pulse"
      ? Math.pow(Math.max(0, Math.sin(time * 6.8)), 4)
      : Math.pow(Math.max(0, Math.sin(time * 3.2)), 2);
  drawDynamicLightingHalo(ctx, theme, time, pulseBeat);

  // Layer 2: Far atmospheric particle layer
  drawAtmosphericParticleLayer(ctx, envEffect, theme, time, "back", intensityMult);

  // Layer 3: Dynamic Camera Transform + Smooth Physics
  applyCameraTransform(ctx, activeCam, 0, 0, sceneProgress, time, {
    timing: spec.motionTiming || "spring",
    intensity: spec.animationIntensity || "cinematic",
    activeSegment,
  });

  const pop = springEase(Math.min(1, sceneElapsed / 0.55));
  const idleHover = Math.sin(time * 2.2) * 5 * intensityMult;
  const focusLabel = spec.focusRegion || spec.subject;

  switch (spec.assetKey) {
    case "projectile_bullet": {
      // Ballistic trajectory axis
      ctx.strokeStyle = theme.inkMuted;
      ctx.setLineDash([10, 8]);
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(-320, 0);
      ctx.lineTo(310, 0);
      ctx.stroke();
      ctx.setLineDash([]);

      // Target energy barrier on right
      ctx.fillStyle = theme.accentSoft;
      ctx.strokeStyle = theme.accent;
      ctx.lineWidth = 3;
      roundRect(ctx, 215, -135, 36, 270, 10);
      ctx.fill();
      ctx.stroke();

      // Projectile moving with smooth acceleration & motion-blur ghosts
      const speedRate = activeTrigger === "accelerate" ? 0.92 : 0.65;
      const cycle = (sceneElapsed * speedRate) % 1;
      const bx = -225 + easeInOutCubic(Math.min(1, cycle * 1.12)) * 345;
      drawSubjectDropShadow(ctx, bx, 128, 86, 0.95);

      // Mach shockwave cones behind projectile
      for (let k = 1; k <= 3; k++) {
        ctx.strokeStyle = theme.accent;
        ctx.globalAlpha = 0.55 - k * 0.14;
        ctx.lineWidth = 3.2;
        ctx.beginPath();
        ctx.moveTo(bx + 70 - k * 28, 0);
        ctx.lineTo(bx - 120 - k * 34, -95 - k * 14);
        ctx.moveTo(bx + 70 - k * 28, 0);
        ctx.lineTo(bx - 120 - k * 34, 95 + k * 14);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      // Smoke / air wake streaks
      for (let s = 0; s < 5; s++) {
        const sy = -36 + s * 18;
        ctx.strokeStyle = theme.inkMuted;
        ctx.globalAlpha = 0.35;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(bx - 95 - (s % 2) * 35, sy);
        ctx.lineTo(bx - 210 - s * 14, sy);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      // Motion blur ghost trails behind projectile
      for (let g = 2; g >= 1; g--) {
        ctx.save();
        ctx.globalAlpha = 0.14 / g;
        ctx.translate(bx - g * 24 * intensityMult, idleHover * 0.25);
        ctx.fillStyle = theme.accent;
        roundRect(ctx, -95, -30, 115, 60, 8);
        ctx.fill();
        ctx.restore();
      }

      // 3D-shaded aerodynamic brass/steel projectile
      ctx.save();
      ctx.translate(bx, idleHover * 0.25);
      const bodyGrad = ctx.createLinearGradient(0, -34, 0, 34);
      bodyGrad.addColorStop(0, "#F59E0B");
      bodyGrad.addColorStop(0.35, "#FDE68A");
      bodyGrad.addColorStop(0.7, "#D97706");
      bodyGrad.addColorStop(1, "#78350F");
      ctx.fillStyle = bodyGrad;
      roundRect(ctx, -95, -32, 115, 64, 8);
      ctx.fill();

      // Ogive pointed tip
      ctx.beginPath();
      ctx.moveTo(20, -32);
      ctx.quadraticCurveTo(95, -24, 128, 0);
      ctx.quadraticCurveTo(95, 24, 20, 32);
      ctx.closePath();
      ctx.fill();

      // Rifling spin band shimmer
      const bandShift = Math.sin(time * 18) * 6;
      ctx.fillStyle = "#475569";
      ctx.fillRect(-35, -33, 14, 66);
      ctx.fillStyle = "rgba(255,255,255,0.45)";
      ctx.fillRect(-35, bandShift - 6, 14, 12);
      ctx.restore();

      // Velocity indicator caption
      ctx.fillStyle = theme.ink;
      ctx.font = `700 19px "JetBrains Mono", monospace`;
      ctx.textAlign = "left";
      ctx.fillText(
        activeTrigger === "accelerate" ? "V ↑ KINETIC SURGE" : "V = HIGH KINETIC ENERGY",
        -320,
        -155
      );
      drawFocusTag(ctx, theme, focusLabel, 0, 178);
      break;
    }

    case "human_silhouette": {
      ctx.save();
      ctx.scale(pop, pop);

      // Axis grid rings behind figure
      ctx.strokeStyle = theme.gridColor;
      ctx.lineWidth = 2;
      for (let r = 80; r <= 200; r += 60) {
        ctx.beginPath();
        ctx.arc(0, -10, r, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Stylized clean human silhouette
      ctx.fillStyle = theme.isDark ? "#334155" : "#475569";
      ctx.strokeStyle = theme.accent;
      ctx.lineWidth = 3;

      // Head
      ctx.beginPath();
      ctx.arc(0, -148, 34, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Torso & shoulders
      ctx.beginPath();
      ctx.moveTo(-64, -92);
      ctx.quadraticCurveTo(0, -108, 64, -92);
      ctx.lineTo(76, 20);
      ctx.lineTo(48, 22);
      ctx.lineTo(42, -55);
      ctx.lineTo(36, 42);
      ctx.lineTo(44, 165);
      ctx.lineTo(14, 165);
      ctx.lineTo(4, 52);
      ctx.lineTo(-4, 52);
      ctx.lineTo(-14, 165);
      ctx.lineTo(-44, 165);
      ctx.lineTo(-36, 42);
      ctx.lineTo(-42, -55);
      ctx.lineTo(-48, 22);
      ctx.lineTo(-76, 20);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Trajectory/interaction axis arrow pointing toward torso
      const pulse = 1 + Math.sin(time * 4.5) * 0.14;
      ctx.strokeStyle = theme.danger;
      ctx.lineWidth = 4;
      ctx.setLineDash([8, 6]);
      ctx.beginPath();
      ctx.moveTo(-250, -35);
      ctx.lineTo(-16, -35);
      ctx.stroke();
      ctx.setLineDash([]);

      // Target focus ring
      ctx.strokeStyle = theme.danger;
      ctx.lineWidth = 3.5;
      ctx.beginPath();
      ctx.arc(0, -35, 28 * pulse, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = theme.accentSoft;
      ctx.beginPath();
      ctx.arc(0, -35, 16, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();
      drawFocusTag(ctx, theme, focusLabel, 0, 198);
      break;
    }

    case "human_anatomy": {
      // Educational anatomical torso cross-section + organ zones
      ctx.save();
      ctx.scale(pop, pop);

      // Outer torso silhouette
      ctx.fillStyle = theme.isDark ? "#1E293B" : "#E2E8F0";
      ctx.strokeStyle = theme.inkMuted;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, -155, 28, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      roundRect(ctx, -95, -112, 190, 245, 42);
      ctx.fill();
      ctx.stroke();

      // Stylized Lungs
      ctx.fillStyle = theme.isDark ? "rgba(56, 189, 248, 0.28)" : "rgba(59, 130, 246, 0.22)";
      ctx.strokeStyle = "#3B82F6";
      ctx.lineWidth = 2.5;
      roundRect(ctx, -74, -88, 62, 108, 26);
      ctx.fill();
      ctx.stroke();
      roundRect(ctx, 12, -88, 62, 108, 26);
      ctx.fill();
      ctx.stroke();

      // Stylized Ribcage arcs
      ctx.strokeStyle = theme.inkMuted;
      ctx.lineWidth = 2.5;
      for (let r = 0; r < 4; r++) {
        const ry = -72 + r * 24;
        ctx.beginPath();
        ctx.moveTo(-68, ry);
        ctx.quadraticCurveTo(0, ry + 10, 68, ry);
        ctx.stroke();
      }

      // Central Heart & Vascular line
      ctx.fillStyle = theme.danger;
      ctx.beginPath();
      ctx.arc(14, -36, 20, 0, Math.PI * 2);
      ctx.fill();

      // Scanning laser / highlight sweep over anatomy
      const scanY = -95 + ((Math.sin(time * 2.4) + 1) * 0.5) * 190;
      ctx.strokeStyle = theme.accent;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(-125, scanY);
      ctx.lineTo(125, scanY);
      ctx.stroke();

      // Annotated callout pin pointing to focus area
      const ringPulse = 18 + Math.sin(time * 5) * 6;
      ctx.strokeStyle = theme.danger;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(14, -36, ringPulse, 0, Math.PI * 2);
      ctx.stroke();

      ctx.strokeStyle = theme.ink;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(32, -46);
      ctx.lineTo(128, -96);
      ctx.lineTo(295, -96);
      ctx.stroke();

      ctx.fillStyle = theme.cardBg;
      ctx.strokeStyle = theme.accent;
      roundRect(ctx, 130, -124, 210, 56, 12);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = theme.ink;
      ctx.font = `700 18px "Plus Jakarta Sans", sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(focusLabel, 235, -96, 190);

      ctx.restore();
      drawFocusTag(ctx, theme, spec.action.slice(0, 38), 0, 188);
      break;
    }

    case "heart_organ": {
      const beatFreq =
        activeTrigger === "accelerate" ? 6.8 + Math.min(2.5, sceneProgress * 2.5) : 5.0;
      const beat = 1 + Math.pow(Math.max(0, Math.sin(time * beatFreq)), 4) * (0.14 * intensityMult);
      drawSubjectDropShadow(ctx, -85, 130, 88, 1 + (beat - 1) * 0.6);

      // Pulsing cardiac light halo
      const heartGlow = ctx.createRadialGradient(-85, -10, 12, -85, -10, 155 * beat);
      heartGlow.addColorStop(0, "rgba(239, 68, 68, 0.38)");
      heartGlow.addColorStop(1, "rgba(239, 68, 68, 0)");
      ctx.fillStyle = heartGlow;
      ctx.beginPath();
      ctx.arc(-85, -10, 155 * beat, 0, Math.PI * 2);
      ctx.fill();

      ctx.save();
      ctx.translate(-85, -10 + idleHover * 0.45);
      ctx.scale(pop * beat, pop * beat);

      // Aorta & Vena Cava vessels
      ctx.strokeStyle = "#EF4444";
      ctx.lineWidth = 18;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(0, -65);
      ctx.quadraticCurveTo(10, -125, 48, -110);
      ctx.stroke();
      ctx.strokeStyle = "#3B82F6";
      ctx.beginPath();
      ctx.moveTo(-36, -55);
      ctx.lineTo(-55, -105);
      ctx.stroke();

      // Flowing blood cells inside aorta
      for (let bc = 0; bc < 4; bc++) {
        const bFlow = ((time * (beatFreq * 0.25) + bc * 0.25) % 1);
        const bx = bFlow * 48;
        const by = -65 - Math.sin(bFlow * Math.PI * 0.7) * 52;
        ctx.fillStyle = "#FCA5A5";
        ctx.beginPath();
        ctx.arc(bx, by, 4.5, 0, Math.PI * 2);
        ctx.fill();
      }

      // 3D-shaded Heart chambers body
      const heartGrad = ctx.createRadialGradient(-25, -35, 10, 0, 10, 120);
      heartGrad.addColorStop(0, "#F87171");
      heartGrad.addColorStop(0.45, "#DC2626");
      heartGrad.addColorStop(1, "#7F1D1D");
      ctx.fillStyle = heartGrad;
      ctx.beginPath();
      ctx.moveTo(0, 95);
      ctx.bezierCurveTo(-110, 30, -115, -75, -25, -80);
      ctx.bezierCurveTo(0, -82, 0, -52, 0, -45);
      ctx.bezierCurveTo(0, -52, 0, -82, 28, -80);
      ctx.bezierCurveTo(115, -75, 110, 30, 0, 95);
      ctx.fill();

      // Chamber highlight reflection
      ctx.strokeStyle = "rgba(255,255,255,0.45)";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(0, -35);
      ctx.lineTo(-8, 65);
      ctx.stroke();
      ctx.restore();

      // Live ECG monitor card on right
      ctx.fillStyle = "#0F172A";
      ctx.strokeStyle = theme.cardBorder;
      ctx.lineWidth = 3;
      roundRect(ctx, 55, -95, 275, 175, 16);
      ctx.fill();
      ctx.stroke();

      const bpmDisplay = Math.round(72 + (beatFreq - 5) * 18 + Math.sin(time * 2) * 3);
      ctx.fillStyle = "#10B981";
      ctx.font = `700 16px "JetBrains Mono", monospace`;
      ctx.textAlign = "right";
      ctx.fillText(`${bpmDisplay} BPM`, 312, -68);

      ctx.strokeStyle = "#10B981";
      ctx.lineWidth = 3.5;
      ctx.beginPath();
      for (let x = 0; x <= 235; x += 5) {
        const phase = ((x / 75 + time * (beatFreq * 0.28)) % 1);
        const spike =
          phase > 0.42 && phase < 0.48
            ? -55
            : phase >= 0.48 && phase < 0.54
            ? 28
            : phase > 0.62 && phase < 0.72
            ? -14
            : 0;
        const py = -2 + spike;
        if (x === 0) ctx.moveTo(75 + x, py);
        else ctx.lineTo(75 + x, py);
      }
      ctx.stroke();

      drawFocusTag(ctx, theme, focusLabel, 0, 178);
      break;
    }

    case "brain_organ": {
      ctx.save();
      ctx.scale(pop, pop);

      // Left & Right cerebral hemispheres
      ctx.fillStyle = theme.accentSoft;
      ctx.strokeStyle = theme.accent;
      ctx.lineWidth = 4;
      roundRect(ctx, -135, -105, 130, 185, 62);
      ctx.fill();
      ctx.stroke();
      roundRect(ctx, 5, -105, 130, 185, 62);
      ctx.fill();
      ctx.stroke();

      // Synaptic nodes & firing signals
      const brainNodes = [
        { x: -85, y: -55 },
        { x: -45, y: -15 },
        { x: -80, y: 35 },
        { x: 55, y: -60 },
        { x: 92, y: -5 },
        { x: 45, y: 40 },
      ];
      brainNodes.forEach((n, idx) => {
        const next = brainNodes[(idx + 1) % brainNodes.length];
        ctx.strokeStyle = theme.inkMuted;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(n.x, n.y);
        ctx.lineTo(next.x, next.y);
        ctx.stroke();

        const active = Math.sin(time * 4.5 + idx * 1.1) > 0.2;
        ctx.fillStyle = active ? theme.accent : theme.inkMuted;
        ctx.beginPath();
        ctx.arc(n.x, n.y, active ? 11 : 7, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.restore();
      drawFocusTag(ctx, theme, focusLabel, 0, 178);
      break;
    }

    case "vehicle_car": {
      // Road lane
      ctx.fillStyle = "#334155";
      roundRect(ctx, -340, 75, 680, 62, 10);
      ctx.fill();

      // Moving dashed road lines
      const roadOffset = (time * 220) % 90;
      ctx.fillStyle = "#F8FAFC";
      for (let rx = -320 - roadOffset; rx < 320; rx += 90) {
        if (rx > -330 && rx < 290) {
          ctx.fillRect(rx, 102, 46, 7);
        }
      }

      // Car body bouncing gently
      const suspension = Math.sin(time * 7) * 2.5;
      ctx.save();
      ctx.translate(0, suspension);

      // Airflow lines
      for (let i = 0; i < 3; i++) {
        ctx.strokeStyle = theme.accent;
        ctx.globalAlpha = 0.55;
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(-290 + i * 24, -75 + i * 28);
        ctx.quadraticCurveTo(-80, -118 + i * 20, 120, -68 + i * 16);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      // Chassis
      ctx.fillStyle = theme.accent;
      roundRect(ctx, -185, -18, 370, 74, 24);
      ctx.fill();

      // Cabin roof
      ctx.beginPath();
      ctx.moveTo(-110, -16);
      ctx.lineTo(-65, -86);
      ctx.lineTo(68, -86);
      ctx.lineTo(125, -16);
      ctx.closePath();
      ctx.fill();

      // Windows
      ctx.fillStyle = "#0F172A";
      ctx.beginPath();
      ctx.moveTo(-88, -22);
      ctx.lineTo(-55, -74);
      ctx.lineTo(56, -74);
      ctx.lineTo(100, -22);
      ctx.closePath();
      ctx.fill();

      // Wheels rotating
      [-115, 112].forEach((wx) => {
        ctx.save();
        ctx.translate(wx, 58);
        ctx.rotate(time * 6);
        ctx.fillStyle = "#0F172A";
        ctx.beginPath();
        ctx.arc(0, 0, 36, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = "#CBD5E1";
        ctx.beginPath();
        ctx.arc(0, 0, 18, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = "#334155";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(-15, 0);
        ctx.lineTo(15, 0);
        ctx.moveTo(0, -15);
        ctx.lineTo(0, 15);
        ctx.stroke();
        ctx.restore();
      });

      ctx.restore();
      drawFocusTag(ctx, theme, focusLabel, 0, 188);
      break;
    }

    case "solar_planet": {
      // Elliptical orbit paths
      ctx.strokeStyle = "rgba(148, 163, 184, 0.35)";
      ctx.lineWidth = 2;
      [130, 215, 295].forEach((rx) => {
        ctx.beginPath();
        ctx.ellipse(0, 0, rx, rx * 0.45, -0.15, 0, Math.PI * 2);
        ctx.stroke();
      });

      // Glowing Sun / Central Star
      const sunGrad = ctx.createRadialGradient(-10, -10, 10, 0, 0, 72);
      sunGrad.addColorStop(0, "#FEF08A");
      sunGrad.addColorStop(0.55, "#F59E0B");
      sunGrad.addColorStop(1, "rgba(245, 158, 11, 0)");
      ctx.fillStyle = sunGrad;
      ctx.beginPath();
      ctx.arc(0, 0, 72, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = "#FBBF24";
      ctx.beginPath();
      ctx.arc(0, 0, 44, 0, Math.PI * 2);
      ctx.fill();

      // Orbiting Planets
      const planets = [
        { rx: 130, speed: 1.3, size: 15, color: "#38BDF8", ring: false },
        { rx: 215, speed: 0.85, size: 22, color: "#F87171", ring: false },
        { rx: 295, speed: 0.52, size: 26, color: "#C084FC", ring: true },
      ];
      planets.forEach((pl, i) => {
        const ang = time * pl.speed + i * 2.1;
        const px = Math.cos(ang) * pl.rx;
        const py = Math.sin(ang) * pl.rx * 0.45;

        ctx.save();
        ctx.translate(px, py);
        if (pl.ring) {
          ctx.strokeStyle = "#E9D5FF";
          ctx.lineWidth = 4;
          ctx.beginPath();
          ctx.ellipse(0, 0, 42, 12, -0.25, 0, Math.PI * 2);
          ctx.stroke();
        }
        ctx.fillStyle = pl.color;
        ctx.beginPath();
        ctx.arc(0, 0, pl.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      drawFocusTag(ctx, theme, focusLabel, 0, 190);
      break;
    }

    case "earthquake_seismic": {
      const quakeShake = Math.sin(time * 22) * 5;

      // Ground & Tectonic fault strata
      ctx.fillStyle = "#78350F";
      roundRect(ctx, -330, 55, 660, 110, 12);
      ctx.fill();
      ctx.fillStyle = "#92400E";
      roundRect(ctx, -330, 55, 660, 38, 8);
      ctx.fill();

      // Crack / fault line
      ctx.strokeStyle = "#FDE047";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(0, 55);
      ctx.lineTo(-18, 92);
      ctx.lineTo(14, 128);
      ctx.lineTo(-8, 165);
      ctx.stroke();

      // Expanding seismic wave rings from fault
      for (let wIdx = 0; wIdx < 3; wIdx++) {
        const radius = 25 + ((time * 85 + wIdx * 55) % 165);
        ctx.strokeStyle = theme.danger;
        ctx.globalAlpha = Math.max(0, 1 - radius / 180);
        ctx.lineWidth = 3.5;
        ctx.beginPath();
        ctx.arc(0, 75, radius, Math.PI, Math.PI * 2);
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      // Swaying buildings
      const buildings = [
        { x: -165, w: 86, h: 165, sway: 0.045 },
        { x: -35, w: 96, h: 205, sway: -0.055 },
        { x: 115, w: 88, h: 148, sway: 0.04 },
      ];
      buildings.forEach((b, idx) => {
        ctx.save();
        ctx.translate(b.x + b.w / 2, 58);
        ctx.rotate(Math.sin(time * 12 + idx) * b.sway);
        ctx.fillStyle = idx === 1 ? "#334155" : "#475569";
        roundRect(ctx, -b.w / 2 + quakeShake * 0.25, -b.h, b.w, b.h, 6);
        ctx.fill();

        // Windows
        ctx.fillStyle = "#FDE047";
        for (let r = 0; r < 4; r++) {
          for (let c = 0; c < 2; c++) {
            ctx.fillRect(-b.w / 2 + 16 + c * 32, -b.h + 18 + r * 30, 16, 16);
          }
        }
        ctx.restore();
      });

      drawFocusTag(ctx, theme, focusLabel, 0, 198);
      break;
    }

    case "tech_circuit": {
      // Circuit traces radiating out from microchip
      const pins = [-90, -30, 30, 90];
      ctx.strokeStyle = theme.accent;
      ctx.lineWidth = 3.5;
      pins.forEach((p, idx) => {
        // Left & Right traces
        ctx.beginPath();
        ctx.moveTo(-95, p);
        ctx.lineTo(-245, p);
        ctx.moveTo(95, p);
        ctx.lineTo(245, p);
        ctx.stroke();

        // Top & Bottom traces
        ctx.beginPath();
        ctx.moveTo(p, -95);
        ctx.lineTo(p, -175);
        ctx.moveTo(p, 95);
        ctx.lineTo(p, 165);
        ctx.stroke();

        // Moving data pulse dot on horizontal line
        const t = ((time * 0.9 + idx * 0.25) % 1);
        const dotX = 95 + t * 150;
        ctx.fillStyle = theme.success;
        ctx.beginPath();
        ctx.arc(dotX, p, 7, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.arc(-dotX, p, 7, 0, Math.PI * 2);
        ctx.fill();
      });

      // Central Processor Chip
      ctx.save();
      ctx.scale(pop, pop);
      ctx.fillStyle = "#0F172A";
      ctx.strokeStyle = theme.accent;
      ctx.lineWidth = 5;
      roundRect(ctx, -98, -98, 196, 196, 22);
      ctx.fill();
      ctx.stroke();

      ctx.fillStyle = theme.accentSoft;
      roundRect(ctx, -64, -64, 128, 128, 14);
      ctx.fill();

      ctx.fillStyle = "#F8FAFC";
      ctx.font = `800 28px "JetBrains Mono", monospace`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("CORE", 0, -8);
      ctx.font = `600 16px "JetBrains Mono", monospace`;
      ctx.fillStyle = theme.accent;
      ctx.fillText("SYSTEM", 0, 22);
      ctx.restore();

      drawFocusTag(ctx, theme, focusLabel, 0, 192);
      break;
    }

    case "ocean_marine": {
      // Sunbeams underwater
      ctx.fillStyle = "rgba(255, 255, 255, 0.08)";
      for (let b = 0; b < 3; b++) {
        ctx.beginPath();
        ctx.moveTo(-220 + b * 170, -210);
        ctx.lineTo(-140 + b * 170, -210);
        ctx.lineTo(-60 + b * 170, 180);
        ctx.lineTo(-190 + b * 170, 180);
        ctx.closePath();
        ctx.fill();
      }

      // Rolling surface waves
      ctx.fillStyle = "#0284C7";
      ctx.beginPath();
      ctx.moveTo(-360, -70);
      for (let wx = -360; wx <= 360; wx += 20) {
        const wy = -72 + Math.sin(wx * 0.025 + time * 3.2) * 18;
        ctx.lineTo(wx, wy);
      }
      ctx.lineTo(360, 210);
      ctx.lineTo(-360, 210);
      ctx.closePath();
      ctx.fill();

      // Coral silhouettes at bottom
      ctx.fillStyle = "#0F766E";
      [-230, -140, 180, 255].forEach((cxCoral, idx) => {
        roundRect(ctx, cxCoral, 95 - (idx % 2) * 28, 28, 105, 14);
        ctx.fill();
      });

      // Swimming fish
      [
        { y: 12, speed: 65, dir: 1, color: "#FBBF24", size: 22 },
        { y: 68, speed: 45, dir: -1, color: "#38BDF8", size: 17 },
      ].forEach((f, idx) => {
        const rawX = ((time * f.speed + idx * 210) % 580) - 290;
        const fx = rawX * f.dir;
        ctx.save();
        ctx.translate(fx, f.y + Math.sin(time * 4 + idx) * 6);
        ctx.scale(f.dir, 1);
        ctx.fillStyle = f.color;
        ctx.beginPath();
        ctx.ellipse(0, 0, f.size * 1.4, f.size * 0.75, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.moveTo(-f.size * 1.2, 0);
        ctx.lineTo(-f.size * 2, -f.size * 0.65);
        ctx.lineTo(-f.size * 2, f.size * 0.65);
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      });

      drawFocusTag(ctx, theme, focusLabel, 0, 192);
      break;
    }

    case "energy_solar": {
      // Glowing Sun top left
      ctx.fillStyle = "#F59E0B";
      ctx.beginPath();
      ctx.arc(-215, -135, 44, 0, Math.PI * 2);
      ctx.fill();

      // Animated sunbeams to solar panel
      for (let i = 0; i < 4; i++) {
        const shift = ((time * 1.2 + i * 0.25) % 1);
        const rx = -175 + shift * 145;
        const ry = -110 + shift * 95;
        ctx.fillStyle = "#FBBF24";
        ctx.beginPath();
        ctx.arc(rx, ry, 7, 0, Math.PI * 2);
        ctx.fill();
      }

      // Tilted Solar Panel
      ctx.save();
      ctx.translate(-30, 20);
      ctx.rotate(-0.22);
      ctx.fillStyle = "#1E3A8A";
      ctx.strokeStyle = "#94A3B8";
      ctx.lineWidth = 4;
      roundRect(ctx, -115, -65, 230, 130, 10);
      ctx.fill();
      ctx.stroke();

      ctx.strokeStyle = "rgba(147, 197, 253, 0.45)";
      ctx.lineWidth = 2;
      for (let gx = -75; gx <= 75; gx += 38) {
        ctx.beginPath();
        ctx.moveTo(gx, -65);
        ctx.lineTo(gx, 65);
        ctx.stroke();
      }
      ctx.beginPath();
      ctx.moveTo(-115, 0);
      ctx.lineTo(115, 0);
      ctx.stroke();
      ctx.restore();

      // Battery charge unit on right
      ctx.fillStyle = theme.cardBg;
      ctx.strokeStyle = theme.success;
      ctx.lineWidth = 4;
      roundRect(ctx, 155, -80, 110, 170, 14);
      ctx.fill();
      ctx.stroke();
      const chargeH = 35 + ((Math.sin(time * 2.5) + 1) * 0.5) * 100;
      ctx.fillStyle = theme.success;
      roundRect(ctx, 169, 76 - chargeH, 82, chargeH, 8);
      ctx.fill();

      drawFocusTag(ctx, theme, focusLabel, 0, 185);
      break;
    }

    case "money_economy": {
      // Rising bar chart + currency coins
      const bars = [0.4, 0.62, 0.78, 1.0];
      bars.forEach((hRatio, idx) => {
        const bh = 180 * hRatio * easeOutCubic(Math.min(1, sceneElapsed / 0.8));
        const bx = -205 + idx * 78;
        ctx.fillStyle = idx === 3 ? theme.accent : "#3B82F6";
        roundRect(ctx, bx, 105 - bh, 52, bh, 8);
        ctx.fill();
      });

      // Flowing coins on right
      for (let c = 0; c < 4; c++) {
        const cyCoin = -95 + c * 52 + Math.sin(time * 3 + c) * 6;
        ctx.fillStyle = "#F59E0B";
        ctx.strokeStyle = "#B45309";
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(195, cyCoin, 22, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }

      drawFocusTag(ctx, theme, focusLabel, 0, 182);
      break;
    }

    case "concept_diagram":
    default: {
      // Adaptive educational diagram built directly from spec.subject, spec.action, spec.objects
      const objs =
        spec.objects && spec.objects.length > 0
          ? spec.objects.slice(0, 4)
          : [scene.topSubLabel || "Aspek Utama", "Mekanisme", "Dampak"];

      const nodePositions = [
        { x: -215, y: -105 },
        { x: 215, y: -105 },
        { x: -215, y: 105 },
        { x: 215, y: 105 },
      ];

      // Connecting vectors
      objs.forEach((_, idx) => {
        const pos = nodePositions[idx % nodePositions.length];
        ctx.strokeStyle = theme.accent;
        ctx.lineWidth = 3;
        ctx.globalAlpha = 0.6;
        ctx.beginPath();
        ctx.moveTo(0, -10);
        ctx.lineTo(pos.x, pos.y);
        ctx.stroke();

        // Moving pulse dot along connector
        const t = ((time * 0.8 + idx * 0.25) % 1);
        ctx.globalAlpha = 1;
        ctx.fillStyle = theme.accent;
        ctx.beginPath();
        ctx.arc(pos.x * t, -10 + (pos.y + 10) * t, 6, 0, Math.PI * 2);
        ctx.fill();
      });

      // Satellite object nodes
      objs.forEach((label, idx) => {
        const pos = nodePositions[idx % nodePositions.length];
        ctx.fillStyle = theme.cardBg;
        ctx.strokeStyle = theme.cardBorder;
        ctx.lineWidth = 2.5;
        roundRect(ctx, pos.x - 115, pos.y - 30, 230, 60, 14);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = theme.ink;
        ctx.font = `700 18px "DM Sans", sans-serif`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(label, pos.x, pos.y, 205);
      });

      // Central Subject Hub with spring pop + floating shadow
      drawSubjectDropShadow(ctx, 0, 72, 130, pop);
      ctx.save();
      ctx.translate(0, idleHover * 0.55);
      ctx.scale(pop, pop);
      ctx.fillStyle = theme.accent;
      roundRect(ctx, -145, -62, 290, 104, 20);
      ctx.fill();

      ctx.fillStyle = theme.accentText;
      ctx.font = `800 23px "Plus Jakarta Sans", sans-serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(spec.subject, 0, -24, 260);

      ctx.font = `600 16px "DM Sans", sans-serif`;
      ctx.globalAlpha = 0.88;
      ctx.fillText(spec.action, 0, 14, 260);
      ctx.restore();

      drawFocusTag(ctx, theme, spec.environment, 0, 195);
      break;
    }
  }

  // Layer 4: Foreground atmospheric particle layer & active narration cue pill
  drawAtmosphericParticleLayer(ctx, envEffect, theme, time, "front", intensityMult);

  if (activeSegment?.visualEvent) {
    ctx.save();
    ctx.globalAlpha = 0.88;
    ctx.fillStyle = theme.cardBg;
    ctx.strokeStyle = theme.cardBorder;
    ctx.lineWidth = 1.5;
    roundRect(ctx, -345, -222, 310, 34, 9);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = theme.accent;
    ctx.beginPath();
    ctx.arc(-327, -205, 5, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = theme.inkMuted;
    ctx.font = `600 13px "JetBrains Mono", monospace`;
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(activeSegment.visualEvent, -315, -205, 268);
    ctx.restore();
  }

  ctx.restore();
}
